# MIKOSMETICS v3.1 — Fase 1: infraestructura y campanita

## Implementado en archivos (no desplegado)
- Migración incremental `supabase/migrations/20261012_v31_notifications_core.sql`: eventos internos persistentes, lectura por administrador, cola externa email/push, preferencias, índices, idempotencia por pedido/evento/canal/destinatario, RLS y Realtime.
- `js/admin-notifications.js`: campanita con contador, bandeja, marcas de lectura, acceso al pedido, suscripción Realtime, recuperación al volver online/abrir panel.
- Integración en `js/admin.js` y estilos en `css/style.css`.
- Conservados el outbox y los workers WhatsApp v3.0; no se ejecuta ninguna entrega WhatsApp nueva desde esta implementación. No ejecutar worker WhatsApp si está pausado.

## Alcance y límites
- La campanita muestra pedidos creados y pendientes, pero solo llama «Venta confirmada» a un pedido cuyo `payment_status` es `paid` y cuyo inventario está `committed` tras transición del backend.
- No hay proveedor de correo ni push configurado todavía: las preferencias email/push vienen desactivadas por defecto y la cola no tiene worker activo.
- No se ha aplicado la migración a Supabase ni comprobado RLS en una base remota. No se han enviado correos ni notificaciones iOS. Los webhooks de Mercado Pago siguen pendientes de pruebas reales.
- Eventos repetidos de un mismo tipo por pedido se registran una sola vez. Para ciclos logísticos que requieran registrar varias ocurrencias del mismo tipo se ampliará la clave idempotente.
- Antes de desplegar, revisar las políticas y funciones contra el esquema remoto, hacer copia de seguridad y probar en staging. La migración supone que `public.profiles` tiene `id` y `role`, que `private.is_admin()` existe y que `public.orders` tiene `payment_status`, `inventory_state` y `order_status`.

## Verificaciones locales
- `node --check js/admin.js` y `node --check js/admin-notifications.js` sin errores.
- Suite de pruebas `.mjs` del ZIP ejecutada sin errores.
- `python tests/validate_release.py`: PASS.
- SQL: inspección estática; **no** se ha ejecutado contra PostgreSQL/Supabase en este entorno.

## Instalación posterior (sin aplicar automáticamente)
1. Respaldar base de datos y comparar el esquema remoto con las migraciones incluidas.
2. Aplicar la migración v3.1 en un proyecto de pruebas y validar triggers/RLS con cuentas admin y cliente.
3. Desplegar el frontend completo con HTTPS, iniciar sesión como admin y probar pedidos de prueba y eventos Realtime.
4. Posteriormente configurar proveedor transaccional, worker de entregas, preferencias, Web Push PWA y VAPID; no activar canales hasta superar pruebas reales.
