-- Additive v3.1: preserves v3.0 WhatsApp outbox and functions unchanged.
create table if not exists public.admin_notifications (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete cascade,
 event_type text not null check (event_type in ('order_created','payment_pending','payment_approved','payment_rejected','order_cancelled','order_preparing','order_shipped','order_delivered')),
 severity text not null default 'info' check (severity in ('info','important','critical')),
 title text not null, body text not null,
 created_at timestamptz not null default now(),
 unique(order_id,event_type)
);
create index if not exists admin_notifications_recent_v31 on public.admin_notifications(created_at desc);
create table if not exists public.admin_notification_reads (
 notification_id uuid not null references public.admin_notifications(id) on delete cascade,
 admin_id uuid not null references auth.users(id) on delete cascade,
 read_at timestamptz not null default now(),
 primary key(notification_id,admin_id)
);
create table if not exists public.notification_deliveries (
 id uuid primary key default gen_random_uuid(),
 notification_id uuid not null references public.admin_notifications(id) on delete cascade,
 channel text not null check(channel in ('email','push')),
 recipient_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'queued' check(status in ('queued','sending','retry','sent','failed','disabled')),
 attempts integer not null default 0 check(attempts between 0 and 10),
 next_attempt_at timestamptz not null default now(),
 provider_message_id text, last_error text, sent_at timestamptz,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 unique(notification_id,channel,recipient_id)
);
create index if not exists notification_deliveries_queue_v31 on public.notification_deliveries(next_attempt_at) where status in ('queued','retry');
create table if not exists public.admin_notification_preferences (
 admin_id uuid primary key references auth.users(id) on delete cascade,
 email_enabled boolean not null default false,
 push_enabled boolean not null default false,
 updated_at timestamptz not null default now()
);
-- No external channels enabled by default until providers, opt-in and verification are ready.
create or replace function public.enqueue_admin_notification_v31(p_order_id uuid,p_event text,p_severity text,p_title text,p_body text)
returns void language plpgsql security definer set search_path='' as $$
declare v_id uuid;
begin
 insert into public.admin_notifications(order_id,event_type,severity,title,body)
 values(p_order_id,p_event,p_severity,p_title,p_body)
 on conflict(order_id,event_type) do nothing returning id into v_id;
 if v_id is null then return; end if;
 insert into public.notification_deliveries(notification_id,channel,recipient_id)
 select v_id,'email',p.id from public.profiles p
 join public.admin_notification_preferences pref on pref.admin_id=p.id and pref.email_enabled
 where p.role='admin'
 on conflict do nothing;
 insert into public.notification_deliveries(notification_id,channel,recipient_id)
 select v_id,'push',p.id from public.profiles p
 join public.admin_notification_preferences pref on pref.admin_id=p.id and pref.push_enabled
 where p.role='admin'
 on conflict do nothing;
end; $$;
revoke all on function public.enqueue_admin_notification_v31(uuid,text,text,text,text) from public,anon,authenticated;
create or replace function public.orders_notify_admin_v31()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='INSERT' then
  perform public.enqueue_admin_notification_v31(new.id,'order_created','info','Nuevo pedido','Pedido recibido; el pago todavía no está confirmado.');
  if new.payment_status='pending' then
   perform public.enqueue_admin_notification_v31(new.id,'payment_pending','info','Pago pendiente','Aún no se ha confirmado el pago.');
  end if;
 else
  if new.payment_status is distinct from old.payment_status then
   if new.payment_status='paid' and new.inventory_state='committed' then
    perform public.enqueue_admin_notification_v31(new.id,'payment_approved','important','Venta confirmada','Pago validado e inventario confirmado.');
   elsif new.payment_status='pending' then
    perform public.enqueue_admin_notification_v31(new.id,'payment_pending','info','Pago pendiente','El pago está pendiente de confirmación.');
   elsif new.payment_status in ('failed','rejected') then
    perform public.enqueue_admin_notification_v31(new.id,'payment_rejected','important','Pago no aprobado','Revisa el estado del pedido.');
   end if;
  end if;
  if new.order_status is distinct from old.order_status then
   if new.order_status='Cancelado' then
    perform public.enqueue_admin_notification_v31(new.id,'order_cancelled','important','Pedido cancelado','El pedido cambió a cancelado.');
   elsif new.order_status in ('En preparación','Preparando') then
    perform public.enqueue_admin_notification_v31(new.id,'order_preparing','info','Pedido en preparación','Se actualizó el estado logístico.');
   elsif new.order_status in ('Enviado','En camino') then
    perform public.enqueue_admin_notification_v31(new.id,'order_shipped','info','Pedido enviado','Se actualizó el estado logístico.');
   elsif new.order_status='Entregado' then
    perform public.enqueue_admin_notification_v31(new.id,'order_delivered','info','Pedido entregado','Se actualizó el estado logístico.');
   end if;
  end if;
 end if;
 return new;
end; $$;
revoke all on function public.orders_notify_admin_v31() from public,anon,authenticated;
drop trigger if exists orders_notify_admin_v31 on public.orders;
create trigger orders_notify_admin_v31 after insert or update of payment_status,inventory_state,order_status on public.orders
for each row execute function public.orders_notify_admin_v31();

-- Privileges and RLS: authenticated admins read, only their own read receipts can be written.
do $$ declare t text; begin
 foreach t in array array['admin_notifications','admin_notification_reads','notification_deliveries','admin_notification_preferences'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('revoke all on public.%I from public,anon,authenticated',t);
  execute format('grant all on public.%I to service_role',t);
 end loop;
end $$;
grant select on public.admin_notifications to authenticated;
grant select,insert,delete on public.admin_notification_reads to authenticated;
grant select on public.notification_deliveries to authenticated;
grant select,insert,update on public.admin_notification_preferences to authenticated;
create policy admin_notifications_select_v31 on public.admin_notifications for select to authenticated using ((select private.is_admin()));
create policy admin_reads_select_v31 on public.admin_notification_reads for select to authenticated using ((select private.is_admin()) and admin_id=(select auth.uid()));
create policy admin_reads_insert_v31 on public.admin_notification_reads for insert to authenticated with check ((select private.is_admin()) and admin_id=(select auth.uid()));
create policy admin_reads_delete_v31 on public.admin_notification_reads for delete to authenticated using ((select private.is_admin()) and admin_id=(select auth.uid()));
create policy admin_deliveries_select_v31 on public.notification_deliveries for select to authenticated using ((select private.is_admin()) and recipient_id=(select auth.uid()));
create policy admin_preferences_select_v31 on public.admin_notification_preferences for select to authenticated using ((select private.is_admin()) and admin_id=(select auth.uid()));
create policy admin_preferences_insert_v31 on public.admin_notification_preferences for insert to authenticated with check ((select private.is_admin()) and admin_id=(select auth.uid()));
create policy admin_preferences_update_v31 on public.admin_notification_preferences for update to authenticated using ((select private.is_admin()) and admin_id=(select auth.uid())) with check ((select private.is_admin()) and admin_id=(select auth.uid()));
-- Supabase Realtime publication; duplicate-safe.
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='admin_notifications') then
  alter publication supabase_realtime add table public.admin_notifications;
 end if;
end $$;
