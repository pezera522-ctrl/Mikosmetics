/** v3.1 admin bell. Database policies enforce admin access; never use service keys here. */
export function mountAdminNotifications({sb,user,onOpenOrder}) {
  const host=document.querySelector('.admin-tabs');
  if(!host || !user?.id)return ()=>{};
  let alive=true,rows=[],readIds=new Set(),channel=null;
  const wrap=document.createElement('div');wrap.className='admin-bell-wrap';
  const bell=document.createElement('button');bell.type='button';bell.className='admin-bell';bell.setAttribute('aria-label','Notificaciones');bell.setAttribute('aria-expanded','false');bell.textContent='🔔';
  const count=document.createElement('span');count.className='admin-bell-count';count.hidden=true;bell.append(count);
  const tray=document.createElement('section');tray.className='admin-bell-tray';tray.hidden=true;tray.setAttribute('aria-label','Notificaciones administrativas');
  const heading=document.createElement('h3');heading.textContent='Notificaciones';
  const status=document.createElement('p');status.setAttribute('role','status');
  const items=document.createElement('div');
  const markAll=document.createElement('button');markAll.type='button';markAll.textContent='Marcar todas como leídas';
  tray.append(heading,status,markAll,items);wrap.append(bell,tray);host.append(wrap);
  const date=(value)=>new Date(value).toLocaleString('es-MX',{dateStyle:'short',timeStyle:'short'});
  function render(){
    if(!alive)return;
    const unread=rows.filter(r=>!readIds.has(r.id)).length;
    count.hidden=!unread;count.textContent=unread>99?'99+':String(unread);
    items.replaceChildren();
    if(!rows.length){const p=document.createElement('p');p.textContent='Todavía no hay avisos.';items.append(p);}
    for(const r of rows){
      const item=document.createElement('article');item.className='admin-bell-item';
      if(!readIds.has(r.id))item.classList.add('is-unread');
      const title=document.createElement('strong');title.textContent=r.title;
      const body=document.createElement('p');body.textContent=r.body;
      const time=document.createElement('small');time.textContent=date(r.created_at);
      const open=document.createElement('button');open.type='button';open.textContent='Ver pedido';open.addEventListener('click',()=>{tray.hidden=true;bell.setAttribute('aria-expanded','false');onOpenOrder(r.order_id);});
      const mark=document.createElement('button');mark.type='button';mark.textContent=readIds.has(r.id)?'Leída':'Marcar leída';mark.disabled=readIds.has(r.id);
      mark.addEventListener('click',async()=>{const {error}=await sb.from('admin_notification_reads').upsert({notification_id:r.id,admin_id:user.id},{onConflict:'notification_id,admin_id'});if(error)status.textContent='No se pudo marcar como leída.';else{readIds.add(r.id);render();}});
      item.append(title,body,time,open,mark);items.append(item);
    }
  }
  async function refresh(){
    const [notices,reads]=await Promise.all([
      sb.from('admin_notifications').select('id,order_id,event_type,severity,title,body,created_at').order('created_at',{ascending:false}).limit(100),
      sb.from('admin_notification_reads').select('notification_id').eq('admin_id',user.id).limit(5000)
    ]);
    if(!alive)return;
    if(notices.error||reads.error){status.textContent='No se pudieron cargar las notificaciones. Verifica la migración v3.1.';return;}
    rows=notices.data||[];readIds=new Set((reads.data||[]).map(r=>r.notification_id));status.textContent='';render();
  }
  bell.addEventListener('click',()=>{tray.hidden=!tray.hidden;bell.setAttribute('aria-expanded',String(!tray.hidden));if(!tray.hidden)void refresh();});
  markAll.addEventListener('click',async()=>{
    const unread=rows.filter(r=>!readIds.has(r.id));if(!unread.length)return;
    const {error}=await sb.from('admin_notification_reads').upsert(unread.map(r=>({notification_id:r.id,admin_id:user.id})),{onConflict:'notification_id,admin_id'});
    if(error)status.textContent='No se pudieron marcar todas como leídas.';else{unread.forEach(r=>readIds.add(r.id));render();}
  });
  channel=sb.channel(`admin-bell-${user.id}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'admin_notifications'},()=>void refresh()).subscribe();
  const online=()=>void refresh();window.addEventListener('online',online);
  const focus=()=>{if(document.visibilityState==='visible')void refresh();};document.addEventListener('visibilitychange',focus);
  void refresh();
  return ()=>{alive=false;window.removeEventListener('online',online);document.removeEventListener('visibilitychange',focus);if(channel)void sb.removeChannel(channel);wrap.remove();};
}
