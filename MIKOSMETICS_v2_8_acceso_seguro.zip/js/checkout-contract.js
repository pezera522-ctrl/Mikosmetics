/** Contrato de revisión de compra de MIKOSMETICS.
 * Pure functions: no redes, no claves privadas, ninguna mutación del servidor.
 * Se preservará este contrato al habilitar pagos después de resolver inventario.
 */
export const paymentGate = Object.freeze({
  enabled: false,
  reason: 'Inventario sin reserva ni descuento transaccional; webhook de pagos pendiente de corrección y pruebas 3DS.',
});
export function cleanCart(input){
  if(!Array.isArray(input))return [];
  const seen=new Map();
  for(const raw of input.slice(0,100)){
    const id=raw?.id;const quantity=Number(raw?.quantity);
    if(typeof id!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id))continue;
    if(!Number.isSafeInteger(quantity)||quantity<1||quantity>99)continue;
    seen.set(id,Math.min(99,(seen.get(id)||0)+quantity));
  }
  return [...seen].map(([id,quantity])=>({id,quantity}));
}
export function specialPrice(p,now=Date.now()){
  const regular=Number(p.price);const sale=Number(p.promotion_price);
  if(!Number.isFinite(regular)||regular<0)return null;
  if(p.promotion_enabled!==true||p.promotion_price===null||!Number.isFinite(sale)||sale<0||sale>=regular)return regular;
  const start=p.promotion_starts_at?Date.parse(p.promotion_starts_at):-Infinity;
  const end=p.promotion_ends_at?Date.parse(p.promotion_ends_at):Infinity;
  if(Number.isNaN(start)||Number.isNaN(end))return regular;
  return now>=start&&now<end?sale:regular;
}
export function analyzeInventory(cart,products,now=Date.now()){
  const byId=new Map(products.map(p=>[p.id,p]));
  const lines=[];let subtotal=0,ok=cart.length>0;
  for(const item of cart){
    const p=byId.get(item.id);
    let valid=true,reason='';const qty=item.quantity;
    let value=null;
    if(!p||p.published!==true||p.available!==true){valid=false;reason='Producto no publicado o ya no disponible.';}
    else if(!Number.isSafeInteger(p.stock)||p.stock<qty){valid=false;reason='Existencias insuficientes. Ajusta la cantidad en el carrito.';}
    else {value=specialPrice(p,now);if(value===null){valid=false;reason='Precio no válido.';}}
    if(!valid)ok=false;
    const total=valid?Math.round(value*qty*100)/100:0;
    if(valid)subtotal+=total;
    lines.push({id:item.id,name:p?.name||'Producto retirado',quantity:qty,price:value,total,valid,reason});
  }
  return {ok,lines,subtotal:Math.round(subtotal*100)/100};
}
