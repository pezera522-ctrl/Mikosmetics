/**
 * MIKOSMETICS — storefront 2.3.
 * Lectura pública con RLS, render seguro de catálogo, destacados, promociones,
 * detalles y carrito local. Sin escritura de pedidos ni cobros desde frontend.
 */
const SUPABASE = 'https://vkjiwdshcftjllllkzbf.supabase.co';
// Clave PUBLISHABLE pública; nunca introducir service_role aquí.
const PUBLISHABLE_KEY = 'sb_publishable_svkc9Vj2VVBgY7h5D2Gx4Q_OsqeJ0a0';
const CART_KEY = 'mikosmetics:cart:v1';
const CACHE_MS = 60_000;
const PAGE_SIZE = 16;
const money = new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' });
const $ = (id) => document.getElementById(id);
const text = (node, value) => { if (node) node.textContent = String(value ?? ''); };
const el = (tag, className = '', value = '') => {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (value !== '') element.textContent = String(value);
  return element;
};
const querySelector = (selector, root = document) => root.querySelector(selector);
const sku = (item) => String(item.id);

let inventory = [];
let cachedAt = 0;
let pending = null;
let catalogDisplayCount = PAGE_SIZE;
let cart = loadCart();
let filterBound = false;
let currentProduct = null;

function amount(n) { return money.format(Number(n) || 0); }
function safePicture(raw) {
  if (typeof raw !== 'string' || raw.length > 1800) return '';
  try {
    const url = new URL(raw, location.href);
    return url.protocol === 'https:' || (url.origin === location.origin && url.protocol === 'http:') ? url.href : '';
  } catch { return ''; }
}
function validProduct(p) {
  const price = Number(p.price);
  return p && typeof p.id === 'string' && typeof p.name === 'string' && Number.isFinite(price) && price >= 0;
}
function promo(p, now = Date.now()) {
  if (!p.promotion_enabled) return false;
  const special = Number(p.promotion_price);
  if (p.promotion_price == null || !Number.isFinite(special) || special < 0 || special >= Number(p.price)) return false;
  const from = p.promotion_starts_at ? Date.parse(p.promotion_starts_at) : -Infinity;
  const to = p.promotion_ends_at ? Date.parse(p.promotion_ends_at) : Infinity;
  return Number.isFinite(from) || from === -Infinity ? (Number.isFinite(to) || to === Infinity) && now >= from && now <= to : false;
}
function currentPrice(p) { return promo(p) ? Number(p.promotion_price) : Number(p.price); }
function stock(p) { return p.available === true && Number.isSafeInteger(p.stock) && p.stock > 0 ? p.stock : 0; }
function safeReadCart(input) {
  if (!Array.isArray(input)) return [];
  const valid = new Map();
  for (const item of input.slice(0, 100)) {
    if (typeof item?.id !== 'string' || !/^[0-9a-f-]{36}$/i.test(item.id)) continue;
    const quantity = Number(item.quantity);
    if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 99) continue;
    valid.set(item.id, Math.min(99, (valid.get(item.id) || 0) + quantity));
  }
  return [...valid].map(([id, quantity]) => ({ id, quantity }));
}
function loadCart() {
  try { return safeReadCart(JSON.parse(localStorage.getItem(CART_KEY) || '[]')); }
  catch { return []; }
}
function saveCart() {
  try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch { /* Sin almacenamiento disponible. */ }
  window.MIKOSMETICS_UI?.updateCartCount(cart.reduce((sum, item) => sum + item.quantity, 0));
}
function setState(id, message, kind = '') {
  const node = $(id);
  if (!node) return;
  text(node, message);
  if (kind) node.dataset.state = kind;
  else node.removeAttribute('data-state');
}
function link(label, href, className = 'text-link') {
  const a = el('a', className, label);
  a.href = href;
  a.dataset.link = '';
  return a;
}
function actionButton(label, callback) {
  const b = el('button', 'button button--outline', label);
  b.type = 'button';
  b.addEventListener('click', callback);
  return b;
}
function showProblem(id, error, retry) {
  const node = $(id);
  if (!node) return;
  node.replaceChildren(el('span', '', error), actionButton('Reintentar', retry));
  node.dataset.state = 'error';
}
function refresh() { cachedAt = 0; pending = null; const route = window.MIKOSMETICS_UI?.route; if (route) displayRoute(route); }
async function requestJson(path) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 9_000);
  try {
    const res = await fetch(`${SUPABASE}/rest/v1/${path}`, {
      method: 'GET',
      headers: { apikey: PUBLISHABLE_KEY, Accept: 'application/json' },
      signal: controller.signal,
      cache: 'no-store',
    });
    if (!res.ok) throw new Error(`Servidor: ${res.status}`);
    return await res.json();
  } finally { clearTimeout(timer); }
}
async function fetchInventory() {
  if (Date.now() - cachedAt < CACHE_MS) return inventory;
  if (pending) return pending;
  pending = (async () => {
    const fields = 'id,name,category,description,material,price,image_url,stock,available,published,featured,slug,promotion_enabled,promotion_price,promotion_starts_at,promotion_ends_at';
    const data = await requestJson(`products?select=${fields}&published=eq.true&order=created_at.desc&limit=250`);
    if (!Array.isArray(data)) throw new Error('Respuesta de catálogo no válida.');
    inventory = data.filter(validProduct);
    cachedAt = Date.now();
    return inventory;
  })();
  try { return await pending; } finally { pending = null; }
}
function imageElement(p, className = '') {
  const url = safePicture(p.image_url);
  if (!url) return el('div', `media-empty ${className}`, 'MIKOSMETICS');
  const img = el('img', className);
  img.src = url;
  img.alt = p.name;
  img.loading = 'lazy';
  img.decoding = 'async';
  img.addEventListener('error', () => img.replaceWith(el('div', `media-empty ${className}`, p.name)), { once: true });
  return img;
}
function priceDom(p) {
  const wrapper = el('span', 'product-card__prices');
  if (promo(p)) wrapper.append(el('del', 'price-old', amount(p.price)));
  wrapper.append(el('strong', 'price-current', amount(currentPrice(p))));
  return wrapper;
}
function card(p) {
  const article = el('article', `product-card${stock(p) ? '' : ' is-unavailable'}`);
  const dest = `#/producto/${encodeURIComponent(p.slug || p.id)}`;
  const a = link('', dest, 'product-card__link');
  a.setAttribute('aria-label', `Ver ${p.name}`);
  const media = el('div', 'product-card__media');
  media.append(imageElement(p));
  if (promo(p)) media.append(el('span', 'product-card__badge', 'Promoción'));
  a.append(media);
  const body = el('div', 'product-card__body');
  body.append(el('p', 'product-card__category', p.category || 'Producto'), el('h3', 'product-card__name', p.name), priceDom(p), el('p', 'product-card__stock', stock(p) ? `${stock(p)} disponibles` : 'Agotado'));
  const label = body.querySelector('h3');
  label.id = `product-${String(p.id).replace(/[^\w-]/g, '')}`;
  a.append(body);
  article.append(a);
  return article;
}
function choose(items, containerId, stateId, emptyText) {
  const holder = $(containerId);
  if (!holder) return;
  holder.replaceChildren(...items.map(card));
  setState(stateId, items.length ? '' : emptyText);
}
function showFeatured(products) {
  choose(products.filter(p => p.featured).slice(0, 12), 'featured-list', 'featured-state', 'No hay productos destacados publicados en este momento.');
  const previews = products.filter(promo);
  const panel = $('home-promo-preview');
  if (panel) {
    panel.replaceChildren();
    if (previews.length) panel.append(imageElement(previews[0]));
    else panel.append(el('span', 'media-empty', 'Sin promociones activas'));
  }
}
function populateCategories(products) {
  const box = $('catalog-category');
  if (!box) return;
  const current = box.value;
  const categories = [...new Set(products.map(p => (p.category || '').trim()).filter(Boolean))].sort((a,b) => a.localeCompare(b,'es'));
  box.replaceChildren(new Option('Todas las categorías',''), ...categories.map(v => new Option(v, v)));
  box.value = categories.includes(current) ? current : '';
}
function showCatalog(products) {
  populateCategories(products);
  const query = ($('catalog-query')?.value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
  const cat = $('catalog-category')?.value || '';
  const sorting = $('catalog-sort')?.value || 'relevance';
  let results = products.filter(p => (!cat || p.category === cat) && (!query || `${p.name} ${p.category||''} ${p.description||''}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(query)));
  if (sorting === 'price_asc') results = results.sort((a,b)=>currentPrice(a)-currentPrice(b));
  else if (sorting === 'price_desc') results = results.sort((a,b)=>currentPrice(b)-currentPrice(a));
  else if (sorting === 'name') results = results.sort((a,b)=>a.name.localeCompare(b.name,'es'));
  choose(results.slice(0,catalogDisplayCount), 'catalog-list', 'catalog-state', products.length ? 'No hay productos que coincidan con los filtros.' : 'Todavía no hay productos publicados.');
  const more = $('catalog-more');
  if (more) more.hidden = results.length <= catalogDisplayCount;
}
function showPromos(products) {
  choose(products.filter(promo), 'promos-list','promos-state', 'No hay promociones vigentes en este momento.');
}
async function showProduct(products, id, signal) {
  const p = products.find(item => item.slug === id || item.id === id);
  const detail = $('product-detail');
  if (!p) {
    if (detail) detail.hidden = true;
    setState('product-state', 'No encontramos ese producto.', 'error');
    return;
  }
  currentProduct = p;
  $('product-title').textContent = p.name;
  text($('product-category'), p.category || 'Producto');
  text($('product-description'), p.description || '');
  text($('product-material'), p.material ? `Material: ${p.material}` : '');
  text($('product-availability'), stock(p) ? `Disponible · ${stock(p)} unidades` : 'Actualmente agotado');
  $('product-availability').classList.toggle('is-unavailable', !stock(p));
  $('product-prices').replaceChildren(priceDom(p));
  $('product-id').value = p.id;
  $('product-quantity').value = '1';
  $('product-quantity').max = String(Math.max(1, stock(p)));
  $('add-to-cart').disabled = stock(p) === 0;
  $('product-main-media').replaceChildren(imageElement(p));
  const thumb = $('product-thumbs');
  thumb.replaceChildren();
  const primary = safePicture(p.image_url);
  // La ficha principal aparece inmediatamente; la galería secundaria no bloquea la pantalla.
  detail.hidden = false;
  document.title = `${p.name} — MIKOSMETICS`;
  setState('product-state', '');
  let secondary = [];
  try {
    const list = await requestJson(`product_images?select=image_url,position&product_id=eq.${encodeURIComponent(p.id)}&order=position.asc&limit=20`);
    if (Array.isArray(list)) secondary = list.map(v => safePicture(v.image_url)).filter(Boolean);
  } catch { /* Galería secundaria no bloquea la ficha. */ }
  if (signal.aborted) return;
  const urls = [...new Set([primary, ...secondary].filter(Boolean))];
  if (urls.length > 1) {
    urls.forEach((url, i) => {
      const b = actionButton(`Imagen ${i+1}`, () => {
        const img = el('img'); img.src = url; img.alt = p.name;
        img.addEventListener('error', () => img.replaceWith(el('div','media-empty',p.name)), { once:true });
        $('product-main-media').replaceChildren(img);
        thumb.querySelectorAll('button').forEach((x,j)=>x.setAttribute('aria-pressed',String(j===i)));
      });
      b.className = '';
      b.setAttribute('aria-pressed', String(i===0));
      const preview = el('img'); preview.src = url; preview.alt = '';
      b.replaceChildren(preview);
      b.setAttribute('aria-label',`Mostrar imagen ${i+1}`);
      thumb.append(b);
    });
  }
}
function updateCartUI(products) {
  const list = $('cart-items');
  if (!list) return;
  list.replaceChildren();
  let subtotal = 0;
  if (!cart.length) {
    setState('cart-state','Tu carrito está vacío.');
  } else {
    setState('cart-state','');
    for (const item of cart) {
      const product = products.find(p => sku(p) === item.id);
      const itemNode = el('div','cart-item');
      if (product) itemNode.append(imageElement(product,'cart-item__image'));
      else itemNode.append(el('div','cart-item__image media-empty','Sin imagen'));
      const details = el('div');
      details.append(el('h2','cart-item__title',product?.name || 'Producto retirado'),el('p','cart-item__meta',product ? amount(currentPrice(product)) : 'No disponible'));
      const controls = el('div','cart-item__controls');
      const qty = el('input'); qty.type='number'; qty.min='1'; qty.max=String(product ? Math.min(99,stock(product)) : 1); qty.step='1'; qty.value=String(item.quantity); qty.setAttribute('aria-label',`Cantidad de ${product?.name || 'producto retirado'}`);
      qty.disabled = !product || !stock(product);
      qty.addEventListener('change',()=>{
        const n = Number(qty.value);
        if (Number.isSafeInteger(n) && n >= 1 && n <= Math.min(99,stock(product))) {item.quantity=n;saveCart();updateCartUI(inventory);}
        else {qty.value=String(item.quantity);window.MIKOSMETICS_UI?.toast('Cantidad no disponible.','error');}
      });
      const remove = el('button','cart-item__remove','Quitar');remove.type='button';remove.addEventListener('click',()=>{cart=cart.filter(c=>c.id!==item.id);saveCart();updateCartUI(inventory);});
      controls.append(qty,remove);details.append(controls);itemNode.append(details);list.append(itemNode);
      if(product) subtotal += currentPrice(product)*Math.min(item.quantity,stock(product));
    }
  }
  text($('cart-subtotal'),amount(subtotal));
  const checkout=$('cart-checkout');
  if(checkout) checkout.disabled=true; // Todavía no hay checkout seguro verificado.
}
async function displayRoute(route, signal = new AbortController().signal) {
  if (!['inicio','productos','promociones','producto','carrito'].includes(route.screen)) return;
  if(route.screen==='inicio') setState('featured-state','Cargando productos destacados…');
  if(route.screen==='productos') setState('catalog-state','Cargando catálogo…');
  if(route.screen==='promociones') setState('promos-state','Consultando promociones…');
  if(route.screen==='producto') setState('product-state','Cargando producto…');
  if(route.screen==='carrito') setState('cart-state','Comprobando disponibilidad…');
  let products;
  try { products = await fetchInventory(); }
  catch(e) {
    if (signal.aborted) return;
    const id={inicio:'featured-state',productos:'catalog-state',promociones:'promos-state',producto:'product-state',carrito:'cart-state'}[route.screen];
    showProblem(id,'No pudimos conectar con el catálogo. Comprueba la red y vuelve a intentar.',refresh);
    return;
  }
  if(signal.aborted) return;
  if(route.screen==='inicio') showFeatured(products);
  if(route.screen==='productos') showCatalog(products);
  if(route.screen==='promociones') showPromos(products);
  if(route.screen==='producto') await showProduct(products,route.id,signal);
  if(route.screen==='carrito') updateCartUI(products);
}
function bindControls() {
  $('catalog-filters')?.addEventListener('input',()=>{catalogDisplayCount=PAGE_SIZE;showCatalog(inventory);});
  $('catalog-filters')?.addEventListener('change',()=>{catalogDisplayCount=PAGE_SIZE;showCatalog(inventory);});
  $('catalog-filters')?.addEventListener('reset',()=>{setTimeout(()=>{catalogDisplayCount=PAGE_SIZE;showCatalog(inventory);},0);});
  $('catalog-more')?.addEventListener('click',()=>{catalogDisplayCount+=PAGE_SIZE;showCatalog(inventory);});
  $('add-to-cart-form')?.addEventListener('submit',(event)=>{
    event.preventDefault();
    const p=currentProduct;
    if(!p || !stock(p))return;
    const n=Number($('product-quantity')?.value);
    const index=cart.findIndex(c=>c.id===p.id);
    const existing=index<0?0:cart[index].quantity;
    if(!Number.isSafeInteger(n)||n<1||n+existing>Math.min(99,stock(p))) {
      window.MIKOSMETICS_UI?.toast('La cantidad supera las existencias disponibles.','error');return;
    }
    if(index<0)cart.push({id:p.id,quantity:n});else cart[index].quantity+=n;
    saveCart();window.MIKOSMETICS_UI?.toast('Producto agregado al carrito.','success');
  });
  // Cuentas/direcciones/pedidos administrados por js/account.js (RLS).
  // El checkout, los pagos y las operaciones de administración permanecen bloqueados.
  const restricted = {
    checkout: ['checkout-state', 'Las compras estarán disponibles cuando se verifique el servidor de pedidos, inventario y pagos.'],
    pago: ['payment-state', 'Los cobros no están habilitados.'],
  };
  for (const [stateId, message] of Object.values(restricted)) setState(stateId, message, 'error');
  // CTA de compra deshabilitado hasta comprobar create-checkout-order.
  $('cart-checkout')?.addEventListener('click',()=>window.MIKOSMETICS_UI?.navigate('/checkout'));
}
export function initStorefront() {
  bindControls();
  window.addEventListener('mikosmetics:route',(event)=>{
    const {screen,id,pathname,signal}=event.detail;
    displayRoute({screen,id,pathname},signal);
  });
  window.addEventListener('storage',(event)=>{
    if(event.key===CART_KEY){cart=loadCart();saveCart();if(window.MIKOSMETICS_UI?.route.screen==='carrito')updateCartUI(inventory);}
  });
  queueMicrotask(()=>saveCart());
}
