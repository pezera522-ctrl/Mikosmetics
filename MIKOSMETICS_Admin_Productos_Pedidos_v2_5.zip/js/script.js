/** MIKOSMETICS — arranque ordenado v2.4. */
import { initStorefront } from './storefront.js';
import { initAccount } from './account.js';
import { initAdmin } from './admin.js';
import { initShell } from './ui-shell.js';
// Servicios se suscriben al routing antes de la primera pantalla.
initStorefront();
initAccount();
initAdmin();
initShell();
