/** MIKOSMETICS 3.0 — contrato aislado de Card Payment Brick.
 * No se importa desde script.js; no cobra ni reserva stock.
 * El montaje requiere una orden reservada en el servidor, credenciales TEST y permiso explícito.
 */
export const TEST_PAYMENTS = Object.freeze({ enabled:false, publicKey:'', sdkUrl:'https://sdk.mercadopago.com/js/v2' });
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function validateTestOrder(order){
  return !!(order && UUID.test(String(order.order_id||'')) && order.currency==='MXN' && Number.isFinite(Number(order.total)) && Number(order.total)>0 && order.testing===true && Date.parse(order.reserved_until)>Date.now());
}
export function validateChallengeUrl(value){
  try{const u=new URL(value);return u.protocol==='https:' && (u.hostname==='mercadopago.com' || u.hostname.endsWith('.mercadopago.com') || u.hostname.endsWith('.mercadopago.com.mx') || u.hostname==='mercadopago.com.mx');}
  catch{return false;}
}
export function cardPaymentRequest(order,formData,methodType){
  if(!validateTestOrder(order))throw new Error('La reserva ya no está vigente o no es una compra TEST validada.');
  const token=String(formData?.token||''),method=String(formData?.payment_method_id||'');
  const installments=Number(formData?.installments??1);
  if(!token||token.length>2048||!method||!['credit_card','debit_card'].includes(methodType)||!Number.isInteger(installments)||installments<1||installments>48)throw new Error('El método de pago de prueba no es válido.');
  return {order_id:order.order_id,token,payment_method_id:method,payment_method_type:methodType,installments};
}
/** El callback nunca puede ejecutarse en producción mientras TEST_PAYMENTS.enabled=false. */
export async function mountSandboxCardPaymentBrick({order,methodType,submitSandboxPayment}){
 if(!TEST_PAYMENTS.enabled||!TEST_PAYMENTS.publicKey.trim())throw new Error('Mercado Pago TEST todavía no está habilitado.');
 if(!validateTestOrder(order))throw new Error('Se necesita una orden TEST reservada en Supabase.');
 if(typeof submitSandboxPayment!=='function')throw new Error('Falta el envío autenticado al servidor.');
 if(typeof window.MercadoPago!=='function')throw new Error('Carga primero el SDK oficial Mercado Pago JS v2.');
 const instance=new window.MercadoPago(TEST_PAYMENTS.publicKey,{locale:'es-MX'});
 return instance.bricks().create('cardPayment','payment-brick',{
   initialization:{amount:Number(order.total)},
   callbacks:{
     onReady:()=>{},
     onError:(error)=>console.warn('Error en formulario TEST',error?.name||'error'),
     onSubmit:async({formData})=>{
       const body=cardPaymentRequest(order,formData,methodType);
       const response=await submitSandboxPayment(body);
       if(response?.provider?.challenge_url&&!validateChallengeUrl(response.provider.challenge_url))throw new Error('Destino de autenticación no verificado.');
       return response;
     },
   },
 });
}
