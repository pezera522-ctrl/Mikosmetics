/** MIKOSMETICS v3.0 — enlace de atención; NO envía notificaciones. */
export const BUSINESS_WHATSAPP = '525664218666';
export const SUPPORT_MESSAGE = '¡Hola! Vengo de MIKOSMETICS y me gustaría recibir información sobre sus productos.';
export function whatsappUrl(phone=BUSINESS_WHATSAPP, message=SUPPORT_MESSAGE){
  if(!/^\d{10,15}$/.test(phone))throw new Error('Número de WhatsApp inválido');
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
export function initWhatsAppHelp(){
  if(document.getElementById('whatsapp-support'))return;
  const a=document.createElement('a');
  a.id='whatsapp-support';a.className='whatsapp-support';
  a.href=whatsappUrl();a.target='_blank';a.rel='noopener noreferrer';
  a.setAttribute('aria-label','Abrir conversación de ayuda con MIKOSMETICS en WhatsApp');
  a.innerHTML='<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.6a8.6 8.6 0 0 1-12.6 7.6L3 21l1.8-5.4a8.6 8.6 0 1 1 16.2-4z"/><path d="M9 8.7c.3-.5.5-.6.8-.5l1.1.7c.3.2.3.4.1.8l-.4.7c.6 1 1.4 1.8 2.4 2.3l.6-.6c.3-.3.5-.3.8-.2l1.2.6c.3.1.4.4.2.7-.3.7-.9 1.1-1.5 1.2-2 .2-5.3-2.7-5.7-4.6-.1-.4 0-.7.4-1.1z"/></svg><span>Ayuda por WhatsApp</span>';
  document.body.append(a);
}
