/** Una sola fuente de versión visible para MIKOSMETICS. */
export const RELEASE = '3.0';
export const BUILD = 30;
