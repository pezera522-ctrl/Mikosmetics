# MIKOSMETICS v3.0 — Preparación de cobros TEST y avisos por WhatsApp

**Estado de la versión: tienda navegable y gestión de avisos preparada. No es un checkout de producción ni permite realizar pagos TEST todavía desde el navegador.**

## Funciones ya visibles tras instalar el ZIP

- Se conserva el catálogo, la intro SVG, las cuentas, el carrito, checkout protegido, reservas de inventario v2.9 y administración.
- `js/release.js` muestra la versión **3.0** en el pie de página; todos los módulos de tienda tienen versión de caché `?v=30`.
- Botón flotante de **Ayuda por WhatsApp**, hacia `https://wa.me/525664218666` con texto prellenado. Este botón **no envía mensajes automáticamente** ni necesita una clave.
- Nueva pestaña **Avisos WhatsApp** dentro de Administración. Solo consulta el estado de la bandeja; no envía mensajes ni altera pedidos.
- La revisión del checkout sigue sin crear pedidos; no hay captura de tarjetas en el navegador. No se configura ningún SDK del proveedor ni una llave privada en el frontend.

## Cambios reales aplicados en Supabase

Se aplicó la migración `v30_whatsapp_paid_order_outbox` para crear la tabla `business_notification_outbox`, protegerla con RLS, restringir inserciones al servidor, añadir una clave única `(order_id,event_type,channel)` y crear un trigger que encola **un solo aviso** cuando un pedido pasa a `paid` con inventario `committed`.

**La migración YA está aplicada. NO ejecutar manualmente el SQL incluido en el ZIP.**

Prueba transaccional realizada en Supabase: se creó un pedido/reserva provisional, se confirmó un pago **simulado internamente** y se verificó que solo se encoló un aviso. Repetir la confirmación no añadió duplicados. Se ejecutó `ROLLBACK`, así que quedaron **0 pedidos y 0 avisos de prueba**. Esto **no implica una prueba real de Mercado Pago**.

## Fuentes de Edge Functions incluidas (NO DESPLEGADAS)

`supabase/functions/` contiene cuatro borradores para una etapa posterior:

1. `create-checkout-order`: modo TEST y allowlist de usuario, valida carrito y usa el RPC transaccional v29.
2. `create-mercadopago-order`: solo tokens TEST, reserva vigente, intento de pago previo e idempotencia; nunca actualiza `orders.payment_status=paid` desde el navegador.
3. `mercadopago-webhook`: validación HMAC de firma del proveedor, consulta de la orden remota, concordancia de importe, moneda, referencia e intento de pago, y finalización mediante RPC v29. Maneja resultados inciertos como incidencias de conciliación.
4. `whatsapp-order-notifier`: modo explícitamente habilitado, secret de servicio, número receptor distinto al emisor, plantilla de Meta, entrega de mensajes en cola sin reenviar automáticamente respuestas inciertas.

Los cuatro borradores pasan pruebas de **sintaxis** TypeScript o contratos puros locales, pero **no han sido desplegados, ejecutados en Edge Runtime ni comprobados contra Mercado Pago y Meta reales**. Los dos endpoints desplegados `create-checkout-order` y `create-mercadopago-order` mantienen su bloqueo preventivo 503 y JWT; el webhook desplegado sigue siendo la versión previa. No usar los borradores para producción sin revisión adicional.

## Pruebas locales

- `python3 tests/validate_release.py`: 14 archivos críticos, 129 IDs únicos, 12 módulos JS, 18 pantallas, cuatro borradores de Edge Functions y comprobación de referencias entre JS.
- `node tests/test_checkout_contract.mjs`: 11 escenarios de precios, promociones, stock y bloqueo de cobro.
- `node tests/test_release_v30.mjs`: release 3.0 centralizado y gate de pago desactivado.
- `node tests/test_support_v30.mjs`: número WhatsApp y enlace seguro.
- `node tests/test_payment_protocol_v30.mjs`: contrato de importes, solicitudes, firma y estados del proveedor.
- `python3 tests/smoke_browser_v30.py`: Chromium local en 5 tamaños, botón de ayuda accesible, checkout oculto inicialmente y nueva pestaña administrativa. Es una prueba DOM con contenido estático: no sustituye autenticación o pagos reales en Safari.
- Comprobación de sintaxis TypeScript de los cuatro endpoints preparados, sin comprobar tipos específicos del runtime Deno.

## Bloqueantes para habilitar pagos y automatización

1. Disponer de llaves **TEST** de Mercado Pago configuradas exclusivamente en secretos de Supabase; nunca pegarlas al chat ni añadirlas al repositorio.
2. Probar la reconciliación completa del webhook con firmas válidas, reenvíos, pérdidas de red, pagos tardíos, pagos aprobados con reservas expiradas, reembolsos y 3DS.
3. Integrar Card Payment Brick cuando el servidor tenga habilitación TEST controlada; revisar sus contratos según la versión oficial del SDK y la API Orders.
4. Configurar un programador supervisado para reservas caducadas y recuperación de eventos `error`, `received` o `sending` sin duplicar operaciones.
5. Validar políticas de inventario bajo concurrencia real, y definir punto/hora de entrega personal y tarifas de envío. El envío nacional permanece bloqueado.
6. Registrar WhatsApp Business Platform en Meta, aprobar una plantilla de utilidad con dos parámetros (número de pedido y total), guardar secretos Cloud API y proporcionar un **número receptor distinto del Business emisor**. Solo entonces activar el worker.
7. Hacer pruebas integrales desde Codespaces/iPhone tras instalar este ZIP.

**Precaución:** el código del backend nuevo incluido es trabajo en preparación, no autorización para desplegar funciones ni para cobrar.
