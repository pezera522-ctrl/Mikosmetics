# Instrucciones sencillas para el iPhone — MIKOSMETICS v3.0

1. Descarga `MIKOSMETICS_v3_0_preparacion_TEST_y_WhatsApp.zip`.
2. Sube el archivo ZIP completo (sin descomprimirlo) a la raíz del repositorio en GitHub: `Add file` → `Upload files` → `Commit changes`.
3. En Codespaces ejecuta, **uno por vez**:

   `git pull --ff-only`

   `unzip -o MIKOSMETICS_v3_0_preparacion_TEST_y_WhatsApp.zip`

   `python3 tests/validate_release.py`

   `node tests/test_support_v30.mjs`

4. Abre la vista previa puerto 8000 en Safari. Comprueba el footer `MIKOSMETICS · 3.0`, el botón **Ayuda por WhatsApp** y el tercer apartado del panel **Avisos WhatsApp**.
5. No pegues tokens, claves secretas ni contraseñas en la terminal, GitHub o el chat.

**Ya se aplicó la migración SQL de avisos al proyecto existente en Supabase. No la ejecutes otra vez. No despliegues las funciones de `supabase/functions` hasta completar las pruebas. Los cobros siguen cerrados.**
