from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parents[1]
html=(p/'index.html').read_text()
css=(p/'css/style.css').read_text()
src=(p/'js/whatsapp-help.js').read_text().replace('export ', '')
with sync_playwright() as browser:
    b=browser.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for width,height in [(320,700),(390,844),(430,932),(844,390),(1440,900)]:
        page=b.new_page(viewport={'width':width,'height':height})
        page.set_content(html,wait_until='domcontentloaded')
        page.add_style_tag(content=css)
        page.evaluate(src+'\ninitWhatsAppHelp();')
        assert page.locator('#whatsapp-support').count()==1
        assert page.locator('#whatsapp-support').get_attribute('href').startswith('https://wa.me/525664218666?text=')
        assert page.locator('#checkout-private').get_attribute('hidden') is not None
        assert page.locator('[data-admin-tab="notifications"]').count()==1
        assert page.locator('#cart-checkout').count()==1
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1'), f'horizontal overflow {width}'
        page.close()
    b.close()
print('PASS: 5 viewports, WhatsApp accessible, review hidden by default, admin alerts tab and no sideways overflow')
