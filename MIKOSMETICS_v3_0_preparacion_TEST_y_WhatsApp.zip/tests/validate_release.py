"""Pruebas sin dependencias para revisar archivos de MIKOSMETICS v3.0."""
from pathlib import Path
from html.parser import HTMLParser
from subprocess import run
import re

ROOT=Path(__file__).resolve().parents[1]
FILES=['index.html','css/style.css','js/script.js','js/ui-shell.js','js/storefront.js','js/account.js','js/admin.js','js/supabase-client.js','js/checkout.js','js/checkout-contract.js','js/checkout-access.js','js/release.js','js/whatsapp-help.js','assets/logo-mikosmetics.svg']
class IDs(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.refs=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.append(attrs['id'])
        if 'aria-labelledby' in attrs:self.refs.extend(attrs['aria-labelledby'].split())

for name in FILES:assert (ROOT/name).is_file(),f'Falta {name}'
html=(ROOT/'index.html').read_text(encoding='utf-8')
p=IDs();p.feed(html)
assert len(p.ids)==len(set(p.ids)), 'IDs HTML duplicados'
assert set(p.refs)<=set(p.ids), 'Referencias aria-labelledby inválidas'
assert '?v=30' in html and 'js/script.js?v=30' in html, 'Versionado no configurado'
for route in ['inicio','productos','promociones','producto','carrito','acceso','registro','recuperar','restablecer','cuenta','direcciones','pedidos','pedido','checkout','pago','admin','ayuda','no-encontrado']:
    assert f'id="page-{route}"' in html, f'Falta pantalla {route}'
for js in (ROOT/'js').glob('*.js'):
    r=run(['node','--check',str(js)],capture_output=True,text=True)
    if r.returncode:raise AssertionError(f'Error de sintaxis en {js.name}: {r.stderr}')
    for rel in re.findall(r'\b(?:from|import\()\s*[\'\"](\./[^\'\"]+)',js.read_text(encoding='utf-8')):
        assert (js.parent/rel.split('?')[0]).is_file(),f'Import roto: {js.name} -> {rel}'
assert 'id="release-version"' in html and 'MIKOSMETICS · 2.7' not in html
assert 'data-release="2.8"' not in html
assert 'id="checkout-auth"' in html and 'id="checkout-summary"' in html
assert 'id="checkout-private" hidden' in html
assert 'id="auth-checkout-context"' in html
assert "no se crean pedidos ni se cobran tarjetas" in html
checkout=(ROOT/"js/checkout.js").read_text()
assert ".insert(" not in checkout and "functions.invoke" not in checkout and "POST" not in checkout, "La revisión no puede cobrar ni crear pedidos"

assert (ROOT/'supabase/migrations/20261009_v29_reservas_y_estados.sql').is_file()
assert (ROOT/'supabase/migrations/20261009_v30_outbox_whatsapp.sql').is_file()
for slug in ['create-checkout-order','create-mercadopago-order','mercadopago-webhook','whatsapp-order-notifier']:
    assert (ROOT/'supabase/functions'/slug/'index.ts').is_file(), f'Falta borrador de Edge Function {slug}'
assert (ROOT/'supabase/functions/_shared/payment-contract.mjs').is_file()
assert 'data-admin-tab="notifications"' in html
assert './whatsapp-help.js?v=30' in (ROOT/'js/script.js').read_text()
assert 'MIKOSMETICS · 2.7' not in html
assert (ROOT/'js/release.js').read_text().find("'3.0'")>=0
print(f'PASS: {len(FILES)} archivos críticos, {len(p.ids)} IDs únicos, {len(list((ROOT/"js").glob("*.js")))} módulos JS, 18 pantallas y 4 Edge Functions preparadas.')
