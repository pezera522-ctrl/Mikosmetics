-- MIKOSMETICS 3.0: worker confiable y salida sin notificaciones duplicadas.
-- Importante: requiere que se haya aplicado v30_outbox_whatsapp.
CREATE OR REPLACE FUNCTION public.claim_next_business_notification_v30()
RETURNS TABLE(notification_id uuid, order_id uuid, order_number text, total numeric, delivery_method text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE v_id uuid;
BEGIN
 SELECT n.id INTO v_id FROM public.business_notification_outbox n
 JOIN public.orders o ON o.id=n.order_id
 WHERE n.status IN ('queued','retry') AND n.next_attempt_at<=now() AND n.attempts<5
 AND o.payment_status='paid' AND o.inventory_state='committed'
 ORDER BY n.created_at, n.id LIMIT 1 FOR UPDATE OF n SKIP LOCKED;
 IF v_id IS NULL THEN RETURN; END IF;
 UPDATE public.business_notification_outbox SET status='sending', attempts=attempts+1,updated_at=now() WHERE id=v_id;
 RETURN QUERY SELECT n.id,o.id,o.order_number,o.total,o.delivery_method FROM public.business_notification_outbox n
 JOIN public.orders o ON o.id=n.order_id WHERE n.id=v_id;
END; $$;
REVOKE ALL ON FUNCTION public.claim_next_business_notification_v30() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.claim_next_business_notification_v30() TO service_role;

CREATE OR REPLACE FUNCTION public.complete_business_notification_v30(p_notification_id uuid,p_outcome text,p_provider_message_id text DEFAULT NULL,p_error text DEFAULT NULL)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
BEGIN
 IF p_outcome NOT IN ('sent','failed','retry') OR p_notification_id IS NULL THEN
  RAISE EXCEPTION 'invalid_notification_outcome' USING ERRCODE='22023';
 END IF;
 UPDATE public.business_notification_outbox n SET
  status=CASE WHEN p_outcome='retry' AND attempts>=5 THEN 'failed' ELSE p_outcome END,
  provider_message_id=CASE WHEN p_outcome='sent' THEN NULLIF(p_provider_message_id,'') ELSE provider_message_id END,
  last_error=LEFT(p_error,350),
  sent_at=CASE WHEN p_outcome='sent' THEN now() ELSE sent_at END,
  next_attempt_at=CASE WHEN p_outcome='retry' THEN now()+make_interval(mins=>LEAST(120,GREATEST(2,attempts*5))) ELSE next_attempt_at END,
  updated_at=now()
 WHERE n.id=p_notification_id AND n.status='sending';
 RETURN FOUND;
END; $$;
REVOKE ALL ON FUNCTION public.complete_business_notification_v30(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.complete_business_notification_v30(uuid,text,text,text) TO service_role;
