-- MIKOSMETICS v3.0: bandeja de notificaciones transaccionales.
-- Esta migración NO envía mensajes; la API WhatsApp no está conectada todavía.
create table if not exists public.business_notification_outbox (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  event_type text not null default 'order_paid' check (event_type='order_paid'),
  channel text not null default 'whatsapp' check (channel='whatsapp'),
  status text not null default 'queued' check(status in ('queued','sending','retry','sent','failed')),
  attempts integer not null default 0 check(attempts between 0 and 25),
  next_attempt_at timestamptz not null default now(),
  provider_message_id text,
  last_error text,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint business_notification_outbox_once unique(order_id,event_type,channel)
);
create index if not exists business_notification_outbox_pending_idx
 on public.business_notification_outbox(next_attempt_at)
 where status in ('queued','retry');
alter table public.business_notification_outbox enable row level security;
revoke all on public.business_notification_outbox from public,anon,authenticated;
grant all on public.business_notification_outbox to service_role;
grant select on public.business_notification_outbox to authenticated;
do $$ begin
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='business_notification_outbox' and policyname='admin_outbox_read_v30') then
  create policy admin_outbox_read_v30 on public.business_notification_outbox
  for select to authenticated using ((select private.is_admin()));
 end if;
end $$;
create or replace function public.enqueue_whatsapp_order_paid_v30()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.payment_status='paid' and new.inventory_state='committed'
    and (old.payment_status is distinct from new.payment_status) then
  insert into public.business_notification_outbox(order_id,event_type,channel,status)
  values(new.id,'order_paid','whatsapp','queued')
  on conflict (order_id,event_type,channel) do nothing;
 end if;
 return new;
end; $$;
revoke all on function public.enqueue_whatsapp_order_paid_v30() from public,anon,authenticated;
drop trigger if exists orders_enqueue_whatsapp_order_paid_v30 on public.orders;
create trigger orders_enqueue_whatsapp_order_paid_v30
 after update of payment_status,inventory_state on public.orders
 for each row execute function public.enqueue_whatsapp_order_paid_v30();
