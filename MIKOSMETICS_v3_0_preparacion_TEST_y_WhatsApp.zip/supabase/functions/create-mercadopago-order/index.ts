/** STAGED TEST ONLY — Nunca habilitar con un access token APP_USR. */
import { withSupabase } from 'npm:@supabase/server@1.9.0';
import { isUuid, isTestMode, toCents } from '../_shared/payment-contract.mjs';
const hdr={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,x-client-info,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store'};
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:hdr});
const secured=withSupabase({auth:'user'},async(req,ctx)=>{
  if(req.method!=='POST')return json({error:'method_not_allowed'},405);
  if(!isTestMode(Deno.env.toObject()))return json({error:'test_payments_closed'},503);
  const userId=String(ctx.userClaims?.id??ctx.jwtClaims?.sub??'');
  const email=String(ctx.userClaims?.email??ctx.jwtClaims?.email??'');
  if(!isUuid(userId)||!Deno.env.get('MIKO_TEST_USER_IDS')?.split(',').map(s=>s.trim()).includes(userId))return json({error:'test_user_not_authorized'},403);
  let body:any;try{body=await req.json();}catch{return json({error:'invalid_json'},400);}
  const orderId=String(body?.order_id||'');const token=String(body?.token||'');
  const method=String(body?.payment_method_id||'');const kind=String(body?.payment_method_type||'');
  const installments=Number(body?.installments);
  if(!isUuid(orderId)||!token||token.length>250||!/^[a-z0-9_]{2,50}$/i.test(method)||!['credit_card','debit_card'].includes(kind)||!Number.isInteger(installments)||installments<1||installments>48)return json({error:'invalid_payment_fields'},400);
  const {data:order,error:orderError}=await ctx.supabaseAdmin.from('orders').select('id,user_id,order_number,total,currency,payment_status,inventory_state,reserved_until').eq('id',orderId).maybeSingle();
  if(orderError||!order||order.user_id!==userId)return json({error:'order_not_found'},404);
  if(order.payment_status!=='pending'||order.inventory_state!=='held'||new Date(order.reserved_until).getTime()<=Date.now()||order.currency!=='MXN'||!toCents(order.total))return json({error:'order_not_payable'},409);
  // Una solicitud simultánea no crea una segunda operación; el proveedor recibe la misma idempotency key.
  const {data:oldAttempt}=await ctx.supabaseAdmin.from('payment_attempts').select('id,provider_order_id,status').eq('order_id',orderId).in('status',['pending','authorized','in_process','in_mediation']).order('created_at',{ascending:false}).limit(1).maybeSingle();
  if(oldAttempt)return json({error:'payment_attempt_already_exists',provider_order_id:oldAttempt.provider_order_id||null,action:'verify_in_provider_before_retry'},409);
  const {data:attempt,error:insertError}=await ctx.supabaseAdmin.from('payment_attempts').insert({order_id:orderId,provider:'mercado_pago',status:'pending',amount:order.total,currency:'MXN'}).select('id,idempotency_key').single();
  if(insertError||!attempt)return json({error:'payment_attempt_locked'},409);
  const amount=(toCents(order.total)/100).toFixed(2);
  let provider:any;let response:Response;
  try{
    response=await fetch('https://api.mercadopago.com/v1/orders',{
      method:'POST',headers:{Authorization:`Bearer ${Deno.env.get('MERCADO_PAGO_ACCESS_TOKEN')}`,'Content-Type':'application/json','X-Idempotency-Key':attempt.idempotency_key},
      body:JSON.stringify({type:'online',processing_mode:'automatic',total_amount:amount,external_reference:orderId,
        config:{online:{transaction_security:{validation:'on_fraud_risk',liability_shift:'required'}}},payer:{email},
        transactions:{payments:[{amount,payment_method:{id:method,type:kind,token,installments}}]}})
    });provider=await response.json().catch(()=>({}));
  }catch{
    // El resultado remoto podría ser incierto. Nunca reintentar automáticamente ni cambiar idempotency key.
    return json({error:'provider_outcome_unknown',action:'manual_reconciliation_required'},503);
  }
  if(!response.ok){
    // Error remoto: mantener intento pendiente hasta conciliación. Nunca probar de nuevo con otra clave automáticamente.
    console.error('Mercado Pago provider error:',response.status);
    return json({error:'provider_response_error',action:'manual_reconciliation_required'},502);
  }
  const providerId=String(provider?.id||'');
  if(!providerId)return json({error:'provider_missing_reference',action:'manual_reconciliation_required'},502);
  const payment=provider?.transactions?.payments?.[0];
  const {error:attemptErr}=await ctx.supabaseAdmin.from('payment_attempts').update({provider_order_id:providerId,provider_payment_id:payment?.id?String(payment.id):null,
    provider_order_status:String(provider?.status||''),status_detail:String(provider?.status_detail||'')}).eq('id',attempt.id);
  if(attemptErr)return json({error:'provider_created_but_not_recorded',action:'manual_reconciliation_required'},502);
  await ctx.supabaseAdmin.from('orders').update({payment_provider:'mercado_pago',payment_reference:providerId}).eq('id',orderId).eq('payment_status','pending');
  // No aprobar ni descontar stock aquí: exclusivamente reconciliación HMAC + GET del proveedor + RPC.
  const url=String(payment?.payment_method?.transaction_security?.url||'');
  return json({order_id:orderId,provider_order_id:providerId,status:String(provider?.status||'pending'),
    challenge_required:provider?.status_detail==='pending_challenge',challenge_url:url.startsWith('https://')?url:null,mode:'test'},201);
});
Deno.serve(async req=>req.method==='OPTIONS'?new Response(null,{status:204,headers:hdr}):secured(req));
