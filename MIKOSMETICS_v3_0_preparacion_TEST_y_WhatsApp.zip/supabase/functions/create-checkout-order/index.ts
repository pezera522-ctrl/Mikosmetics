/** STAGED — NO DESPLEGAR sin pruebas y credenciales TEST. */
import { withSupabase } from 'npm:@supabase/server@1.9.0';
import { isUuid, validatedCheckoutItems, isTestMode } from '../_shared/payment-contract.mjs';
const hdr={ 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,x-client-info,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store' };
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:hdr});
const secured=withSupabase({auth:'user'},async(req,ctx)=>{
  if(req.method!=='POST')return json({error:'method_not_allowed'},405);
  if(!isTestMode(Deno.env.toObject()))return json({error:'test_checkout_closed'},503);
  const userId=String(ctx.userClaims?.id??ctx.jwtClaims?.sub??'');
  const email=String(ctx.userClaims?.email??ctx.jwtClaims?.email??'');
  // Evita crear pedidos para usuarios comunes mientras la tienda está en pruebas.
  const allow=Deno.env.get('MIKO_TEST_USER_IDS')?.split(',').map(x=>x.trim())||[];
  if(!isUuid(userId)||!allow.includes(userId))return json({error:'test_user_not_authorized'},403);
  let body:any;try{body=await req.json();}catch{return json({error:'invalid_json'},400);}
  const checkoutKey=String(body?.checkout_key||'');
  if(!isUuid(checkoutKey)||body?.delivery_method!=='personal')return json({error:'invalid_checkout_request'},400);
  let items;try{items=validatedCheckoutItems(body.items);}catch(e){return json({error:String(e.message)},400);}
  const {data,error}=await ctx.supabaseAdmin.rpc('create_checkout_order_v29',{
    p_user_id:userId,p_customer_email:email,p_delivery_method:'personal',p_address_id:null,p_items:items,p_checkout_key:checkoutKey
  });
  if(error){console.error('checkout RPC',error.code);return json({error:'checkout_unavailable_or_out_of_stock'},409);}
  const o=Array.isArray(data)?data[0]:data;
  if(!o?.order_id)return json({error:'checkout_unavailable'},503);
  return json({order_id:o.order_id,order_number:o.order_number,total:o.total,currency:o.currency,reserved_until:o.reserved_until,mode:'test'},201);
});
Deno.serve(async req=>req.method==='OPTIONS'?new Response(null,{status:204,headers:hdr}):secured(req));
