/** STAGED: notificador a número personal, NO desplegar antes de aprobar template META. */
import { withSupabase } from 'npm:@supabase/server@1.9.0';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const digits=(value:string)=>String(value||'').replace(/^\+/,'').replace(/\D/g,'');
const secured=withSupabase({auth:'none'},async(req,ctx)=>{
  if(req.method!=='POST')return json({error:'method_not_allowed'},405);
  const secret=Deno.env.get('MIKO_WORKER_SECRET')||'';
  const provided=req.headers.get('x-miko-worker-secret')||'';
  if(!secret||provided!==secret)return json({error:'unauthorized'},401);
  if(Deno.env.get('MIKO_WHATSAPP_MODE')!=='enabled')return json({error:'whatsapp_sender_disabled'},503);
  const token=Deno.env.get('META_WHATSAPP_TOKEN')||'';
  const senderId=Deno.env.get('META_WHATSAPP_PHONE_NUMBER_ID')||'';
  const from=digits(Deno.env.get('MIKO_WHATSAPP_SENDER_E164')||'');
  const to=digits(Deno.env.get('MIKO_WHATSAPP_ADMIN_E164')||'');
  const template=Deno.env.get('MIKO_WHATSAPP_TEMPLATE')||'';
  if(!token||!/^\d{8,30}$/.test(senderId)||!/^\d{10,15}$/.test(to)||to===from||!/^[a-z][a-z0-9_]{1,100}$/.test(template))
    return json({error:'whatsapp_not_configured_or_same_recipient'},503);
  const {data:jobs,error:jobsErr}=await ctx.supabaseAdmin.from('business_notification_outbox')
    .select('id,order_id,attempts').eq('status','queued').lte('next_attempt_at',new Date().toISOString())
    .order('created_at',{ascending:true}).limit(5);
  if(jobsErr)return json({error:'queue_unavailable'},503);
  let attempted=0,sent=0;
  for(const job of jobs||[]){
    const {data:claim,error:claimErr}=await ctx.supabaseAdmin.from('business_notification_outbox')
      .update({status:'sending',attempts:job.attempts+1,updated_at:new Date().toISOString()})
      .eq('id',job.id).eq('status','queued').select('id').maybeSingle();
    if(claimErr||!claim)continue;
    attempted++;
    const {data:order,error:orderErr}=await ctx.supabaseAdmin.from('orders').select('id,order_number,total,currency,payment_status,inventory_state').eq('id',job.order_id).maybeSingle();
    if(orderErr||!order||order.payment_status!=='paid'||order.inventory_state!=='committed'){
      await ctx.supabaseAdmin.from('business_notification_outbox').update({status:'failed',last_error:'order_not_confirmed'}).eq('id',job.id);
      continue;
    }
    const amount=new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(Number(order.total));
    try{
      const response=await fetch(`https://graph.facebook.com/${Deno.env.get('META_GRAPH_API_VERSION')||'v22.0'}/${senderId}/messages`,{
        method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
        body:JSON.stringify({messaging_product:'whatsapp',to,type:'template',template:{name:template,language:{code:'es_MX'},
          components:[{type:'body',parameters:[{type:'text',text:String(order.order_number)},{type:'text',text:amount}]}]}})
      });
      const body=await response.json().catch(()=>({}));
      if(!response.ok||!body?.messages?.[0]?.id){
        await ctx.supabaseAdmin.from('business_notification_outbox').update({status:'failed',last_error:`meta_http_${response.status}`}).eq('id',job.id);
        continue;
      }
      await ctx.supabaseAdmin.from('business_notification_outbox').update({status:'sent',provider_message_id:String(body.messages[0].id),
        sent_at:new Date().toISOString(),updated_at:new Date().toISOString(),last_error:null}).eq('id',job.id);
      sent++;
    }catch{
      // En caso de timeout el mensaje puede haber salido. No repetir automáticamente.
      await ctx.supabaseAdmin.from('business_notification_outbox').update({status:'failed',last_error:'uncertain_provider_outcome_manual_review'}).eq('id',job.id);
    }
  }
  return json({attempted,sent,mode:'enabled'});
});
Deno.serve(secured);
