/** STAGED — sustituir webhook anterior SOLO después de pruebas TEST y revisión de firma. */
import { withSupabase } from 'npm:@supabase/server@1.9.0';
import { isValidProviderOrder, mapMpOrderStatus, mpSignatureManifest, signatureParts, toCents, isUuid } from '../_shared/payment-contract.mjs';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
function toHex(a:Uint8Array){return [...a].map(b=>b.toString(16).padStart(2,'0')).join('');}
async function validSignature(dataId:string,requestId:string,signature:string,secret:string){
  if(!secret)return false;
  let parts;try{parts=signatureParts(signature);}catch{return false;}
  const manifest=mpSignatureManifest(dataId,requestId,parts.ts);
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const computed=toHex(new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(manifest))));
  // Comparación de tiempo constante, evita filtrar caracteres de la firma.
  let diff=0;for(let i=0;i<64;i++)diff|=computed.charCodeAt(i)^parts.v1.charCodeAt(i);
  return diff===0;
}
async function setEvent(admin:any,eventId:string,status:string,error=''){
  await admin.from('payment_webhook_events').update({processing_status:status,error_message:error||null,processed_at:status==='processed'?new Date().toISOString():null})
    .eq('provider','mercado_pago').eq('provider_event_id',eventId);
}
async function reconcile(admin:any,providerId:string,eventId:string){
  try{
    const token=Deno.env.get('MERCADO_PAGO_ACCESS_TOKEN');
    const response=await fetch(`https://api.mercadopago.com/v1/orders/${encodeURIComponent(providerId)}`,
      {headers:{Authorization:`Bearer ${token}`,Accept:'application/json'}});
    if(!response.ok)throw Error(`provider_lookup_${response.status}`);
    const provider=await response.json();
    const orderId=String(provider?.external_reference||'');
    if(!isUuid(orderId))throw Error('unmatched_external_reference');
    const {data:order,error:orderError}=await admin.from('orders')
      .select('id,total,currency,payment_status,payment_reference,inventory_state')
      .eq('id',orderId).maybeSingle();
    if(orderError||!order)throw Error('order_not_found');
    if(!isValidProviderOrder(provider,{orderId,providerOrderId:providerId,currency:order.currency,total:order.total}))throw Error('provider_total_currency_reference_mismatch');
    const {data:attempt,error:attemptErr}=await admin.from('payment_attempts')
      .select('id,status,provider_order_id,amount,currency').eq('order_id',orderId)
      .in('status',['pending','authorized','in_process','in_mediation','approved','rejected','cancelled','refunded','charged_back'])
      .order('created_at',{ascending:false}).limit(5);
    if(attemptErr||!Array.isArray(attempt))throw Error('payment_attempt_lookup_failed');
    const match=attempt.find((a:any)=>a.provider_order_id===providerId)||attempt.find((a:any)=>a.provider_order_id===null&&a.status==='pending');
    if(!match||toCents(match.amount)!==toCents(order.total)||match.currency!=='MXN')throw Error('payment_attempt_mismatch');
    if(order.payment_reference&&order.payment_reference!==providerId)throw Error('order_provider_reference_mismatch');
    const state=mapMpOrderStatus(provider);
    if(state==='pending'||state==='in_process'){
      await admin.from('payment_attempts').update({provider_order_id:providerId,provider_order_status:String(provider.status||''),
        provider_payment_id:provider.transactions?.payments?.[0]?.id?String(provider.transactions.payments[0].id):null,status:state,status_detail:String(provider.status_detail||'')}).eq('id',match.id);
      await setEvent(admin,eventId,'processed');return;
    }
    const {data:result,error:rpcErr}=await admin.rpc('finalize_checkout_payment_v29',{
      p_order_id:orderId,p_provider_order_id:providerId,p_provider_payment_id:String(provider.transactions?.payments?.[0]?.id||''),
      p_verified_amount:order.total,p_verified_currency:'MXN',p_verified_status:state
    });
    if(rpcErr)throw Error(`manual_reconciliation_required_${rpcErr.code||'rpc'}`);
    const {error:updateErr}=await admin.from('payment_attempts').update({provider_order_id:providerId,
      provider_payment_id:provider.transactions?.payments?.[0]?.id?String(provider.transactions.payments[0].id):null,
      provider_order_status:String(provider.status||''),status:state,status_detail:String(provider.status_detail||''),processed_at:new Date().toISOString()}).eq('id',match.id);
    if(updateErr)throw Error('attempt_update_after_finalize_failed');
    await setEvent(admin,eventId,'processed');
    console.info('MIKOSMETICS webhook reconciled:',result);
  }catch(e){
    // No marcar pagado con incertidumbre de red/proveedor; reservar para revisión manual.
    console.error('MIKOSMETICS reconciliation requires review',String(e).slice(0,170));
    await setEvent(admin,eventId,'error',String(e).slice(0,480));
  }
}
const secured=withSupabase({auth:'none'},async(req,ctx)=>{
  if(req.method!=='POST')return json({error:'method_not_allowed'},405);
  const secret=Deno.env.get('MERCADO_PAGO_WEBHOOK_SECRET');
  const token=Deno.env.get('MERCADO_PAGO_ACCESS_TOKEN');
  if(!secret||!token)return json({error:'webhook_not_configured'},503);
  const url=new URL(req.url),id=url.searchParams.get('data.id')||'',requestId=req.headers.get('x-request-id')||'';
  const signature=req.headers.get('x-signature')||'';
  if(!id||id.length>150||!requestId||!(await validSignature(id,requestId,signature,secret)))return json({error:'invalid_signature'},401);
  let body:any;try{body=await req.json();}catch{return json({error:'invalid_json'},400);}
  if(body?.type!=='order'&&url.searchParams.get('type')!=='order')return json({received:true,ignored:true});
  if(String(body?.data?.id||'')!==id)return json({error:'webhook_id_mismatch'},400);
  const eventId=String(body?.id||`${id}:${body?.action||'order'}:${body?.data?.version||''}`);
  if(eventId.length>240)return json({error:'event_id_invalid'},400);
  const {error:insertError}=await ctx.supabaseAdmin.from('payment_webhook_events').insert({provider:'mercado_pago',provider_event_id:eventId,
    event_type:String(body.action||'order'),processing_status:'received',payload:body});
  if(insertError){
    if(insertError.code==='23505'){
      // No reintentar a ciegas un webhook recibido: un reconciliador audita estados 'error'.
      return json({received:true,duplicate:true});
    }
    return json({error:'notification_not_persisted'},503);
  }
  EdgeRuntime.waitUntil(reconcile(ctx.supabaseAdmin,id,eventId));
  return json({received:true},200);
});
Deno.serve(secured);
