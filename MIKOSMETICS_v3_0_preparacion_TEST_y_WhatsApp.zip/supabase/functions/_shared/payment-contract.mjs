/** Funciones puras v3.0. Prohibido tomar 'aprobado' del cliente. */
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function isUuid(value){return typeof value==='string'&&UUID.test(value);}
export function toCents(amount){
  if(typeof amount!=='string'&&typeof amount!=='number')return null;
  const s=String(amount).trim();
  if(!/^(?:0|[1-9]\d{0,8})(?:\.\d{1,2})?$/.test(s))return null;
  const [pesos,centavos='']=s.split('.');
  const num=Number(pesos)*100+Number(centavos.padEnd(2,'0'));
  return Number.isSafeInteger(num)?num:null;
}
export function validatedCheckoutItems(items){
  if(!Array.isArray(items)||!items.length||items.length>50)throw Error('invalid_cart');
  const used=new Set();
  return items.map(item=>{
    const id=item?.product_id;const quantity=item?.quantity;
    if(!isUuid(id)||!Number.isInteger(quantity)||quantity<1||quantity>99)throw Error('invalid_cart_item');
    if(used.has(id.toLowerCase()))throw Error('duplicate_product_in_cart');
    used.add(id.toLowerCase());return {product_id:id,quantity};
  });
}
export function mapMpOrderStatus(order){
  const status=String(order?.status||'');
  const detail=String(order?.status_detail||'');
  const payment=order?.transactions?.payments?.[0];
  if(!payment)return 'pending';
  if(status==='processed'&&detail==='accredited'&&payment.status==='processed')return 'approved';
  if(status==='action_required'&&detail==='pending_challenge')return 'in_process';
  if(status==='failed')return 'rejected';
  if(['cancelled','canceled'].includes(status))return 'cancelled';
  if(status==='refunded')return 'refunded';
  if(status==='charged_back')return 'charged_back';
  return 'pending';
}
export function isValidProviderOrder(order, expected){
  return !!order && String(order.external_reference)===String(expected.orderId)
    && String(order.id)===String(expected.providerOrderId)
    && String(order.currency||order.currency_id||'')==='MXN'
    && expected.currency==='MXN' && toCents(order.total_amount)!==null
    && toCents(order.total_amount)===toCents(expected.total)
    && toCents(expected.total)>0;
}
export function mpSignatureManifest(dataId,requestId,timestamp){
  if(!dataId||!requestId||!/^\d{8,14}$/.test(String(timestamp)))throw Error('invalid_webhook_headers');
  return `id:${String(dataId).toLowerCase()};request-id:${requestId};ts:${timestamp};`;
}
export function signatureParts(header){
  const ts=String(header||'').split(',').map(x=>x.trim()).find(x=>x.startsWith('ts='))?.slice(3)||'';
  const v1=String(header||'').split(',').map(x=>x.trim()).find(x=>x.startsWith('v1='))?.slice(3)||'';
  if(!/^\d{8,14}$/.test(ts)||!/^[a-f0-9]{64}$/i.test(v1))throw Error('invalid_signature');
  return {ts,v1:v1.toLowerCase()};
}
export function isTestMode(env){return env?.MIKO_PAYMENT_MODE==='test'&&String(env?.MERCADO_PAGO_ACCESS_TOKEN||'').startsWith('TEST-');}
