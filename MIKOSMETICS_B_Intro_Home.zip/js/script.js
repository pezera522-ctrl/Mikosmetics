const $ = (selector) => document.querySelector(selector);
const intro = $('#intro');
const site = $('#site');
const enterButton = $('#enter-store');
const menuButton = $('#menu-toggle');
const nav = $('#main-menu');
const soundButton = $('#sound-toggle');
const slider = $('#explore-slider');
const announcer = $('#live-message');
const mobileQuery = window.matchMedia('(max-width: 820px)');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const readStorage = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
const writeStorage = (key, value) => { try { localStorage.setItem(key, value); } catch {} };
const readSession = (key) => { try { return sessionStorage.getItem(key); } catch { return null; } };
const writeSession = (key, value) => { try { sessionStorage.setItem(key, value); } catch {} };
const announce = (message) => { announcer.textContent = message; };

let soundOn = readStorage('mikosmetics:sound') === 'on';
let audioContext;
function sound() {
  if (!soundOn) return;
  try {
    const AudioContextType = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextType) return;
    audioContext ||= new AudioContextType();
    if (audioContext.state === 'suspended') audioContext.resume().catch(() => {});
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(540, audioContext.currentTime);
    gain.gain.setValueAtTime(.0001, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.028, audioContext.currentTime + .02);
    gain.gain.exponentialRampToValueAtTime(.0001, audioContext.currentTime + .13);
    oscillator.connect(gain).connect(audioContext.destination);
    oscillator.start(); oscillator.stop(audioContext.currentTime + .14);
  } catch { /* El sonido es opcional: nunca impide navegar. */ }
}
function updateSoundButton() {
  soundButton.setAttribute('aria-pressed', String(soundOn));
  soundButton.setAttribute('aria-label', soundOn ? 'Desactivar sonidos' : 'Activar sonidos');
  soundButton.title = soundOn ? 'Desactivar sonidos' : 'Activar sonidos';
}
soundButton.addEventListener('click', () => {
  soundOn = !soundOn;
  writeStorage('mikosmetics:sound', soundOn ? 'on' : 'off');
  updateSoundButton(); sound();
  announce(soundOn ? 'Sonidos activados' : 'Sonidos desactivados');
});
updateSoundButton();

let introTimer;
function finishIntro() {
  clearTimeout(introTimer);
  intro.hidden = true;
  intro.classList.remove('is-exiting');
  site.classList.remove('is-revealing');
  $('#hero-title').focus({ preventScroll: true });
}
function enterStore() {
  if (intro.hidden || intro.classList.contains('is-exiting')) return;
  writeSession('mikosmetics:entered', '1');
  site.inert = false;
  site.removeAttribute('aria-hidden');
  intro.inert = true;
  intro.classList.add('is-exiting');
  site.classList.add('is-revealing');
  sound();
  if (reduceMotion.matches) finishIntro();
  else introTimer = window.setTimeout(finishIntro, 620);
}
enterButton.addEventListener('click', enterStore);
// El contenido permanece accesible si falla JavaScript: la intro empieza oculta en HTML.
const isDirectLink = Boolean(location.hash || location.search);
if (!isDirectLink && readSession('mikosmetics:entered') !== '1') {
  site.inert = true;
  site.setAttribute('aria-hidden', 'true');
  intro.hidden = false;
  window.requestAnimationFrame(() => enterButton.focus({ preventScroll: true }));
}

function setMenu(open, returnFocus = false) {
  const isOpen = mobileQuery.matches && open;
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Cerrar menú' : 'Abrir menú');
  nav.classList.toggle('is-open', isOpen);
  nav.inert = mobileQuery.matches && !isOpen;
  if (returnFocus) menuButton.focus();
}
menuButton.addEventListener('click', () => {
  const next = menuButton.getAttribute('aria-expanded') !== 'true';
  setMenu(next); sound();
});
mobileQuery.addEventListener('change', () => setMenu(false));
nav.addEventListener('click', (event) => {
  if (event.target.closest('a')) setMenu(false);
});
document.addEventListener('click', (event) => {
  if (mobileQuery.matches && !event.target.closest('.header')) setMenu(false);
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && menuButton.getAttribute('aria-expanded') === 'true') setMenu(false, true);
});
setMenu(false);

function scrollCards(direction) {
  const card = slider.querySelector('.editorial-card');
  if (!card) return;
  const gap = parseFloat(getComputedStyle(slider).gap) || 0;
  slider.scrollBy({ left: direction * (card.getBoundingClientRect().width + gap), behavior: reduceMotion.matches ? 'auto' : 'smooth' });
  sound();
}
$('#slide-prev').addEventListener('click', () => scrollCards(-1));
$('#slide-next').addEventListener('click', () => scrollCards(1));
$('#year').textContent = String(new Date().getFullYear());

window.addEventListener('error', (event) => {
  if (event.target !== window) return;
  console.error('Error de interfaz:', event.message);
  announce('Ocurrió un error en la interfaz. Puedes recargar la página.');
});
