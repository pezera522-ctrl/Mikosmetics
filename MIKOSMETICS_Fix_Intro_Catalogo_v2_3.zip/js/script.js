/** MIKOSMETICS — punto de entrada, versión 2.3. */
import { initStorefront } from './storefront.js';
import { initShell } from './ui-shell.js';

// Los servicios deben suscribirse antes del primer evento de navegación.
initStorefront();
initShell();
