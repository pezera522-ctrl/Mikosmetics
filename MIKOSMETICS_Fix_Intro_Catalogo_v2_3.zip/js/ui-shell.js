/**
 * MIKOSMETICS — UI shell v2.2: auténtico SVG, secuencia MIKO / emblema / SMETICS
 * Contrato HTML: index.html (Storefront 2), CSS: css/style.css (Storefront 2).
 * Responsabilidad exclusiva: intro SVG, routing, navegación accesible y feedback.
 * NO contiene productos ficticios, autenticación simulada ni lógica de cobros.
 *
 * Contrato estable para módulos de negocio posteriores:
 *   window.MIKOSMETICS_UI.route       -> { screen, id, pathname }
 *   window.MIKOSMETICS_UI.navigate(href)
 *   window.MIKOSMETICS_UI.toast(text, type)
 *   window.MIKOSMETICS_UI.updateCartCount(quantity)
 *   window.addEventListener('mikosmetics:route', (event) => {
 *     const {screen, id, signal} = event.detail;
 *     // signal se aborta al abandonar la pantalla.
 *   });
 * Los módulos de datos deberán cargarse ANTES del despacho de la ruta inicial.
 */

const SVG_NS = 'http://www.w3.org/2000/svg';
const LOGO_URL = 'assets/logo-mikosmetics.svg';
const INTRO_HOME_ONLY = true;
const INTRO_FINAL_GLOW_MS = 320;
const INTRO_EXIT_MS = 620;

const SCREENS = new Set([
  'inicio', 'productos', 'promociones', 'producto', 'carrito',
  'acceso', 'registro', 'recuperar', 'restablecer', 'cuenta',
  'direcciones', 'pedidos', 'pedido', 'checkout', 'pago',
  'admin', 'ayuda', 'no-encontrado',
]);
const AUTH_LINKS = new Set(['acceso', 'registro', 'recuperar', 'restablecer']);

const dom = Object.freeze({
  $: (selector, root = document) => root.querySelector(selector),
  $$: (selector, root = document) => [...root.querySelectorAll(selector)],
});
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const nodes = {
  intro: dom.$('#intro'),
  enter: dom.$('#intro-enter'),
  stage: dom.$('.intro__stage'),
  trace: dom.$('#intro-trace'),
  app: dom.$('#app'),
  skipLink: dom.$('.skip-link'),
  main: dom.$('#main'),
  menu: dom.$('#mobile-menu'),
  toggle: dom.$('#menu-toggle'),
  close: dom.$('#menu-close'),
  shade: dom.$('#menu-shade'),
  announcer: dom.$('#screen-announcer'),
  toast: dom.$('#toast-region'),
  scroller: dom.$('#featured-list'),
  scrollerPrevious: dom.$('#featured-prev'),
  scrollerNext: dom.$('#featured-next'),
  cartCount: dom.$('#header-cart-count'),
};

let activeRoute = Object.freeze({ screen: 'inicio', id: '', pathname: '/inicio' });
let routeController = null;
let enterStarted = false;
let introVisible = false;
let introAbortController = null;
let introTracePromise = null;
let menuOpen = false;
let menuFocusReturn = null;
let pageEnterTimer = 0;
const focusables = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

function wait(ms, signal) {
  if (signal?.aborted) return Promise.resolve(false);
  return new Promise((resolve) => {
    let settled = false;
    const finish = (ok) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener('abort', stop);
      resolve(ok);
    };
    const stop = () => finish(false);
    const timer = setTimeout(() => finish(true), ms);
    signal?.addEventListener('abort', stop, { once: true });
  });
}

function nextFrame() {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

function announce(message) {
  if (!nodes.announcer) return;
  nodes.announcer.textContent = '';
  requestAnimationFrame(() => { nodes.announcer.textContent = message; });
}

function toast(message, type = 'info') {
  if (!nodes.toast || typeof message !== 'string' || !message.trim()) return;
  const item = document.createElement('div');
  item.className = `toast ${type === 'error' ? 'toast--error' : type === 'success' ? 'toast--success' : ''}`.trim();
  item.textContent = message.slice(0, 350);
  item.setAttribute('role', type === 'error' ? 'alert' : 'status');
  nodes.toast.append(item);
  while (nodes.toast.children.length > 3) nodes.toast.firstElementChild?.remove();
  setTimeout(() => item.remove(), type === 'error' ? 7000 : 4400);
}

function updateCartCount(quantity) {
  const n = Number.isSafeInteger(Number(quantity)) && Number(quantity) >= 0 ? Number(quantity) : 0;
  if (nodes.cartCount) nodes.cartCount.textContent = n > 99 ? '99+' : String(n);
  const cartLink = dom.$('.cart-shortcut');
  if (cartLink) cartLink.setAttribute('aria-label', `Abrir carrito: ${n} ${n === 1 ? 'artículo' : 'artículos'}`);
}

function normalizeHash(hash = window.location.hash) {
  const source = typeof hash === 'string' && hash.startsWith('#') ? hash.slice(1) : '/inicio';
  const trimmed = source.split('?')[0].replace(/\/{2,}/g, '/');
  const parts = trimmed.replace(/^\/+|\/+$/g, '').split('/');
  let screen = parts[0] || 'inicio';
  let id = '';
  try {
    id = parts.length > 1 ? decodeURIComponent(parts.slice(1).join('/')) : '';
  } catch {
    screen = 'no-encontrado';
  }
  if (!SCREENS.has(screen)) screen = 'no-encontrado';
  if ((screen === 'producto' || screen === 'pedido') && !id) screen = 'no-encontrado';
  if (screen !== 'producto' && screen !== 'pedido' && parts.length > 1) screen = 'no-encontrado';
  return Object.freeze({ screen, id, pathname: `/${screen}${id ? `/${encodeURIComponent(id)}` : ''}` });
}

function currentPageTitle(page) {
  const heading = page?.querySelector('h1');
  return heading?.textContent?.trim().replace(/\s+/g, ' ') || 'MIKOSMETICS';
}

function currentPageHeading(page) {
  return page?.querySelector('h1') || page;
}

function markLinks(route) {
  for (const a of dom.$$('[data-link][href^="#/"]')) {
    const pathname = a.getAttribute('href').slice(1);
    const active = pathname === `/${route.screen}` ||
      (route.screen === 'producto' && pathname === '/productos') ||
      (AUTH_LINKS.has(route.screen) && pathname === '/cuenta') ||
      (route.screen === 'pedido' && pathname === '/pedidos');
    if (active) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  }
}

function navigate(path) {
  if (typeof path !== 'string' || !path.trim()) return;
  const next = path.startsWith('#') ? path : `#${path.startsWith('/') ? path : `/${path}`}`;
  if (window.location.hash === next) {
    applyRoute({ moveFocus: true });
    return;
  }
  window.location.hash = next;
}

function showPage(route, { moveFocus = true } = {}) {
  const requested = dom.$(`#page-${route.screen}`);
  const page = requested || dom.$('#page-no-encontrado');
  if (!page) throw new Error('No existe la pantalla de navegación requerida.');

  if (routeController) routeController.abort();
  routeController = new AbortController();
  const previous = activeRoute;
  activeRoute = route;

  if (pageEnterTimer) window.clearTimeout(pageEnterTimer);
  for (const element of dom.$$('[data-page]')) {
    element.classList.remove('is-entering');
    element.hidden = element !== page;
  }
  if (!reducedMotion.matches && previous.pathname !== route.pathname) {
    page.classList.add('is-entering');
    pageEnterTimer = window.setTimeout(() => page.classList.remove('is-entering'), 800);
  }
  markLinks(route);
  closeMenu({ restoreFocus: false });
  document.title = `${currentPageTitle(page)} — MIKOSMETICS`;
  document.documentElement.scrollTop = 0;
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });

  if (moveFocus && !introVisible && !nodes.app?.inert) {
    const h = currentPageHeading(page);
    if (h && !h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1');
    h?.focus({ preventScroll: true });
  }
  announce(currentPageTitle(page));
  window.dispatchEvent(new CustomEvent('mikosmetics:route', {
    detail: { screen: route.screen, id: route.id, pathname: route.pathname, signal: routeController.signal },
  }));
  updateScrollerButtons();
}

function applyRoute({ moveFocus = true } = {}) {
  const route = normalizeHash();
  if (introVisible && route.screen !== 'inicio') endIntro({ focus: false });
  showPage(route, { moveFocus });
}

function openMenu() {
  if (menuOpen || !nodes.menu || !nodes.toggle || introVisible) return;
  menuOpen = true;
  menuFocusReturn = document.activeElement;
  nodes.shade.hidden = false;
  nodes.menu.hidden = false;
  nodes.menu.classList.remove('is-opening');
  // Force a new transition even when reopening in the same frame.
  void nodes.menu.offsetWidth;
  if (!reducedMotion.matches) nodes.menu.classList.add('is-opening');
  nodes.toggle.setAttribute('aria-expanded', 'true');
  nodes.toggle.setAttribute('aria-label', 'Cerrar menú');
  document.body.classList.add('menu-open');
  if (nodes.main) nodes.main.inert = true;
  const footer = dom.$('.footer');
  if (footer) footer.inert = true;
  (nodes.close || nodes.menu.querySelector('a'))?.focus({ preventScroll: true });
}

function closeMenu({ restoreFocus = true } = {}) {
  if (!menuOpen) return;
  menuOpen = false;
  nodes.menu.hidden = true;
  nodes.menu.classList.remove('is-opening');
  nodes.shade.hidden = true;
  nodes.toggle.setAttribute('aria-expanded', 'false');
  nodes.toggle.setAttribute('aria-label', 'Abrir menú');
  document.body.classList.remove('menu-open');
  if (nodes.main) nodes.main.inert = Boolean(introVisible);
  const footer = dom.$('.footer');
  if (footer) footer.inert = Boolean(introVisible);
  if (restoreFocus) (menuFocusReturn?.isConnected ? menuFocusReturn : nodes.toggle)?.focus({ preventScroll: true });
  menuFocusReturn = null;
}

function trapMenuFocus(event) {
  if (!menuOpen || event.key !== 'Tab') return;
  const choices = [nodes.toggle, ...dom.$$(focusables, nodes.menu)]
    .filter((node) => node && !node.closest('[hidden]') && !node.disabled && !node.hidden);
  if (!choices.length) return;
  const first = choices[0];
  const last = choices[choices.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

function updateScrollerButtons() {
  const { scroller: scroller, scrollerPrevious: prev, scrollerNext: next } = nodes;
  if (!scroller || !prev || !next) return;
  const available = scroller.scrollWidth > scroller.clientWidth + 5;
  prev.disabled = !available || scroller.scrollLeft <= 3;
  next.disabled = !available || scroller.scrollLeft >= scroller.scrollWidth - scroller.clientWidth - 4;
}

function bindNavigation() {
  nodes.toggle?.addEventListener('click', () => menuOpen ? closeMenu() : openMenu());
  nodes.close?.addEventListener('click', () => closeMenu());
  nodes.shade?.addEventListener('click', () => closeMenu());
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menuOpen) { event.preventDefault(); closeMenu(); }
    trapMenuFocus(event);
  });
  dom.$$('#mobile-menu a[data-link]').forEach((link) => link.addEventListener('click', () => closeMenu({ restoreFocus: false })));
  window.addEventListener('hashchange', () => applyRoute());
  // hashchange also fires on back/forward between hash routes; no duplicate dispatch.
  window.addEventListener('resize', () => {
    if (menuOpen && window.matchMedia('(min-width: 981px)').matches) closeMenu({ restoreFocus: false });
    updateScrollerButtons();
  }, { passive: true });

  nodes.scrollerPrevious?.addEventListener('click', () => {
    nodes.scroller?.scrollBy({ left: -Math.max(240, nodes.scroller.clientWidth * .8), behavior: reducedMotion.matches ? 'instant' : 'smooth' });
  });
  nodes.scrollerNext?.addEventListener('click', () => {
    nodes.scroller?.scrollBy({ left: Math.max(240, nodes.scroller.clientWidth * .8), behavior: reducedMotion.matches ? 'instant' : 'smooth' });
  });
  nodes.scroller?.addEventListener('scroll', updateScrollerButtons, { passive: true });
  if (typeof ResizeObserver !== 'undefined' && nodes.scroller) {
    new ResizeObserver(updateScrollerButtons).observe(nodes.scroller);
  }
  if (typeof MutationObserver !== 'undefined' && nodes.scroller) {
    new MutationObserver(updateScrollerButtons).observe(nodes.scroller, { childList: true });
  }
  const year = dom.$('#year');
  if (year) year.textContent = String(new Date().getFullYear());
}

/**
 * Crea una copia de trazos (no cambia el archivo SVG original).
 * Copia únicamente formas geométricas y las transformaciones de sus ancestros.
 * No usa texto inventado, anillos, canvas, imágenes rasterizadas ni bibliotecas 3D.
 */
function cloneShape(shape, root) {
  const validTag = /^(path|rect|circle|ellipse|line|polyline|polygon)$/;
  if (!validTag.test(shape.localName)) return null;
  const allowedGeometry = new Set(['d', 'x', 'y', 'x1', 'x2', 'y1', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'width', 'height', 'points', 'pathLength']);
  const leaf = document.createElementNS(SVG_NS, shape.localName);
  for (const attr of shape.attributes) if (allowedGeometry.has(attr.name)) leaf.setAttribute(attr.name, attr.value);
  leaf.classList.add('intro__stroke');
  let outer = leaf;
  let ancestor = shape.parentElement;
  while (ancestor && ancestor !== root) {
    const group = document.createElementNS(SVG_NS, 'g');
    const transform = ancestor.getAttribute('transform');
    if (transform) group.setAttribute('transform', transform);
    group.append(outer);
    outer = group;
    ancestor = ancestor.parentElement;
  }
  // Some SVGs put a transform on the path itself, which must be preserved.
  if (shape.hasAttribute('transform')) leaf.setAttribute('transform', shape.getAttribute('transform'));
  return { outer, leaf };
}

function sanitizeViewBox(root) {
  const raw = root.getAttribute('viewBox');
  if (raw && /^\s*-?[\d.]+(?:[\s,]+-?[\d.]+){3}\s*$/.test(raw)) return raw.trim();
  const w = Number.parseFloat(root.getAttribute('width'));
  const h = Number.parseFloat(root.getAttribute('height'));
  if (w > 0 && h > 0 && w < 100000 && h < 100000) return `0 0 ${w} ${h}`;
  return null;
}

/**
 * El logotipo original proporcionado por MIKOSMETICS (1000×1000) contiene 23
 * formas: M-I-K-O arriba, la figura central y S-M-E-T-I-C-S abajo.
 * No usamos caracteres tipográficos ni reconstruimos el dibujo: índice =
 * posición de cada forma en el SVG ORIGINAL, comprobada en navegador.
 * Si se sustituye el SVG, se usa una progresión genérica basada en geometría
 * en vez de asignar índices incorrectos a otro dibujo.
 */
const BRAND_GLOW_INDICES = new Set([0, 1, 2, 9, 3, 4, 5, 15, 22, 21, 20, 19, 18, 17, 16]);
const BRAND_SEQUENCE = Object.freeze([
  { name: 'M',     at: 0,    indices: [0] },
  { name: 'I',     at: 170,  indices: [1] },
  { name: 'K',     at: 335,  indices: [2] },
  { name: 'O',     at: 500,  indices: [9, 10] },
  { name: 'emblema', at: 665, indices: [3, 4, 5, 15, 6, 8, 14, 13, 11, 7, 12] },
  { name: 'S',     at: 1020, indices: [22] },
  { name: 'M',     at: 1170, indices: [21] },
  { name: 'E',     at: 1320, indices: [20] },
  { name: 'T',     at: 1470, indices: [19] },
  { name: 'I',     at: 1620, indices: [18] },
  { name: 'C',     at: 1770, indices: [17] },
  { name: 'S',     at: 1920, indices: [16] },
]);

/** Centra el ARTE VISIBLE, no el lienzo vacío de 1000×1000. */
function alignAuthenticLogo() {
  if (!nodes.stage) return;
  const logo = dom.$('.intro__logo', nodes.stage);
  if (!logo || !nodes.trace) return;
  // Caja visible de la obra: aprox. x226–818, y295–686 (592×391).
  // Conserva intacto el archivo y las proporciones originales.
  nodes.stage.style.aspectRatio = '592 / 416';
  logo.style.position = 'absolute';
  logo.style.width = '168%';
  logo.style.maxWidth = 'none';
  logo.style.height = 'auto';
  logo.style.left = '50%';
  logo.style.top = '50%';
  logo.style.transform = 'translate(-52.2%, -49.1%)';
  nodes.trace.style.position = 'absolute';
  const traceSvg = nodes.trace.querySelector('svg');
  if (traceSvg) {
    traceSvg.style.position = 'absolute';
    traceSvg.style.left = '50%';
    traceSvg.style.top = '50%';
    traceSvg.style.width = '168%';
    traceSvg.style.height = 'auto';
    traceSvg.style.maxWidth = 'none';
    traceSvg.style.transform = 'translate(-52.2%, -49.1%)';
  }
}

async function buildTraceFromOriginal(signal) {
  if (!nodes.trace) return null;
  const response = await fetch(LOGO_URL, { signal, cache: 'force-cache' });
  if (!response.ok) throw new Error('No fue posible leer el SVG del logotipo.');
  const svgMarkup = await response.text();
  if (svgMarkup.length > 1500000) throw new Error('SVG demasiado grande para la animación.');
  const parsed = new DOMParser().parseFromString(svgMarkup, 'image/svg+xml');
  const root = parsed.documentElement;
  if (root.localName !== 'svg' || parsed.querySelector('parsererror')) throw new Error('El logo no es SVG válido.');
  const box = sanitizeViewBox(root);
  if (!box) throw new Error('El SVG no declara dimensiones para alinear los contornos.');

  const sourceShapes = [...root.querySelectorAll('path, rect, circle, ellipse, line, polyline, polygon')]
    .filter((shape) => !shape.closest('defs, clipPath, mask, marker, pattern, symbol, filter'));
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.classList.add('intro__trace-svg');
  svg.setAttribute('viewBox', box);
  svg.setAttribute('preserveAspectRatio', root.getAttribute('preserveAspectRatio') || 'xMidYMid meet');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  const entries = sourceShapes.map((source, index) => {
    const result = cloneShape(source, root);
    if (!result) return null;
    svg.append(result.outer);
    return { ...result, index };
  }).filter(Boolean);
  nodes.trace.replaceChildren(svg);
  alignAuthenticLogo();
  await nextFrame();
  if (signal.aborted) return null;

  const usable = [];
  for (const entry of entries) {
    const { leaf } = entry;
    let length;
    let bounds;
    try { length = leaf.getTotalLength(); bounds = leaf.getBBox(); } catch { continue; }
    if (!Number.isFinite(length) || length < 1.5 || !bounds.width || !bounds.height) continue;
    usable.push({ ...entry, length, bounds });
  }
  if (!usable.length) { nodes.trace.replaceChildren(); return null; }

  const authentic = sourceShapes.length === 23 && box.replace(/[\s,]+/g, ' ') === '0 0 1000 1000'
    && usable.some(e => e.index === 0 && e.bounds.x > 235 && e.bounds.x < 250)
    && usable.some(e => e.index === 9 && e.bounds.x > 475 && e.bounds.x < 490)
    && usable.some(e => e.index === 22 && e.bounds.x > 220 && e.bounds.x < 235);

  // El orden de los trazos está basado en el dibujo real y no en texto recreado.
  const ordered = [];
  if (authentic) {
    for (const group of BRAND_SEQUENCE) {
      group.indices.forEach((index, groupIndex) => {
        const item = usable.find(e => e.index === index);
        if (item) ordered.push({ ...item, delay: group.at + (group.name === 'emblema' ? groupIndex * 26 : groupIndex * 35), label: group.name });
      });
    }
  } else {
    // El usuario puede sustituir el logo sin hacer estallar la navegación.
    usable.sort((a, b) => (a.bounds.y - b.bounds.y) * .45 + a.bounds.x - b.bounds.x);
    usable.forEach((item, index) => ordered.push({ ...item, delay: index * 100, label: 'trazado' }));
  }

  let finishMs = 0;
  for (const { leaf, index, length, delay, label } of ordered) {
    const duration = Math.max(275, Math.min(570, 150 + length * .39));
    leaf.style.setProperty('--trace-length', String(Math.ceil(length + 2)));
    leaf.style.setProperty('--trace-delay', `${Math.round(delay)}ms`);
    leaf.style.setProperty('--trace-duration', `${Math.round(duration)}ms`);
    leaf.style.setProperty('--trace-width', '1.55');
    leaf.setAttribute('data-glyph', label);
    // Duplicación limitada: resplandor solamente en letras principales + silueta.
    const glowEligible = authentic ? BRAND_GLOW_INDICES.has(index) : ordered.length <= 16;
    if (glowEligible) {
      const glow = leaf.cloneNode(true);
      glow.removeAttribute('data-glyph');
      glow.classList.add('intro__stroke--glow');
      glow.style.setProperty('--trace-glow-width', '3.1');
      leaf.parentNode?.insertBefore(glow, leaf);
    }
    finishMs = Math.max(finishMs, delay + duration);
  }
  for (const entry of entries) if (!ordered.some(e => e.leaf === entry.leaf)) entry.outer.remove();
  svg.dataset.traceMode = authentic ? 'brand-letters' : 'geometric-fallback';
  return Math.ceil(finishMs) + 35;
}

function hideBackgroundDuringIntro(isOpen) {
  if (nodes.app) nodes.app.inert = isOpen;
  if (nodes.skipLink) nodes.skipLink.inert = isOpen;
  document.body.classList.toggle('intro-open', isOpen);
  if (nodes.app) nodes.app.setAttribute('aria-hidden', isOpen ? 'true' : 'false');
  introVisible = isOpen;
}

function endIntro({ focus = true } = {}) {
  if (!introVisible && nodes.intro?.hidden) return;
  introAbortController?.abort();
  nodes.intro.hidden = true;
  nodes.intro.classList.remove('is-tracing', 'is-illuminated', 'is-leaving');
  hideBackgroundDuringIntro(false);
  if (focus) {
    const page = dom.$(`[data-page="${activeRoute.screen}"]`) || dom.$('#page-inicio');
    const target = currentPageHeading(page);
    if (target) { target.setAttribute('tabindex', '-1'); target.focus({ preventScroll: true }); }
    announce(currentPageTitle(page));
  }
}

async function enterSite() {
  if (enterStarted || !introVisible) return;
  enterStarted = true;
  nodes.enter.disabled = true;
  const signal = introAbortController.signal;
  try {
    if (!reducedMotion.matches) {
      // Wait a short bounded time for the SVG to become traceable. No artificial idle delay.
      // Espera acotada: evita saltarse el trazo si el SVG tarda un poco en cargar.
      const traceDuration = await Promise.race([introTracePromise, wait(2400, signal).then(() => null)]);
      if (signal.aborted) return;
      if (traceDuration && nodes.trace?.children.length) {
        const logo = dom.$('.intro__logo', nodes.stage);
        if (logo) { logo.style.transition = 'filter 180ms ease-out'; logo.style.filter = 'brightness(.14)'; }
        nodes.intro.classList.add('is-tracing');
        const finished = await wait(traceDuration, signal);
        if (!finished) return;
      }
      const logo = dom.$('.intro__logo', nodes.stage);
      if (logo) { logo.style.transition = 'filter 310ms ease-out'; logo.style.filter = 'brightness(1)'; }
      nodes.intro.classList.add('is-illuminated');
      if (!(await wait(INTRO_FINAL_GLOW_MS, signal))) return;
      nodes.intro.classList.add('is-leaving');
      if (!(await wait(INTRO_EXIT_MS, signal))) return;
    }
  } catch {
    // Logo failure must never trap a customer on the intro screen.
  } finally {
    endIntro({ focus: true });
  }
}

function prepareIntro() {
  if (!nodes.intro || !nodes.enter || !nodes.app) return;
  const route = normalizeHash();
  // Solo la URL raíz muestra la intro. Las rutas hash y la navegación interna no la repiten.
  const shouldShow = route.screen === 'inicio' && (!window.location.hash || window.location.hash === '#');
  // Reloading the home shows the intro again; navigating within the site does not.
  if (!shouldShow) { nodes.intro.hidden = true; hideBackgroundDuringIntro(false); return; }
  nodes.intro.hidden = false;
  hideBackgroundDuringIntro(true);
  introAbortController = new AbortController();
  const signal = introAbortController.signal;
  introTracePromise = buildTraceFromOriginal(signal).catch(() => null);
  nodes.enter.addEventListener('click', enterSite, { once: true });
  // Sin autofoco: focus-visible en carga dibujaría un recuadro invasivo.
  // Tab lleva al único botón accesible mientras la tienda permanece inerte.
}

function installPublicAPI() {
  const publicAPI = Object.freeze({
    navigate,
    toast,
    updateCartCount,
    get route() { return activeRoute; },
  });
  Object.defineProperty(window, 'MIKOSMETICS_UI', { value: publicAPI, configurable: false, writable: false });
}

function initialize() {
  if (!nodes.main || !nodes.app) {
    document.body.textContent = 'No se pudo iniciar MIKOSMETICS. Recarga la página.';
    return;
  }
  installPublicAPI();
  bindNavigation();
  prepareIntro();
  // Route is dispatched after the UI is ready. Services installed in later modules
  // must subscribe before this point; they can also read MIKOSMETICS_UI.route.
  applyRoute({ moveFocus: false });
  updateCartCount(0);
}

export { initialize as initShell, navigate, toast, updateCartCount, normalizeHash };
