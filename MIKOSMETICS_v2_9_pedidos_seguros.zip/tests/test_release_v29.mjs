import assert from 'node:assert/strict';
import {RELEASE,BUILD} from '../js/release.js';
import {paymentGate} from '../js/checkout-contract.js';
assert.equal(RELEASE,'2.9');
assert.equal(BUILD,29);
assert.equal(paymentGate.enabled,false);
console.log('PASS: versión centralizada v2.9 y pagos cerrados.');
