# MIKOSMETICS v2.7 — Checkout de revisión (NO cobro)

## Alcance verificado
- Parte de la versión local v2.6, incluye todos los archivos completos.
- Enlace activo desde carrito cuando la selección tiene stock válido.
- Validación fresca vía Supabase REST con id de producto, fecha actual y cantidad.
- Carrito se conserva al iniciar sesión. Dirección seleccionable si existe sesión.
- Envío sin tarifa: no se presenta como gratis. Entrega personal sin horario/dirección final: no se presenta como confirmada.
- Sin POST a orders, sin invocar create-mercadopago-order, sin capturar tarjetas, sin modificar esquema RLS.

## Hallazgos críticos revisados en código remoto (bloquean pago)
1. `create_checkout_order_internal` verifica stock con SELECT FOR SHARE, pero no aparta ni descuenta definitivamente.
2. `mercadopago-webhook` cambia order_status de pedidos pagados a Pedido confirmado sin preservar pasos logísticos y sin verificar suficientemente errores UPDATE.
3. `create-mercadopago-order` puede marcar un intento como approved sin que el pedido se haya confirmado por webhook. El índice de intento activo no cubre approved: puede aparecer una segunda solicitud de pago.
4. No se ha verificado un reto 3DS de punta a punta en TEST ni una clave pública de Mercado Pago válida y entorno coherente.
5. **Permisos RPC verificados:** `create_checkout_order_internal` NO es ejecutable por `anon` ni `authenticated`; solo `service_role`, por lo que no observé exposición directa del SECURITY DEFINER.
6. La tarifa de shipping no está configurada y la ubicación/horario de entrega personal no están confirmados.

## Próximo bloque requerido: v2.8 servidor de pagos
Definir modelo transaccional para stock (reserva temporal o descuento al crear orden con liberación y conciliación), bloqueo idempotente al confirmar, estados de pago/logística independientes, webhook con reintentos/reproceso y reconciliación. Auditar y probar carreras/reenvíos. Recién después activar Brick/Orders TEST con clave pública correcta y hacer challenge 3DS.

## Importante
No hagas pagos de verdad. Este ZIP no habilita cobros, no modifica tu Supabase y no crea pedidos internos. Los importes mostrados son estimaciones de UI, NO precio final.
