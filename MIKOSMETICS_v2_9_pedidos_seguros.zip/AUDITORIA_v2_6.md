# MIKOSMETICS v2.6 — Estado de auditoría

## Alcance
Reconstrucción coherente del frontend con `index.html` completo, estilos, seis módulos ES y el SVG original intacto. URLs internas por hash para GitHub Pages. No se modifican datos ni políticas de Supabase.

## Hallazgos corregidos
- La versión v2.5 estaba empaquetada de forma parcial: cinco archivos, sin el HTML completo ni todos los módulos. La función de navegación de cuenta heredada tenía llaves/flujo incorrectos; fue reconstruida. La causa exacta de la falla observada en Safari no pudo capturarse con una consola de ese dispositivo.
- Cualquier fallo de un módulo opcional (catálogo, cuenta o administración) deja la navegación accesible y muestra un mensaje; el HTML tiene un error visible si la aplicación no arranca.
- CSS y JS llevan versión `?v=26` para evitar mezclar assets antiguos; se conserva `assets/logo-mikosmetics.svg` sin cambios de trazos.
- Nuevo hero editorial, rediseño responsive y controles con foco/estados visibles.
- Inicio de sesión y administración siguen sujetos a Auth + RLS, no al correo en código JavaScript.
- Los precios cobrados, el inventario y los cambios logísticos no se autorizan en frontend. Cobros reales siguen **desactivados**.

## Verificado
- Verificación de estructura HTML, elementos de referencia, sintaxis de seis módulos JavaScript e imports existentes.
- Pruebas de navegador **con datos simulados** a 320 × 700, 390 × 844, 430 × 932, 844 × 390, 1440 × 900: intro, menú, navegación y ausencia de desbordamiento horizontal.
- Pruebas de integración aislada con cuatro módulos, vistas cuenta, acceso, admin, productos, recuperar y direcciones sin errores JS observados.
- Rol `admin` accede a controles simulados; rol `customer` no accede; vista de pedidos de prueba y editor funcional con datos simulados.
- Vistas renderizadas con el SVG original. Estos renders no constituyen una prueba real de Safari.

## Pendiente de prueba REAL
- Arranque de módulos en Safari del iPhone con caché limpia. El navegador automatizado disponible bloqueó navegar a URLs locales, por ello no se ejecutó `index.html` por HTTP en una sesión real.
- Login, creación/edición de producto, fotos, perfil y consultas de pedidos con la sesión administradora auténtica.
- Correos de recuperación, disponibilidad del CDN de Supabase y políticas de datos en el entorno de ejecución real.
- Auditoría transaccional de inventario, webhook, estados e idempotencia de Mercado Pago antes de cualquier cobro real.

## Instalación
El ZIP tiene archivos con rutas relativas a la raíz del proyecto: `index.html`, `css/`, `js/`, `assets/`, `.nojekyll`, `tests/`. Debe extraerse **en la raíz del repositorio**.

Verificación ligera: `python3 tests/validate_release.py`.
