-- MIKOSMETICS v2.9 — fase segura de pedidos. NO activa pagos.
-- Crear con Supabase migrations; no contiene datos/credenciales ni cobra.
-- PRECONDICIÓN: backend de cobros y creación de pedidos permanece cerrado.

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS inventory_state text NOT NULL DEFAULT 'unreserved',
  ADD COLUMN IF NOT EXISTS reserved_until timestamptz,
  ADD COLUMN IF NOT EXISTS checkout_intent_hash text;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.orders'::regclass AND conname='orders_inventory_state_v29_check') THEN
    ALTER TABLE public.orders ADD CONSTRAINT orders_inventory_state_v29_check
      CHECK (inventory_state IN ('unreserved','held','committed','released'));
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.checkout_inventory_reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE RESTRICT,
  quantity integer NOT NULL CHECK(quantity BETWEEN 1 AND 99),
  state text NOT NULL DEFAULT 'held' CHECK (state IN ('held','committed','released')),
  reserved_until timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (order_id, product_id)
);
CREATE INDEX IF NOT EXISTS checkout_reservations_live_v29
  ON public.checkout_inventory_reservations(product_id, reserved_until)
  WHERE state='held';
CREATE INDEX IF NOT EXISTS checkout_reservations_order_v29
  ON public.checkout_inventory_reservations(order_id);
ALTER TABLE public.checkout_inventory_reservations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.checkout_inventory_reservations FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.checkout_inventory_reservations TO service_role;

-- Proteger la integridad: administrador no puede bajar stock por debajo de reservas vivas.
CREATE OR REPLACE FUNCTION public.check_held_inventory_v29()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE v_held bigint;
BEGIN
 IF NEW.stock < 0 THEN RAISE EXCEPTION 'negative_stock' USING ERRCODE='22023'; END IF;
 SELECT coalesce(sum(r.quantity),0) INTO v_held
 FROM public.checkout_inventory_reservations r
 WHERE r.product_id=OLD.id AND r.state='held' AND r.reserved_until>now();
 IF NEW.stock < v_held THEN RAISE EXCEPTION 'stock_below_active_reservations' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.check_held_inventory_v29() FROM PUBLIC,anon,authenticated;
DROP TRIGGER IF EXISTS check_held_inventory_v29_trigger ON public.products;
CREATE TRIGGER check_held_inventory_v29_trigger BEFORE UPDATE OF stock ON public.products
FOR EACH ROW EXECUTE FUNCTION public.check_held_inventory_v29();

-- Servicio transaccional: serializa por usuario/clave; bloquea productos en orden
-- para evitar carreras y deadlocks y revisa precios del servidor.
CREATE OR REPLACE FUNCTION public.create_checkout_order_v29(
  p_user_id uuid, p_customer_email text, p_delivery_method text,
  p_address_id uuid, p_items jsonb, p_checkout_key uuid
)
RETURNS TABLE(order_id uuid, order_number text, subtotal numeric, shipping_cost numeric, total numeric, currency text, reserved_until timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE
 v_order_id uuid:=gen_random_uuid(); v_number text; v_subtotal numeric:=0;
 v_shipping numeric:=0; v_now timestamptz:=clock_timestamp();
 v_expiry timestamptz:=v_now + interval '20 minutes';
 v_it jsonb; v_id uuid; v_qty integer; v_seen uuid[]:=ARRAY[]::uuid[];
 v_p record; v_unit numeric; v_held bigint; v_email text; v_name text; v_phone text;
 v_intent text; v_existing record; v_num integer;
BEGIN
 IF p_user_id IS NULL OR p_checkout_key IS NULL OR p_customer_email IS NULL OR btrim(p_customer_email)='' THEN
  RAISE EXCEPTION 'authenticated_user_required' USING ERRCODE='22023';
 END IF;
 IF p_delivery_method NOT IN ('personal','shipping') OR p_delivery_method IS NULL THEN
  RAISE EXCEPTION 'invalid_delivery_method' USING ERRCODE='22023';
 END IF;
 IF p_delivery_method='shipping' THEN
  RAISE EXCEPTION 'shipping_rate_not_configured' USING ERRCODE='22023';
 END IF;
 IF p_items IS NULL OR jsonb_typeof(p_items)<>'array' OR jsonb_array_length(p_items)<1 OR jsonb_array_length(p_items)>50 THEN
  RAISE EXCEPTION 'invalid_cart' USING ERRCODE='22023';
 END IF;
 FOR v_it IN SELECT value FROM jsonb_array_elements(p_items) LOOP
  BEGIN
   v_id := (v_it->>'product_id')::uuid;
   v_qty := (v_it->>'quantity')::integer;
  EXCEPTION WHEN OTHERS THEN
   RAISE EXCEPTION 'invalid_cart_item' USING ERRCODE='22023';
  END;
  IF v_id IS NULL OR v_qty IS NULL OR v_qty NOT BETWEEN 1 AND 99 THEN
   RAISE EXCEPTION 'invalid_cart_item' USING ERRCODE='22023';
  END IF;
  IF v_id=ANY(v_seen) THEN RAISE EXCEPTION 'duplicate_product_in_cart' USING ERRCODE='22023'; END IF;
  v_seen:=array_append(v_seen,v_id);
 END LOOP;
 SELECT md5(jsonb_build_object(
   'delivery', p_delivery_method,
   'address', p_address_id,
   'items', (SELECT jsonb_agg(jsonb_build_object('product_id', e.value->>'product_id', 'quantity', (e.value->>'quantity')::integer) ORDER BY (e.value->>'product_id')) FROM jsonb_array_elements(p_items) e)
 )::text) INTO v_intent;
 -- Evitar dos operaciones para la misma clave mientras se ejecuta una transacción.
 PERFORM pg_advisory_xact_lock(hashtextextended(p_user_id::text || ':' || p_checkout_key::text,0));
 SELECT o.id, o.order_number, o.subtotal, o.shipping_cost, o.total, o.currency,
        o.reserved_until, o.checkout_intent_hash
 INTO v_existing FROM public.orders o
 WHERE o.user_id=p_user_id AND o.checkout_idempotency_key=p_checkout_key FOR UPDATE;
 IF FOUND THEN
  IF v_existing.checkout_intent_hash IS DISTINCT FROM v_intent THEN
   RAISE EXCEPTION 'checkout_key_payload_mismatch' USING ERRCODE='22023';
  END IF;
  RETURN QUERY SELECT v_existing.id, v_existing.order_number, v_existing.subtotal,
    v_existing.shipping_cost, v_existing.total, v_existing.currency, v_existing.reserved_until;
  RETURN;
 END IF;
 SELECT email::text INTO v_email FROM auth.users WHERE id=p_user_id;
 IF v_email IS NULL OR lower(v_email)<>lower(p_customer_email) THEN
  RAISE EXCEPTION 'user_email_mismatch' USING ERRCODE='22023';
 END IF;
 SELECT pr.full_name, pr.phone INTO v_name,v_phone FROM public.profiles pr WHERE pr.id=p_user_id;
 -- Producto con FOR UPDATE en orden determinista.
 FOR v_it IN SELECT value FROM jsonb_array_elements(p_items) ORDER BY value->>'product_id' LOOP
  v_id:=(v_it->>'product_id')::uuid; v_qty:=(v_it->>'quantity')::integer;
  SELECT p.id,p.name,p.image_url,p.price,p.stock,p.available,p.published,p.promotion_enabled,
         p.promotion_price,p.promotion_starts_at,p.promotion_ends_at
    INTO v_p FROM public.products p WHERE p.id=v_id FOR UPDATE;
  IF NOT FOUND OR v_p.available IS DISTINCT FROM true OR v_p.published IS DISTINCT FROM true THEN
   RAISE EXCEPTION 'product_unavailable' USING ERRCODE='22023';
  END IF;
  SELECT coalesce(sum(r.quantity),0) INTO v_held FROM public.checkout_inventory_reservations r
   WHERE r.product_id=v_id AND r.state='held' AND r.reserved_until>v_now;
  IF v_p.stock-v_held<v_qty THEN RAISE EXCEPTION 'insufficient_stock' USING ERRCODE='22023'; END IF;
  v_unit:=CASE WHEN v_p.promotion_enabled AND v_p.promotion_price IS NOT NULL
   AND (v_p.promotion_starts_at IS NULL OR v_p.promotion_starts_at<=v_now)
   AND (v_p.promotion_ends_at IS NULL OR v_p.promotion_ends_at>v_now)
   THEN v_p.promotion_price ELSE v_p.price END;
  IF v_unit IS NULL OR v_unit<0 OR v_unit<>round(v_unit,2) THEN
   RAISE EXCEPTION 'invalid_product_price' USING ERRCODE='22023';
  END IF;
  v_subtotal:=v_subtotal+v_unit*v_qty;
 END LOOP;
 IF v_subtotal<=0 THEN RAISE EXCEPTION 'invalid_order_total' USING ERRCODE='22023'; END IF;
 v_number:='MIK-'||to_char(v_now AT TIME ZONE 'UTC','YYYYMMDDHH24MISS')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
 INSERT INTO public.orders (
   id,order_number,user_id,subtotal,shipping_cost,total,delivery_method,payment_status,
   order_status,address_snapshot,customer_name,customer_phone,customer_email,currency,
   checkout_idempotency_key,checkout_intent_hash,inventory_state,reserved_until
 ) VALUES (
   v_order_id,v_number,p_user_id,v_subtotal,v_shipping,v_subtotal+v_shipping,p_delivery_method,'pending',
   'Pendiente de pago',NULL,v_name,v_phone,v_email,'MXN',p_checkout_key,v_intent,'held',v_expiry
 );
 FOR v_it IN SELECT value FROM jsonb_array_elements(p_items) ORDER BY value->>'product_id' LOOP
  v_id:=(v_it->>'product_id')::uuid; v_qty:=(v_it->>'quantity')::integer;
  SELECT p.id,p.name,p.price,p.image_url,p.promotion_enabled,p.promotion_price,p.promotion_starts_at,p.promotion_ends_at
   INTO v_p FROM public.products p WHERE p.id=v_id;
  v_unit:=CASE WHEN v_p.promotion_enabled AND v_p.promotion_price IS NOT NULL
   AND (v_p.promotion_starts_at IS NULL OR v_p.promotion_starts_at<=v_now)
   AND (v_p.promotion_ends_at IS NULL OR v_p.promotion_ends_at>v_now)
   THEN v_p.promotion_price ELSE v_p.price END;
  INSERT INTO public.order_items(order_id,product_id,product_name,unit_price,quantity,image_url_snapshot)
   VALUES(v_order_id,v_id,v_p.name,v_unit,v_qty,v_p.image_url);
  INSERT INTO public.checkout_inventory_reservations(order_id,product_id,quantity,state,reserved_until)
   VALUES(v_order_id,v_id,v_qty,'held',v_expiry);
 END LOOP;
 RETURN QUERY SELECT v_order_id,v_number,v_subtotal,v_shipping,v_subtotal+v_shipping,'MXN'::text,v_expiry;
END;
$$;
REVOKE ALL ON FUNCTION public.create_checkout_order_v29(uuid,text,text,uuid,jsonb,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.create_checkout_order_v29(uuid,text,text,uuid,jsonb,uuid) TO service_role;

-- Caducidad: se liberan reservas de pedidos sin NINGÚN intento de pago.
-- Ante estado desconocido de Mercado Pago, no se libera hasta conciliarlo.
CREATE OR REPLACE FUNCTION public.release_expired_checkout_v29(p_limit integer DEFAULT 100)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE v_id uuid; v_count integer:=0;
BEGIN
 IF p_limit IS NULL OR p_limit NOT BETWEEN 1 AND 500 THEN
  RAISE EXCEPTION 'invalid_limit' USING ERRCODE='22023';
 END IF;
 FOR v_id IN SELECT o.id FROM public.orders o
  WHERE o.inventory_state='held' AND o.payment_status='pending' AND o.reserved_until<now()
    AND NOT EXISTS(SELECT 1 FROM public.payment_attempts pa WHERE pa.order_id=o.id)
  ORDER BY o.reserved_until ASC LIMIT p_limit FOR UPDATE OF o SKIP LOCKED
 LOOP
  UPDATE public.checkout_inventory_reservations r SET state='released',updated_at=now()
   WHERE r.order_id=v_id AND r.state='held';
  UPDATE public.orders o SET inventory_state='released',order_status='Cancelado',payment_status='cancelled'
   WHERE o.id=v_id AND o.inventory_state='held' AND o.payment_status='pending';
  v_count:=v_count+1;
 END LOOP;
 RETURN v_count;
END;
$$;
REVOKE ALL ON FUNCTION public.release_expired_checkout_v29(integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.release_expired_checkout_v29(integer) TO service_role;

-- Conciliación atómica SOLO tras verificar en Mercado Pago el identificador,
-- el importe, moneda, referencia de la orden y la firma del webhook.
-- Este RPC no debe usarse desde el frontend y NO está conectado al webhook todavía.
CREATE OR REPLACE FUNCTION public.finalize_checkout_payment_v29(
 p_order_id uuid, p_provider_order_id text, p_provider_payment_id text,
 p_verified_amount numeric, p_verified_currency text, p_verified_status text
)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE v_o record; v_r record; v_total integer:=0; v_p record;
BEGIN
 IF p_provider_order_id IS NULL OR btrim(p_provider_order_id)='' OR p_verified_status NOT IN ('approved','rejected','cancelled','refunded','charged_back') THEN
  RAISE EXCEPTION 'invalid_verified_payment' USING ERRCODE='22023';
 END IF;
 SELECT * INTO v_o FROM public.orders WHERE id=p_order_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'order_not_found' USING ERRCODE='22023'; END IF;
 IF v_o.currency IS DISTINCT FROM p_verified_currency OR v_o.total IS DISTINCT FROM p_verified_amount THEN
  RAISE EXCEPTION 'provider_amount_mismatch' USING ERRCODE='22023';
 END IF;
 IF v_o.payment_reference IS NOT NULL AND v_o.payment_reference<>p_provider_order_id THEN
  RAISE EXCEPTION 'provider_reference_mismatch' USING ERRCODE='22023';
 END IF;
 IF p_verified_status='approved' THEN
  IF v_o.payment_status='paid' AND v_o.payment_reference=p_provider_order_id THEN RETURN 'already_paid'; END IF;
  IF v_o.payment_status NOT IN ('pending','failed') OR v_o.inventory_state<>'held' OR v_o.reserved_until<=now() THEN
   RAISE EXCEPTION 'not_payable_or_reservation_expired' USING ERRCODE='22023';
  END IF;
  -- Lock productos en orden fijo. No se vende más del stock disponible.
  FOR v_r IN SELECT product_id,quantity,reserved_until,state FROM public.checkout_inventory_reservations
   WHERE order_id=p_order_id ORDER BY product_id LOOP
   IF v_r.state<>'held' OR v_r.reserved_until<=now() THEN
    RAISE EXCEPTION 'reservation_expired' USING ERRCODE='22023';
   END IF;
   SELECT p.stock INTO v_p FROM public.products p WHERE p.id=v_r.product_id FOR UPDATE;
   IF NOT FOUND OR v_p.stock<v_r.quantity THEN RAISE EXCEPTION 'physical_stock_conflict' USING ERRCODE='22023'; END IF;
   v_total:=v_total+1;
  END LOOP;
  IF v_total=0 THEN RAISE EXCEPTION 'no_inventory_reservation' USING ERRCODE='22023'; END IF;
  -- Marcamos comprometidas antes de reducir stock, para que el trigger no cuente este pedido.
  UPDATE public.checkout_inventory_reservations SET state='committed',updated_at=now()
    WHERE order_id=p_order_id AND state='held';
  FOR v_r IN SELECT product_id,quantity FROM public.checkout_inventory_reservations
   WHERE order_id=p_order_id ORDER BY product_id LOOP
   UPDATE public.products p SET stock=p.stock-v_r.quantity WHERE p.id=v_r.product_id;
  END LOOP;
  UPDATE public.orders o SET payment_status='paid',inventory_state='committed',paid_at=coalesce(o.paid_at,now()),
   order_status=CASE WHEN o.order_status='Pendiente de pago' THEN 'Pedido confirmado' ELSE o.order_status END,
   payment_provider='mercado_pago',payment_reference=p_provider_order_id WHERE o.id=p_order_id;
  RETURN 'paid';
 END IF;
 IF p_verified_status IN ('refunded','charged_back') THEN
  IF v_o.payment_status NOT IN ('paid','refunded','charged_back') THEN
   RAISE EXCEPTION 'cannot_refund_unpaid_order' USING ERRCODE='22023';
  END IF;
  UPDATE public.orders o SET payment_status=p_verified_status,
   payment_reference=coalesce(o.payment_reference,p_provider_order_id),
   order_status=CASE WHEN o.order_status IN ('Pendiente de pago','Pedido confirmado') THEN 'Cancelado' ELSE o.order_status END
   WHERE o.id=p_order_id;
  -- No devolver stock automáticamente: podría haberse preparado o enviado.
  RETURN p_verified_status;
 END IF;
 IF v_o.payment_status='paid' OR v_o.inventory_state='committed' THEN
  RETURN 'already_paid';
 END IF;
 UPDATE public.checkout_inventory_reservations r SET state='released',updated_at=now()
  WHERE r.order_id=p_order_id AND r.state='held';
 UPDATE public.orders o SET inventory_state='released',payment_status=CASE WHEN p_verified_status='rejected' THEN 'failed' ELSE 'cancelled' END,
  order_status=CASE WHEN p_verified_status='cancelled' THEN 'Cancelado' ELSE o.order_status END,
  payment_provider='mercado_pago',payment_reference=p_provider_order_id WHERE o.id=p_order_id;
 RETURN 'released';
END;
$$;
REVOKE ALL ON FUNCTION public.finalize_checkout_payment_v29(uuid,text,text,numeric,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.finalize_checkout_payment_v29(uuid,text,text,numeric,text,text) TO service_role;

-- El administrador mantiene SELECT, pero no puede escribir estado de pago por REST.
-- Para gestionar logística en el futuro se expondrá un RPC restringido a cambios de estado.
REVOKE UPDATE ON TABLE public.orders FROM authenticated;
