# MIKOSMETICS v2.8 — Protección de acceso al checkout

**Estado: acceso y revisión comprobados con datos simulados; pagos y creación de pedidos temporalmente cerrados.**

## Qué cambia respecto de la v2.7

- El cliente puede navegar y añadir al carrito sin iniciar sesión. El carrito permanece en `localStorage`.
- La ruta `#/checkout` oculta el formulario privado y **comprueba la sesión con `supabase.auth.getUser()`**, en vez de confiar únicamente en `getSession()` o en un indicador local.
- Sin sesión, redirige a `#/acceso`; se guarda el destino previsto `#/checkout` en `sessionStorage`. Al iniciar sesión en la misma pestaña, regresa a checkout manteniendo cantidades.
- Si falla la red o la comprobación de sesión, mantiene el formulario oculto y permite reintentar.
- Al cerrar sesión, se oculta checkout y se redirige a acceso.
- Se preserva la verificación de precio vigente, producto publicado, promoción y stock por consulta fresca a Supabase. Importes mostrados son **estimados**, sin reserva de inventario.
- No se introduce ningún pago, SDK de tarjetas ni nuevo endpoint de escritura en el navegador.

## Bloqueo del servidor aplicado (9 oct. 2026)

En el proyecto Supabase `vkjiwdshcftjllllkzbf` se desplegaron versiones de **cierre preventivo**, con `verify_jwt=true`, para:

- `create-checkout-order`: versión 2, devuelve `503 checkout_temporarily_disabled` ante POST autenticado, sin crear pedidos.
- `create-mercadopago-order`: versión 3, devuelve `503 payments_temporarily_disabled`, sin hablar con Mercado Pago ni iniciar intentos.

Se verificó el código desplegado de ambas funciones. **No se modificó** `mercadopago-webhook`, las filas de órdenes, productos ni la tabla de intentos. La función `create_checkout_order_internal` conserva el permiso `EXECUTE` exclusivo del `service_role`, no de `anon` ni `authenticated` (verificado en auditoría previa).

## Pruebas

- `python3 tests/validate_release.py`: PASS, 12 archivos críticos, 128 IDs únicos, 9 módulos JS, 18 pantallas.
- `node tests/test_checkout_contract.mjs`: PASS, 11 aserciones sobre precios, promociones, stock, carrito y decisión de acceso.
- Pruebas integradas en Chromium mediante DOM real y Supabase **simulado**, con pantallas de 320 × 700, 390 × 844, 430 × 932 y 1440 × 900: cliente sin sesión → acceso → login → checkout, cliente identificado → checkout → cerrar sesión → acceso, y fallo de red → reintentar. **Nueve escenarios superados sin errores JavaScript y sin solicitudes de pago**.
- No se ha probado aún en Safari iPhone y Supabase Auth real después de instalar; no llamar a estos resultados prueba de producción.

## Pendiente antes de activar pagos

1. Diseñar e implementar reserva de inventario con transacciones, caducidad y liberación/reversión tras rechazo, cancelación o timeout; bloquear carreras y sobreventa.
2. Hacer creación de pedidos idempotente y conciliación ante fallos/reintentos con Mercado Pago.
3. Rehacer actualización del webhook: verificación criptográfica, reprocesado de eventos, transiciones monotónicas, no retroceder estado logístico, manejo de devoluciones/chargebacks y control de errores.
4. Configurar confirmación real de entrega personal y tarifas de envío; prueba de extremo a extremo en entorno TEST, incluida autenticación 3DS.
5. Solo tras test y autorización explícita, habilitar pagos. Esta versión **no procesa cobros**.

## Instalación sin borrar archivos actuales

Subir el ZIP completo a la raíz del repositorio GitHub como archivo binario. En Codespaces: sincronizar con `git pull --ff-only`, descomprimir `unzip -o MIKOSMETICS_v2_8_acceso_seguro.zip` y comprobar `python3 tests/validate_release.py`. Probar primero en una pestaña privada de Safari, para separar al visitante de las sesiones existentes. No compartir contraseñas ni tokens.
