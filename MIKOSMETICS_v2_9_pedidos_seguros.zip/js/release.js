/** Una sola fuente de versión visible para MIKOSMETICS. */
export const RELEASE = '2.9';
export const BUILD = 29;
