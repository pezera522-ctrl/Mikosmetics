/** MIKOSMETICS — Supabase público, una sola instancia, SDK v2 fijado.
 * La clave PUBLISHABLE no es secreta. Nunca poner service_role en el navegador.
 * SDK CDN con timeout y errores visibles; ninguna petición de compra aquí.
 */
export const PUBLIC_CONFIG = Object.freeze({
  url: 'https://vkjiwdshcftjllllkzbf.supabase.co',
  publishableKey: 'sb_publishable_svkc9Vj2VVBgY7h5D2Gx4Q_OsqeJ0a0',
});
const SCRIPT_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.57.4/dist/umd/supabase.min.js';
let clientPromise;
function loadSdk() {
  if (window.supabase?.createClient) return Promise.resolve(window.supabase);
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    const timer = window.setTimeout(() => { script.remove(); reject(new Error('El servicio de cuenta tardó demasiado en cargar. Comprueba tu conexión.')); }, 12000);
    script.async = true;
    script.src = SCRIPT_URL;
    script.referrerPolicy = 'no-referrer';
    script.onload = () => { clearTimeout(timer); window.supabase?.createClient ? resolve(window.supabase) : reject(new Error('El módulo de autenticación no se pudo iniciar.')); };
    script.onerror = () => { clearTimeout(timer); script.remove(); reject(new Error('No se pudo descargar el módulo de autenticación. Comprueba tu conexión.')); };
    document.head.append(script);
  });
}
export function getClient() {
  if (!clientPromise) {
    clientPromise = loadSdk().then((sdk) => sdk.createClient(PUBLIC_CONFIG.url, PUBLIC_CONFIG.publishableKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'implicit', storageKey: 'mikosmetics-auth-v1' },
    })).catch((error) => { clientPromise = null; throw error; });
  }
  return clientPromise;
}
