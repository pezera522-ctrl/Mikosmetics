/** MIKOSMETICS v2.9 — checkout de revisión: acceso validado con Supabase Auth.
 * Visitantes conservan carrito, van a inicio de sesión y regresan aquí al entrar.
 * No crea pedidos, no envía tokens de tarjeta, no hace cargos.
 */
import { getClient, PUBLIC_CONFIG } from './supabase-client.js?v=29';
import { cleanCart, analyzeInventory } from './checkout-contract.js?v=29';
import { decideCheckoutAccess } from './checkout-access.js?v=29';

const CART_KEY = 'mikosmetics:cart:v1';
const LOGIN_RETURN_KEY = 'mikosmetics:return:v28';
const money = new Intl.NumberFormat('es-MX', { style:'currency', currency:'MXN' });
const $ = (id) => document.getElementById(id);
let routeController = null;
let active = false;
let runId = 0;
let pending = false;

function node(tag, className='', text=''){
  const element=document.createElement(tag);
  if(className)element.className=className;
  if(text)element.textContent=String(text);
  return element;
}
function showMessage(id, message='', type=''){
  const element=$(id);if(!element)return;
  element.textContent=message;
  if(type)element.dataset.state=type;
  else element.removeAttribute('data-state');
}
function readCart(){
  try{return cleanCart(JSON.parse(localStorage.getItem(CART_KEY)||'[]'));}
  catch{return [];}
}
function privateView(visible){
  const element=$('checkout-private');if(element)element.hidden=!visible;
}
function rememberReturn(){
  try{sessionStorage.setItem(LOGIN_RETURN_KEY,'/checkout');}catch{}
}
function navigation(path){window.MIKOSMETICS_UI?.navigate?.(path);}
function displayAmounts(report){
  const holder=$('checkout-summary');if(!holder)return;
  holder.replaceChildren(node('h2','','Resumen de revisión'));
  for(const entry of report.lines){
    const row=node('div','checkout-review-line');
    row.append(node('span','',`${entry.quantity} × ${entry.name}`),node('strong','',entry.valid?money.format(entry.total):'No disponible'));
    holder.append(row);
    if(entry.reason)holder.append(node('p','checkout-line-warning',entry.reason));
  }
  const row=node('div','summary__row');
  row.append(node('span','','Subtotal estimado'),node('strong','',report.ok?money.format(report.subtotal):'—'));
  holder.append(row);
  holder.append(node('p','checkout-small','Importe estimado. Esta revisión no reserva existencias ni crea un pedido. El envío nacional sigue sin tarifa configurada.'));
}
function deliveryUI(){
  const selected=document.querySelector('input[name="delivery_method"]:checked')?.value||'personal';
  const addr=$('checkout-address-field');if(addr)addr.hidden=selected!=='shipping';
  showMessage('shipping-state',selected==='shipping'
    ?'La tarifa de envío nacional aún no está configurada. No se puede cobrar ni asumir que el envío sea gratis.'
    :'Referencia de entrega personal: 20 de Noviembre. Ubicación y horario exactos pendientes de confirmar.');
  showMessage('checkout-delivery-status',selected==='shipping'
    ?'Envío: tarifa pendiente de configurar en servidor.'
    :'Entrega personal: ubicación y horario pendientes de confirmar.');
}
async function verifiedUser(client){
  // getSession es una comprobación local de existencia. getUser consulta al servidor Auth
  // y NO se sustituye por leer una bandera de localStorage o un JWT sin verificar.
  const {data:sessionData,error:sessionError}=await client.auth.getSession();
  if(sessionError)throw sessionError;
  if(!sessionData?.session)return null;
  const {data,error}=await client.auth.getUser();
  if(error){
    if(['AuthSessionMissingError','AuthApiError'].includes(error.name) && (error.status===401 || error.status===403 || error.name==='AuthSessionMissingError'))return null;
    throw error;
  }
  return data?.user||null;
}
async function fetchProducts(ids,signal){
  const qs=new URLSearchParams();
  qs.set('select','id,name,price,stock,available,published,promotion_enabled,promotion_price,promotion_starts_at,promotion_ends_at');
  qs.set('id',`in.(${ids.join(',')})`);
  qs.set('published','eq.true');
  const timeout=new AbortController();
  const stop=()=>timeout.abort();signal.addEventListener('abort',stop,{once:true});
  const timer=setTimeout(()=>timeout.abort(),10000);
  try{
    const response=await fetch(`${PUBLIC_CONFIG.url}/rest/v1/products?${qs}`,{headers:{apikey:PUBLIC_CONFIG.publishableKey,Accept:'application/json'},signal:timeout.signal,cache:'no-store'});
    if(!response.ok)throw new Error('catalog_http_'+response.status);
    const rows=await response.json();if(!Array.isArray(rows))throw new Error('catalog_shape');
    return rows;
  }finally{clearTimeout(timer);signal.removeEventListener('abort',stop);}
}
async function fetchAddresses(client,user,signal){
  const select=$('checkout-address');if(!select)return;
  select.replaceChildren(new Option('Seleccionar dirección',''));
  const {data,error}=await client.from('addresses').select('id,full_name,street,number,city,postal_code').eq('user_id',user.id).order('created_at',{ascending:false}).limit(25);
  if(signal.aborted)return;
  if(error){showMessage('checkout-form-state','No se pudieron consultar tus direcciones.','error');return;}
  for(const a of data||[])select.add(new Option(`${a.full_name||'Dirección'} · ${a.street||''} ${a.number||''}, ${a.city||''} · ${a.postal_code||''}`,a.id));
  const help=$('checkout-address-help');
  if(help)help.textContent=(data?.length?'':'No tienes direcciones registradas. Agrégala desde Mi cuenta → Direcciones.');
}
async function openReview(signal){
  if(pending)return;
  pending=true;
  const requestId=++runId;
  const live=()=>!signal.aborted && requestId===runId && active;
  const button=$('create-order');if(button)button.disabled=true;
  privateView(false);
  showMessage('checkout-state','Comprobando tu sesión con Supabase Auth…');
  try{
    const client=await getClient();
    if(!live())return;
    const user=await verifiedUser(client);
    if(!live())return;
    const access=decideCheckoutAccess({user,authChecked:true});
    if(access==='login'){
      rememberReturn();
      showMessage('checkout-state','Necesitas iniciar sesión para revisar una compra. Tus productos seguirán en el carrito.');
      navigation('/acceso');
      return;
    }
    const cart=readCart();
    privateView(true);
    const auth=$('checkout-auth');
    if(auth)auth.replaceChildren(node('p','checkout-auth__success',`Sesión verificada: ${user.email||'cliente identificado'}`));
    deliveryUI();
    if(!cart.length){
      const holder=$('checkout-summary');if(holder)holder.replaceChildren(node('p','checkout-notice','Tu carrito está vacío. Agrega productos antes de revisar la compra.'));
      showMessage('checkout-state','Tu carrito está vacío.');
      return;
    }
    showMessage('checkout-state','Verificando precios y cantidades…');
    const products=await fetchProducts(cart.map(x=>x.id),signal);
    if(!live())return;
    const report=analyzeInventory(cart,products,Date.now());
    displayAmounts(report);
    showMessage('checkout-state',report.ok?'Precios y existencias consultados.':'Hay productos no disponibles o cantidades superiores al stock.',report.ok?'':'error');
    showMessage('checkout-form-state',report.ok?'':'Corrige el carrito antes de continuar.',report.ok?'':'error');
    await fetchAddresses(client,user,signal);
  }catch(error){
    if(!live())return;
    console.warn('Checkout no pudo verificar sesión o catálogo:',error?.name||'error');
    privateView(false);
    showMessage('checkout-state','No pudimos comprobar tu sesión o los productos. Revisa tu conexión y pulsa Reintentar.','error');
    // No exponer una revisión sin haber comprobado autenticación.
    const retry=$('checkout-retry');if(retry)retry.hidden=false;
  }finally{
    if(live()){pending=false;if(button)button.disabled=false;}
  }
}
function routeChanged(event){
  const checkout=event.detail.screen==='checkout';
  active=checkout;
  if(routeController)routeController.abort();
  routeController=null;
  pending=false;runId++;
  privateView(false);
  const retry=$('checkout-retry');if(retry)retry.hidden=true;
  if(!checkout)return;
  routeController=new AbortController();
  void openReview(routeController.signal);
}
export function initCheckout(){
  const form=$('checkout-form');
  if(!form||!$('checkout-summary')||!$('checkout-private'))throw new Error('Los archivos de checkout no coinciden: revisa la instalación v2.9.');
  form.addEventListener('change',(event)=>{if(event.target.name==='delivery_method')deliveryUI();});
  form.addEventListener('submit',(event)=>{
    event.preventDefault();
    // Revalidar sesión, stock y cantidades. Nunca crear orden ni procesar tarjeta.
    if(active && routeController && !pending)void openReview(routeController.signal);
  });
  $('checkout-retry')?.addEventListener('click',()=>{
    if(active && routeController && !pending){$('checkout-retry').hidden=true;void openReview(routeController.signal);}
  });
  window.addEventListener('mikosmetics:route',routeChanged);
  window.addEventListener('mikosmetics:cart-changed',()=>{if(active&&routeController&&!pending)void openReview(routeController.signal);});
  window.addEventListener('mikosmetics:account-refresh',()=>{if(active&&routeController&&!pending)void openReview(routeController.signal);});
  // logout: detectarlo incluso si el usuario permanece en checkout.
  void getClient().then(client=>{
    client.auth.onAuthStateChange((event)=>{
      if(event==='SIGNED_OUT' && active){privateView(false);rememberReturn();queueMicrotask(()=>navigation('/acceso'));}
    });
  }).catch(()=>{});
  const route=window.MIKOSMETICS_UI?.route;if(route?.screen==='checkout')routeChanged({detail:route});
}
