/** Decisión pura y testeable; el servidor sigue verificando JWT + permisos RLS. */
export function decideCheckoutAccess({user,authChecked,authError=false}) {
  if(authError || !authChecked)return 'hold';
  return user?.id ? 'allow' : 'login';
}
