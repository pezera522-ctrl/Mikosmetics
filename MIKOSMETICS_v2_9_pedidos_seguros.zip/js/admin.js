/** MIKOSMETICS — panel administrativo v2.9.
 * Consultas y escrituras bajo sesión autenticada + RLS existente.
 * Mostrar una sección por rol NO otorga privilegios; cada operación la controla Supabase.
 * Los pedidos son lectura real: cambiar logística queda bloqueado hasta reparar webhook
 * y disponer de una transición atómica en servidor, sin alterar pagos ni reembolsos.
 */
import { getClient } from './supabase-client.js?v=29';

const $ = (id) => document.getElementById(id);
const E = (tag, cls='', value) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (value !== undefined) n.textContent = String(value);
  return n;
};
const B = (label, action, cls='button button--outline') => {
  const n=E('button',cls,label);n.type='button';n.addEventListener('click',action);return n;
};
const currency = new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'});
const formatDate = s => {
  if (!s) return '—';
  const d=new Date(s);
  return Number.isNaN(d.valueOf()) ? '—' : new Intl.DateTimeFormat('es-MX',{dateStyle:'medium',timeStyle:'short'}).format(d);
};
const inventoryLabels = {unreserved:'Sin reserva',held:'Reserva temporal',committed:'Inventario descontado',released:'Reserva liberada'};
const productColumns='id,name,slug,category,description,material,price,stock,available,published,featured,image_url,promotion_enabled,promotion_price,promotion_starts_at,promotion_ends_at,created_at,updated_at';
const imageColumns='id,product_id,image_url,position,is_primary,created_at';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const IMAGE_TYPES=new Map([['image/jpeg','jpg'],['image/png','png'],['image/webp','webp']]);
const MAX_FILE=8*1024*1024;
let clientPromise, sb, user, authorized=false, controller=0, tab='products';
let products=[], orders=[], editingId=null, editingVersion='', images=[], saving=false, openedOrder=null;
let listSearch='';
const nodes={};

function state(message,kind='') {
  const n=$('admin-state'); if(!n)return;
  n.textContent=message;
  if(kind)n.dataset.state=kind;else delete n.dataset.state;
}
function panelNotice(message,kind='') {
  if(!nodes.notice)return;
  nodes.notice.textContent=message;
  if(kind)nodes.notice.dataset.state=kind;else delete nodes.notice.dataset.state;
}
function field(name,label,type='text',options={}) {
  const l=E('label','field');l.append(E('span','',label));
  const input=E(type==='textarea'?'textarea':type==='select'?'select':'input');
  input.name=name;
  if(type!=='select'&&type!=='textarea')input.type=type;
  if(options.required)input.required=true;
  if(options.min!==undefined)input.min=String(options.min);
  if(options.max!==undefined)input.max=String(options.max);
  if(options.step!==undefined)input.step=String(options.step);
  if(options.maxLength)input.maxLength=options.maxLength;
  if(options.placeholder)input.placeholder=options.placeholder;
  if(type==='select')for(const [value,text] of options.items||[])input.add(new Option(text,value));
  l.append(input);
  return l;
}
function check(name,label) {
  const l=E('label','admin-check');const x=E('input');x.type='checkbox';x.name=name;
  l.append(x,E('span','',label));return l;
}
function get(name) {return nodes.form?.elements.namedItem(name);}
function set(name,val){const x=get(name);if(x)x.type==='checkbox'?x.checked=!!val:x.value=val??'';}
function localValue(utc){if(!utc)return ''; const d=new Date(utc);if(!Number.isFinite(d.valueOf()))return '';
  // datetime-local shows the device's wall clock, never a UTC clock without conversion.
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}T${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}
function utcValue(value) {if(!value)return null;const d=new Date(value);if(!Number.isFinite(d.valueOf()))throw Error('Hay una fecha promocional inválida.');return d.toISOString();}
function finitePrice(value,label,required=true) {
  const s=String(value??'').trim();if(!s && !required)return null;
  if(!/^\d{1,9}(?:\.\d{1,2})?$/.test(s))throw Error(`${label} debe ser un importe válido con hasta dos decimales.`);
  const n=Number(s);if(!Number.isFinite(n)||n<0)throw Error(`${label} no es válido.`);return n;
}
function normaliseSlug(s) {
  return String(s||'').trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9-]+/g,'-').replace(/^-+|-+$/g,'').replace(/--+/g,'-').slice(0,85);
}
function safeImageUrl(value) {
  if(!value)return '';
  try {const u=new URL(value,location.href);return u.protocol==='https:'?u.href:'';}catch{return ''}
}
function fail(error, fallback='No se pudo completar la operación.') {
  const code=String(error?.code||'');
  if(code==='23505')return 'Ya existe un producto con ese identificador o slug. Usa otro.';
  if(code==='42501'||code==='PGRST301')return 'Tu sesión no tiene permisos suficientes. Revisa el rol administrador e inicia sesión de nuevo.';
  if(/Failed to fetch|NetworkError/i.test(String(error?.message)))return 'Error de red. Revisa tu conexión y vuelve a intentar.';
  return fallback;
}
function visible(){return location.hash.replace(/^#\//,'').split('/')[0]==='admin';}
async function authGuard() {
  const {data:{user:current},error:userError}=await sb.auth.getUser();
  if(userError||!current){user=null;authorized=false;throw Error('Inicia sesión para administrar MIKOSMETICS.');}
  const {data:profile,error}=await sb.from('profiles').select('role').eq('id',current.id).maybeSingle();
  if(error||profile?.role!=='admin'){user=current;authorized=false;throw Error('Esta cuenta no tiene permisos de administración.');}
  user=current;authorized=true;
  return current;
}
async function pageAll(base,orderKey='created_at') {
  const result=[];
  for(let from=0;from<5000;from+=200){
    const {data,error}=await base().order(orderKey,{ascending:false}).range(from,from+199);
    if(error)throw error;
    result.push(...(data||[]));if(!data||data.length<200)return result;
  }
  throw Error('Hay más registros que los que puede mostrar este panel.');
}
function markTabs() {
  document.querySelectorAll('[data-admin-tab]').forEach(button=>{
    const active=button.dataset.adminTab===tab;
    button.setAttribute('aria-selected',String(active));button.setAttribute('role','tab');button.classList.toggle('is-active',active);
  });
  document.querySelector('.admin-tabs')?.setAttribute('role','tablist');
}
function setup() {
  const root=$('admin-panel');if(!root)return false;
  root.replaceChildren();
  nodes.toolbar=E('div','admin-toolbar');nodes.notice=E('p','data-state');nodes.content=E('div','admin-workspace');
  root.append(nodes.toolbar,nodes.notice,nodes.content);
  markTabs();return true;
}
function listHeader() {
  nodes.toolbar.replaceChildren();
  const input=E('input','admin-search');input.type='search';input.placeholder='Buscar productos';input.setAttribute('aria-label','Buscar productos');input.value=listSearch;
  input.addEventListener('input',()=>{listSearch=input.value;drawProducts();});
  const add=B('Crear producto',()=>openEditor(null),'button button--light');
  const refresh=B('Actualizar',()=>loadProducts());
  nodes.toolbar.append(input,add,refresh);
}
function cardForProduct(p) {
  const card=E('article','admin-product');
  const img=safeImageUrl(p.image_url);
  const media=E('div','admin-product__media');if(img){const picture=E('img');picture.src=img;picture.alt='';picture.loading='lazy';picture.onerror=()=>picture.replaceWith(E('span','','Sin imagen'));media.append(picture);}else media.append(E('span','','Sin imagen'));
  const body=E('div','admin-product__body');
  body.append(E('h3','',p.name),E('p','',`${p.category} · ${currency.format(Number(p.price))}`),E('p','',`${p.stock} unidades · ${p.published?'Publicado':'Oculto'} · ${p.available?'Disponible':'No disponible'}${p.featured?' · Destacado':''}${p.promotion_enabled?' · Promoción configurada':''}`));
  body.append(B('Editar producto',()=>openEditor(p)));
  card.append(media,body);return card;
}
function drawProducts() {
  const matches=products.filter(p=>`${p.name} ${p.slug||''} ${p.category}`.toLocaleLowerCase('es').includes(listSearch.toLocaleLowerCase('es')));
  const list=E('div','admin-products-grid');if(!matches.length)list.append(E('p','data-state','No hay productos que coincidan con la búsqueda.'));
  else for(const p of matches)list.append(cardForProduct(p));
  nodes.content.replaceChildren(list);
  panelNotice(`${products.length} ${products.length===1?'producto registrado':'productos registrados'} (incluidos los ocultos).`);
}
async function loadProducts() {
  if(!authorized)return;const t=controller;
  panelNotice('Consultando productos…');
  try {
    products=await pageAll(()=>sb.from('products').select(productColumns));
    if(t!==controller||!visible()||tab!=='products')return;
    listHeader();drawProducts();
  } catch(e){if(t===controller){panelNotice(fail(e,'No se pudo consultar el catálogo administrativo.'),'error');nodes.content.replaceChildren(B('Reintentar',loadProducts));}}
}
function imageTile(im,index) {
  const tile=E('article','admin-image');
  const url=safeImageUrl(im.image_url);
  if(url){const pic=E('img');pic.src=url;pic.alt=`Imagen ${index+1} del producto`;pic.loading='lazy';tile.append(pic);}else tile.append(E('span','','Sin imagen'));
  const metadata=E('span','',im.is_primary?'Principal':`Galería ${index+1}`);
  const actions=E('div','admin-image__actions');
  actions.append(B('Principal',()=>promoteImage(im), 'button button--outline'));
  actions.append(B('Quitar',()=>removeImage(im),'button button--outline'));
  tile.append(metadata,actions);return tile;
}
function redrawImages() {
  if(!nodes.images)return;nodes.images.replaceChildren();
  if(!images.length){nodes.images.append(E('p','field-help','Todavía no hay imágenes vinculadas a este producto.'));return;}
  images.sort((a,b)=>Number(b.is_primary)-Number(a.is_primary)||Number(a.position)-Number(b.position));
  images.forEach((im,i)=>nodes.images.append(imageTile(im,i)));
}
async function loadImages(id){
  if(!id){images=[];redrawImages();return;}
  const {data,error}=await sb.from('product_images').select(imageColumns).eq('product_id',id).order('position',{ascending:true});
  if(error)throw error;
  images=data||[];redrawImages();
}
function fileError(f){
  if(!f)return '';
  if(!IMAGE_TYPES.has(f.type))return 'Utiliza JPEG, PNG o WebP.';
  if(f.size===0||f.size>MAX_FILE)return 'Cada archivo debe tener hasta 8 MiB.';
  return '';
}
async function uploadImage(product,file,asPrimary,position){
  const error=fileError(file);if(error)throw Error(error);
  const ext=IMAGE_TYPES.get(file.type);
  // Never use an original file name in a storage path.
  const path=`${product.id}/${crypto.randomUUID()}.${ext}`;
  const uploaded=await sb.storage.from('product-images').upload(path,file,{contentType:file.type,cacheControl:'3600',upsert:false});
  if(uploaded.error)throw uploaded.error;
  const url=sb.storage.from('product-images').getPublicUrl(path).data.publicUrl;
  if(asPrimary){
    const reset=await sb.from('product_images').update({is_primary:false}).eq('product_id',product.id).eq('is_primary',true);
    if(reset.error){await sb.storage.from('product-images').remove([path]);throw reset.error;}
  }
  const row={product_id:product.id,image_url:url,position,is_primary:asPrimary};
  const inserted=await sb.from('product_images').insert(row).select(imageColumns).single();
  if(inserted.error){await sb.storage.from('product-images').remove([path]);throw inserted.error;}
  if(asPrimary){
    const changed=await sb.from('products').update({image_url:url}).eq('id',product.id);
    if(changed.error)throw Error('Se guardó la imagen en galería, pero no se pudo actualizar la imagen principal.');
  }
  return inserted.data;
}
async function removeImage(im){
  if(saving||!editingId||!confirm('¿Desvincular esta imagen del producto?'))return;
  saving=true;panelNotice('Quitando imagen…');
  try {
    const {error}=await sb.from('product_images').delete().eq('id',im.id).eq('product_id',editingId);
    if(error)throw error;
    if(im.is_primary){
      const other=images.find(x=>x.id!==im.id);
      await setProductPrimary(other?.image_url||null);
      if(other){const promoted=await sb.from('product_images').update({is_primary:true}).eq('id',other.id).eq('product_id',editingId);if(promoted.error)throw promoted.error;}
    }
    const storageRoot=`${sb.storage.from('product-images').getPublicUrl('').data.publicUrl.replace(/\/$/,'')}/`;
    if(im.image_url.startsWith(storageRoot)) {
      const path=decodeURIComponent(im.image_url.slice(storageRoot.length).split('?')[0]);
      if(path.startsWith(`${editingId}/`)&&!path.includes('..'))await sb.storage.from('product-images').remove([path]);
    }
    await loadImages(editingId);panelNotice('Imagen desvinculada.','success');
    window.dispatchEvent(new Event('mikosmetics:inventory-changed'));
  }catch(e){panelNotice(fail(e,'No se pudo quitar la imagen.'),'error');}
  finally{saving=false;}
}
async function setProductPrimary(url){
  const {error}=await sb.from('products').update({image_url:url}).eq('id',editingId);
  if(error)throw error;
}
async function promoteImage(im){
  if(saving||!editingId)return;saving=true;panelNotice('Cambiando imagen principal…');
  try {
    // Clear the previous primary row before promoting; RLS checks both writes.
    const {error:clear}=await sb.from('product_images').update({is_primary:false}).eq('product_id',editingId).eq('is_primary',true);
    if(clear)throw clear;
    const {error:promote}=await sb.from('product_images').update({is_primary:true}).eq('id',im.id).eq('product_id',editingId);
    if(promote)throw promote;
    await setProductPrimary(im.image_url);
    await loadImages(editingId);panelNotice('Imagen principal actualizada.','success');
    window.dispatchEvent(new Event('mikosmetics:inventory-changed'));
  }catch(e){panelNotice(fail(e,'No se pudo actualizar la imagen principal.'),'error');}
  finally{saving=false;}
}
function openEditor(p) {
  editingId=p?.id||null;editingVersion=p?.updated_at||'';images=[];
  nodes.toolbar.replaceChildren(B('← Volver a productos',()=>{editingId=null;loadProducts();}));
  const f=E('form','form-card admin-editor');f.id='admin-product-form';f.noValidate=false;
  f.append(E('h2','',p?'Editar producto':'Nuevo producto'));
  const grid=E('div','admin-form-grid');
  [field('name','Nombre del producto','text',{required:true,maxLength:160}),
   field('slug','Slug (URL amigable)','text',{maxLength:85,placeholder:'Se genera a partir del nombre'}),
   field('category','Categoría','text',{required:true,maxLength:100}),
   field('material','Material','text',{maxLength:160}),
   field('price','Precio normal (MXN)','number',{required:true,min:0,step:'0.01'}),
   field('stock','Existencias','number',{required:true,min:0,step:1}),
   field('description','Descripción','textarea',{maxLength:5000})]
  .forEach(x=>grid.append(x));
  f.append(grid);
  const toggles=E('div','admin-checks');
  ['available','published','featured','promotion_enabled'].forEach((name,i)=>toggles.append(check(name,['Disponible para comprar','Publicado en catálogo','Destacado en inicio','Activar promoción'][i])));
  f.append(toggles);
  const promoGroup=E('fieldset','admin-promo');promoGroup.append(E('legend','','Precio especial y vigencia'));
  const promoFields=E('div','admin-form-grid');
  promoFields.append(field('promotion_price','Precio promocional (MXN)','number',{min:0,step:'0.01'}),field('promotion_starts_at','Desde (hora local)','datetime-local'),field('promotion_ends_at','Hasta (hora local)','datetime-local'));
  promoGroup.append(promoFields,E('p','field-help','Las fechas se guardan en UTC. El servidor determina el precio definitivo cobrado.'));
  f.append(promoGroup);
  const pictureGroup=E('fieldset','admin-promo');pictureGroup.append(E('legend','','Fotografías'));
  const imageHelp=E('p','field-help','JPEG, PNG o WebP, máximo 8 MiB por imagen. La primera fotografía seleccionada será principal si no existe otra.');
  pictureGroup.append(imageHelp);
  const mainLabel=field('main_picture','Nueva imagen principal','file');const galleryLabel=field('gallery_pictures','Agregar imágenes a galería','file');
  mainLabel.querySelector('input').accept='image/jpeg,image/png,image/webp';galleryLabel.querySelector('input').accept='image/jpeg,image/png,image/webp';galleryLabel.querySelector('input').multiple=true;
  pictureGroup.append(mainLabel,galleryLabel);
  nodes.images=E('div','admin-gallery');pictureGroup.append(nodes.images);f.append(pictureGroup);
  nodes.editorStatus=E('p','form-state');nodes.editorStatus.setAttribute('role','status');
  const actions=E('div','admin-form-actions');
  const save=E('button','button button--light','Guardar producto');save.type='submit';
  actions.append(save,B('Cancelar',()=>{editingId=null;loadProducts();}));
  f.append(nodes.editorStatus,actions);
  nodes.form=f;nodes.content.replaceChildren(f);panelNotice('');
  const values=p||{};
  ['name','slug','category','material','price','stock','description','promotion_price'].forEach(k=>set(k,values[k]??''));
  ['available','published','featured','promotion_enabled'].forEach(k=>set(k,p?p[k]:(k==='published'||k==='available')));
  set('promotion_starts_at',localValue(p?.promotion_starts_at));set('promotion_ends_at',localValue(p?.promotion_ends_at));
  f.addEventListener('submit',event=>{event.preventDefault();saveProduct();});
  redrawImages();
  if(p)loadImages(p.id).catch(e=>{nodes.editorStatus.textContent=fail(e,'No se pudo cargar la galería.');nodes.editorStatus.dataset.state='error';});
  f.querySelector('input[name="name"]')?.focus({preventScroll:true});
}
async function saveProduct() {
  if(saving||!authorized)return;
  const f=nodes.form;if(!f?.reportValidity())return;
  const savedEditing=editingId,version=editingVersion;
  const primary=f.elements.namedItem('main_picture')?.files?.[0];
  const gallery=[...(f.elements.namedItem('gallery_pictures')?.files||[])];
  const allFiles=[primary,...gallery].filter(Boolean);
  const issue=allFiles.map(fileError).find(Boolean);
  if(issue){nodes.editorStatus.textContent=issue;nodes.editorStatus.dataset.state='error';return;}
  if(allFiles.length>12){nodes.editorStatus.textContent='Puedes agregar como máximo 12 fotografías por guardado.';nodes.editorStatus.dataset.state='error';return;}
  let payload;
  try {
    const name=get('name').value.trim();const category=get('category').value.trim();
    if(!name||!category)throw Error('Nombre y categoría son obligatorios.');
    const price=finitePrice(get('price').value,'Precio normal');
    const stock=Number(get('stock').value);
    if(!Number.isSafeInteger(stock)||stock<0||stock>100000000)throw Error('La cantidad disponible debe ser un entero no negativo.');
    const enabled=get('promotion_enabled').checked;
    const pp=finitePrice(get('promotion_price').value,'Precio promocional',false);
    const start=utcValue(get('promotion_starts_at').value);const end=utcValue(get('promotion_ends_at').value);
    if(enabled && (pp===null||pp>=price))throw Error('La promoción necesita un precio inferior al precio normal.');
    if(start&&end&&Date.parse(start)>=Date.parse(end))throw Error('La fecha final debe ser posterior a la inicial.');
    payload={name,category,slug:normaliseSlug(get('slug').value||name),material:get('material').value.trim()||null,description:get('description').value.trim()||null,
      price,stock,available:get('available').checked,published:get('published').checked,featured:get('featured').checked,
      promotion_enabled:enabled,promotion_price:pp,promotion_starts_at:start,promotion_ends_at:end};
    if(!payload.slug)throw Error('El slug necesita al menos una letra o número.');
  }catch(error){nodes.editorStatus.textContent=error.message;nodes.editorStatus.dataset.state='error';return;}
  saving=true;const saveBtn=f.querySelector('[type="submit"]');saveBtn.disabled=true;
  nodes.editorStatus.textContent='Guardando producto…';delete nodes.editorStatus.dataset.state;
  try {
    const query=savedEditing?sb.from('products').update(payload).eq('id',savedEditing).eq('updated_at',version):sb.from('products').insert(payload);
    const {data:product,error}=await query.select(productColumns).maybeSingle();
    if(error)throw error;
    if(!product)throw Error('Conflicto de edición: el producto cambió desde otra sesión. Actualiza el panel y vuelve a editarlo.');
    editingId=product.id;editingVersion=product.updated_at;
    let i=0;const problems=[];
    for(const file of allFiles){
      try {await uploadImage(product,file,(file===primary)||(!product.image_url&&i===0),images.length+i);}catch(e){problems.push(`${file.name}: ${fail(e,'No se pudo subir esta fotografía.')}`);}
      i++;
    }
    window.dispatchEvent(new Event('mikosmetics:inventory-changed'));
    await loadImages(product.id);
    const message=problems.length ? `Producto guardado, pero hubo errores de fotografías: ${problems.join(' | ')}` : 'Producto guardado correctamente.';
    nodes.editorStatus.textContent=message;nodes.editorStatus.dataset.state=problems.length?'error':'success';
    panelNotice(message,problems.length?'error':'success');
    // Preserve the editor when uploads fail so the user can retry deliberately.
    if(!problems.length){editingId=null;await loadProducts();}
  }catch(e){nodes.editorStatus.textContent=e.message?.startsWith('Conflicto')?e.message:fail(e,'No se pudo guardar el producto.');nodes.editorStatus.dataset.state='error';}
  finally{saving=false;saveBtn.disabled=false;}
}
function renderOrderCard(o) {
  const item=E('article','admin-order');
  const info=E('div');info.append(E('h3','',`Pedido ${o.order_number}`),E('p','',`${formatDate(o.created_at)} · ${currency.format(Number(o.total))}`),
    E('p','',`Pago: ${o.payment_status} · Estado: ${o.order_status}`),E('p','',`Entrega: ${o.delivery_method==='shipping'?'Envío':'Personal'}`),E('p','',`Inventario: ${inventoryLabels[o.inventory_state]||'Pendiente de verificar'}`));
  item.append(info,B('Ver detalle',()=>openOrder(o)));return item;
}
async function loadOrders(){
  if(!authorized)return;const t=controller;
  nodes.toolbar.replaceChildren(B('Actualizar pedidos',loadOrders));
  panelNotice('Consultando pedidos…');
  try{
    orders=await pageAll(()=>sb.from('orders').select('id,order_number,user_id,created_at,updated_at,customer_name,customer_phone,customer_email,total,subtotal,shipping_cost,currency,payment_status,order_status,delivery_method,address_snapshot,paid_at,inventory_state,reserved_until'));
    if(t!==controller||!visible()||tab!=='orders')return;
    const list=E('div','admin-orders');if(!orders.length)list.append(E('p','data-state','Todavía no hay pedidos registrados.'));
    else orders.forEach(o=>list.append(renderOrderCard(o)));
    nodes.content.replaceChildren(list);panelNotice(`${orders.length} pedidos registrados. Los estados se consultan desde Supabase.`);
  }catch(e){if(t===controller){panelNotice(fail(e,'No se pudieron consultar los pedidos.'),'error');nodes.content.replaceChildren(B('Reintentar',loadOrders));}}
}
async function openOrder(order) {
  openedOrder=order.id;nodes.toolbar.replaceChildren(B('← Volver a pedidos',loadOrders));
  panelNotice('Cargando detalle…');
  const detail=E('article','admin-order-detail');nodes.content.replaceChildren(detail);
  try {
    const {data:lines,error}=await sb.from('order_items').select('id,product_name,quantity,unit_price,image_url_snapshot').eq('order_id',order.id).order('created_at',{ascending:true});
    if(error)throw error;
    if(openedOrder!==order.id||!visible()||tab!=='orders')return;
    detail.append(E('h2','',`Pedido ${order.order_number}`));
    const dl=E('dl','admin-order-kv');
    const kv=(name,value)=>{dl.append(E('dt','',name),E('dd','',value===null||value===undefined||value===''?'—':String(value)));};
    kv('Fecha',formatDate(order.created_at));kv('Cliente',order.customer_name);kv('Correo',order.customer_email);kv('Teléfono',order.customer_phone);
    kv('Pago',order.payment_status);kv('Reserva',inventoryLabels[order.inventory_state]||'No registrada');if(order.inventory_state==='held')kv('Reservado hasta',formatDate(order.reserved_until));kv('Estado logístico',order.order_status);kv('Método',order.delivery_method==='shipping'?'Envío':'Entrega personal');
    kv('Subtotal',currency.format(Number(order.subtotal)));kv('Envío',currency.format(Number(order.shipping_cost)));kv('Total',currency.format(Number(order.total)));
    if(order.delivery_method==='shipping'&&order.address_snapshot){
      const a=order.address_snapshot;
      const address=typeof a==='object'? Object.entries(a).filter(([key,val])=>['street','number','colony','city','postal_code','between_streets','customer_references','full_name','phone'].includes(key)&&val).map(([k,v])=>`${k}: ${v}`).join(' · '):'';
      kv('Dirección registrada',address);
    }
    detail.append(dl,E('h3','','Artículos'));
    const ul=E('ul','admin-order-lines');
    (lines||[]).forEach(line=>ul.append(E('li','',`${line.quantity} × ${line.product_name} — ${currency.format(Number(line.unit_price)*line.quantity)}`)));
    detail.append(ul);
    const warning=E('p','data-state','Los cambios de estado logístico están bloqueados hasta corregir y validar el webhook de pagos y la transición atómica en servidor. No se puede aprobar un pago ni realizar un reembolso desde este panel.');
    detail.append(warning);panelNotice('Detalle consultado correctamente.','success');
  }catch(e){panelNotice(fail(e,'No se pudo cargar el detalle del pedido.'),'error');}
}
async function activate(){
  if(!visible())return;
  const t=++controller;
  const content=$('admin-content');if(content)content.hidden=true;
  state('Verificando permisos de administración…');
  try {
    sb=await (clientPromise??=getClient());
    await authGuard();
    if(t!==controller||!visible())return;
    if(content)content.hidden=false;
    state('');
    if(!setup())return;
    if(tab==='orders')await loadOrders();else await loadProducts();
  }catch(e){if(t===controller){state(e.message||'No se pudo confirmar tu acceso.','error');if(content)content.hidden=true;}}
}
export function initAdmin(){
  document.querySelectorAll('[data-admin-tab]').forEach(button=>button.addEventListener('click',()=>{
    if(!authorized)return;tab=button.dataset.adminTab==='orders'?'orders':'products';openedOrder=null;editingId=null;controller++;
    setup();if(tab==='orders')loadOrders();else loadProducts();
  }));
  window.addEventListener('mikosmetics:route',e=>{
    if(e.detail.screen==='admin')activate();else controller++;
  });
  window.addEventListener('mikosmetics:account-refresh',()=>{if(visible())activate();});
  if (visible()) activate();
}
