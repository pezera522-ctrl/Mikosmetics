# MIKOSMETICS v2.9 — Backend de pedidos e inventario, pagos todavía cerrados

**Estado de entrega: preparado y desplegado en Supabase, sin habilitar compras ni cobros.**

## Servidor: cambios instalados

En el proyecto existente de Supabase se aplicó la migración `v29_atomic_checkout_reservations_payment_guards`. Se agregaron:

- `orders.inventory_state` (`unreserved`, `held`, `committed`, `released`), fecha de expiración y huella del contenido del checkout.
- Tabla `checkout_inventory_reservations` con RLS habilitado, sin acceso directo para `anon` ni `authenticated`.
- `create_checkout_order_v29`: función **solo service_role**, con validación de cuenta y correo, comprobación de precio/promociones y stock vigentes, bloqueo de productos en orden estable, reserva temporal de 20 minutos e idempotencia por usuario/checkout_key. Pedidos físicos no descuentan stock hasta confirmación verificada.
- `release_expired_checkout_v29`: libera reservas vencidas que nunca tuvieron intento de pago; no libera las de estado financiero incierto. **No hay programador instalado todavía**; deberá invocarse de manera segura y supervisada cuando el checkout se habilite.
- `finalize_checkout_payment_v29`: función **solo service_role**, para asociar la información *previamente verificada por un webhook seguro* a una transición de inventario/pedido atómica. No se conecta al webhook actual todavía; por sí sola no comprueba Mercado Pago ni firma.
- Trigger de stock: rechaza que una modificación administrativa de stock lo deje por debajo de reservas vigentes.
- Se retiró el permiso de UPDATE de `orders` al rol `authenticated`: el administrador ve pedidos pero todavía no cambia logística. Se diseñará un RPC administrativo de transición logística separada.

**Las dos funciones públicas `create-checkout-order` y `create-mercadopago-order` siguen cerradas con HTTP 503 y JWT habilitado**, como en v2.8. El webhook anterior se conserva sin conectar al RPC nuevo. No se ejecutan tarjetas, pagos, ni pedidos desde la tienda.

## Pruebas reales de Supabase (transacciones revertidas)

Se ejecutaron pruebas contra la base real, dentro de `BEGIN ... ROLLBACK`:

1. Crear pedido temporal de prueba con usuario existente y producto disponible; comprobación de importe > 0 y expiración futura.
2. Reintento con misma clave no duplica pedido; contenido diferente con misma clave se rechaza.
3. Crear reserva no reduce stock físico.
4. Una confirmación con importe distinto se rechaza.
5. Confirmación simulada como verificada descuenta stock una sola vez; repetirla devuelve `already_paid`.
6. Reserva excesiva se rechaza cuando el producto ya tiene reservas vivas.
7. Administración no puede reducir stock por debajo de las unidades reservadas.
8. Rechazo libera reserva, y el stock queda disponible para una nueva.
9. Liberación de reserva vencida sin intento de pago actualiza el estado del pedido.
10. Se verificó que después de los rollback quedaron **0 pedidos, 0 reservas y 0 intentos de pago**.

Estas **no son pruebas reales de Mercado Pago ni de concurrencia bajo carga**. Tampoco confirman reconciliación de webhook/3DS ni resistencia ante cortes de red; esos son bloqueantes para abrir cobros.

## Frontend v2.9

- Se conserva la intro SVG, el carrito, catálogo, cuentas y checkout de v2.8.
- En checkout se explica con claridad que la pantalla solo revisa productos y no crea pedidos.
- El pie de página ya muestra `MIKOSMETICS · 2.9`, controlado desde `js/release.js` (una sola fuente de versión); se eliminó el `2.7` fijo.
- En Administración y Mi cuenta los pedidos futuros mostrarán estado de inventario y expiración de reserva cuando corresponda.
- Corrección gramatical `1 producto registrado` en panel.
- Cache-busting `?v=29`, sin tocar credenciales ni claves secretas.

## Próximos bloqueantes (no habilitar pagos todavía)

1. Revisar y reemplazar el webhook de Mercado Pago: firma, identificación de referencia, monto/moneda, idempotencia de eventos y transiciones permitidas; reconciliación de eventos atrasados y pagos acreditados con reserva expirada.
2. Habilitar un flujo TEST de Card Payment Brick con 3DS; dobles toques, errores y pérdida de red deben ser seguros.
3. Diseñar expiración automatizada con supervisión, política de reserva mientras 3DS está activo y reposición sobre reembolsos.
4. Configurar ubicación/horarios de entrega personal y tarifa real de envío; cualquier envío sigue bloqueado hasta tener tarifa.
5. Añadir RPC de gestión logística para administradores, sin darles capacidad de editar el estado financiero.
6. Aprobar pruebas reales multiusuario/concurrentes antes de reactivar la función pública de creación y luego cobros.

## Instalación

Subir `MIKOSMETICS_v2_9_pedidos_seguros.zip` intacto a la raíz del repo en GitHub → `git pull --ff-only` en Codespaces → `unzip -o MIKOSMETICS_v2_9_pedidos_seguros.zip` → `python3 tests/validate_release.py` → `node tests/test_checkout_contract.mjs` → `node tests/test_release_v29.mjs`. No ejecutar migración otra vez: **ya está instalada en Supabase**.

Importante: la base fue modificada antes de instalar el frontend v2.9; no es una operación reversible por mera descompresión del ZIP. Pagos se mantienen cerrados durante y después de la instalación.
