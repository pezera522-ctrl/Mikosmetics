"""Pruebas sin dependencias para revisar archivos de MIKOSMETICS v2.7."""
from pathlib import Path
from html.parser import HTMLParser
from subprocess import run
import re

ROOT=Path(__file__).resolve().parents[1]
FILES=['index.html','css/style.css','js/script.js','js/ui-shell.js','js/storefront.js','js/account.js','js/admin.js','js/supabase-client.js','js/checkout.js','js/checkout-contract.js','assets/logo-mikosmetics.svg']
class IDs(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.refs=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.append(attrs['id'])
        if 'aria-labelledby' in attrs:self.refs.extend(attrs['aria-labelledby'].split())

for name in FILES:assert (ROOT/name).is_file(),f'Falta {name}'
html=(ROOT/'index.html').read_text(encoding='utf-8')
p=IDs();p.feed(html)
assert len(p.ids)==len(set(p.ids)), 'IDs HTML duplicados'
assert set(p.refs)<=set(p.ids), 'Referencias aria-labelledby inválidas'
assert '?v=27' in html and 'js/script.js?v=27' in html, 'Versionado no configurado'
for route in ['inicio','productos','promociones','producto','carrito','acceso','registro','recuperar','restablecer','cuenta','direcciones','pedidos','pedido','checkout','pago','admin','ayuda','no-encontrado']:
    assert f'id="page-{route}"' in html, f'Falta pantalla {route}'
for js in (ROOT/'js').glob('*.js'):
    r=run(['node','--check',str(js)],capture_output=True,text=True)
    if r.returncode:raise AssertionError(f'Error de sintaxis en {js.name}: {r.stderr}')
    for rel in re.findall(r'\b(?:from|import\()\s*[\'\"](\./[^\'\"]+)',js.read_text(encoding='utf-8')):
        assert (js.parent/rel.split('?')[0]).is_file(),f'Import roto: {js.name} -> {rel}'
assert 'id="checkout-auth"' in html and 'id="checkout-summary"' in html
assert "No se creará un pedido" in html
checkout=(ROOT/"js/checkout.js").read_text()
assert ".insert(" not in checkout and "functions.invoke" not in checkout and "POST" not in checkout, "La revisión no puede cobrar ni crear pedidos"
print(f'PASS: {len(FILES)} archivos críticos, {len(p.ids)} IDs únicos, {len(list((ROOT/"js").glob("*.js")))} módulos JS y 18 pantallas.')
