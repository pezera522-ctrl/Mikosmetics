/** MIKOSMETICS — cuenta real con Auth v2 + perfiles, direcciones y pedidos protegidos por RLS.
 * La validación de identidad/rol es del servidor; las UI solo expresan estados.
 * No se accede a datos de terceros, no se usa service_role, no se guarda password.
 */
import { getClient } from './supabase-client.js?v=27';
const $ = (id) => document.getElementById(id);
const el = (tag, name, label='') => { const x=document.createElement(tag); if(name)x.className=name; if(label)x.textContent=label; return x; };
const txt = (id, value, kind='') => { const x=$(id);if(!x)return;x.textContent=String(value||''); kind?x.dataset.state=kind:delete x.dataset.state; };
const stamp = (raw) => raw ? new Intl.DateTimeFormat('es-MX',{dateStyle:'medium'}).format(new Date(raw)) : '';
const money = (value) => new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(Number(value)||0);
let sb = null, authUser = null, starting = null, route = null, recoveryActive = false;
let profile = null, busy = new Set(), routeToken=0, profileLoadedFor='';
const authRouteNames = new Set(['cuenta','acceso','registro','recuperar','restablecer','direcciones','pedidos','pedido','admin']);
const authCodeInUrl = /(?:^#|&)access_token=/.test(location.hash);
const passwordRecoveryInUrl = /(?:^#|&)type=recovery(?:&|$)/.test(location.hash);
function link(href, label) { const a=el('a','text-link',label);a.href=`#${href}`;a.dataset.link='';return a; }
function current() { return window.MIKOSMETICS_UI?.route?.screen || 'inicio'; }
function navigate(target) { window.MIKOSMETICS_UI?.navigate(target); }
function describe(error, generic='No fue posible completar la operación.') {
  // No revelar identificadores ni mensajes potencialmente sensibles de backend.
  const code = String(error?.code || '').toLowerCase();
  if(code.includes('invalid_credentials'))return 'Correo o contraseña incorrectos.';
  if(code.includes('email_not_confirmed'))return 'Confirma tu correo antes de iniciar sesión.';
  if(code.includes('over_email_send_rate_limit')||code.includes('over_request_rate_limit'))return 'Demasiados intentos. Espera un momento y vuelve a intentar.';
  if(code.includes('weak_password'))return 'La contraseña no cumple los requisitos de seguridad.';
  if(code.includes('same_password'))return 'Elige una contraseña diferente.';
  if(code.includes('user_already_exists'))return 'No se pudo crear la cuenta. Comprueba el correo o inicia sesión.';
  if(error?.message?.includes('Failed to fetch'))return 'No hay conexión con Supabase. Revisa tu internet.';
  return generic;
}
function transient(id, label, action) {
  if(busy.has(id))return;
  const f=$(id); const button=f?.querySelector('[type="submit"]');
  if(!f||!button)return;
  busy.add(id);button.disabled=true;const previous=button.textContent;button.textContent=label;
  Promise.resolve().then(action).catch((e)=>txt(id.replace('-form','-state'),describe(e),'error')).finally(()=>{button.disabled=false;button.textContent=previous;busy.delete(id);});
}
function accountGuest(message='Inicia sesión para consultar tu perfil, tus direcciones y tus pedidos.') {
  const state=$('account-state');if(state)state.replaceChildren(el('p','',message),link('/acceso','Iniciar sesión →'),link('/registro','Crear una cuenta →'));
  if($('account-content'))$('account-content').hidden=true;
}
function requiresSession(id, message='Inicia sesión para consultar esta información.') {
  const node=$(id);if(node)node.replaceChildren(el('span','',message),link('/acceso','Iniciar sesión →'));
}
function activeRoute(token) {return token===routeToken;}
function emailRedirect() { return `${location.origin}${location.pathname}`; }
function accountDestination(){
  try{const v=sessionStorage.getItem('mikosmetics:return:v27');if(v==='/checkout'){sessionStorage.removeItem('mikosmetics:return:v27');return v;}}catch{}
  return '/cuenta';
}
function loginForm() {
  $('login-form')?.addEventListener('submit',(event)=>{event.preventDefault();transient('login-form','Entrando…',async()=>{
    txt('login-state','Comprobando credenciales…');
    try {
      const data=new FormData($('login-form'));
      const {error}=await sb.auth.signInWithPassword({email:String(data.get('email')).trim(),password:String(data.get('password'))});
      if(error)throw error;
      $('login-form').reset();txt('login-state','');navigate(accountDestination());
    }catch(e){txt('login-state',describe(e),'error');}
  });});
  $('register-form')?.addEventListener('submit',(event)=>{event.preventDefault();transient('register-form','Creando cuenta…',async()=>{
    txt('register-state','Enviando registro…');
    try {
      const data=new FormData($('register-form'));
      const {data:result,error}=await sb.auth.signUp({email:String(data.get('email')).trim(),password:String(data.get('password')),options:{data:{full_name:String(data.get('name')).trim()},emailRedirectTo:emailRedirect()}});
      if(error)throw error;
      $('register-form').reset();
      if(result.session)navigate(accountDestination());
      else txt('register-state','Si el registro se procesó, recibirás un correo de confirmación. Revisa también spam.');
    }catch(e){txt('register-state',describe(e),'error');}
  });});
  $('recover-form')?.addEventListener('submit',(event)=>{event.preventDefault();transient('recover-form','Enviando…',async()=>{
    txt('recover-state','Solicitando correo…');
    try {const data=new FormData($('recover-form'));
      const {error}=await sb.auth.resetPasswordForEmail(String(data.get('email')).trim(),{redirectTo:emailRedirect()});
      if(error)throw error;
      txt('recover-state','Si el correo corresponde a una cuenta, recibirás un enlace para restablecer tu contraseña.');
    }catch(e){txt('recover-state',describe(e),'error');}
  });});
  $('reset-form')?.addEventListener('submit',(event)=>{event.preventDefault();transient('reset-form','Guardando…',async()=>{
    if(!recoveryActive||!authUser){txt('reset-state','Abre primero el enlace de recuperación válido que recibiste por correo.','error');return;}
    try {const data=new FormData($('reset-form'));
      const {error}=await sb.auth.updateUser({password:String(data.get('password'))});if(error)throw error;
      recoveryActive=false;$('reset-form').reset();txt('reset-state','Contraseña actualizada. Tu sesión está activa.');navigate('/cuenta');
    }catch(e){txt('reset-state',describe(e),'error');}
  });});
}
async function loadProfile(token) {
  if(!authUser||!activeRoute(token))return;
  txt('account-state','Cargando perfil…');
  const {data,error}=await sb.from('profiles').select('id,full_name,phone,role').eq('id',authUser.id).maybeSingle();
  if(!activeRoute(token)||!authUser)return;
  if(error){txt('account-state','No se pudo consultar el perfil. Comprueba la conexión.','error');$('account-content').hidden=true;return;}
  if(!data){txt('account-state','No se encontró el perfil asociado a esta cuenta. Contacta con soporte.','error');$('account-content').hidden=true;return;}
  profile=data;profileLoadedFor=authUser.id;
  const form=$('profile-form');if(form){form.elements.namedItem('full_name').value=data.full_name||'';form.elements.namedItem('phone').value=data.phone||'';}
  $('account-content').hidden=false;txt('account-state',`Sesión iniciada como ${authUser.email||'usuario'}.`);
  document.querySelectorAll('[data-admin-link]').forEach(a=>a.hidden=data.role!=='admin');
}
function profileForm() {
  $('profile-form')?.addEventListener('submit',(event)=>{event.preventDefault();transient('profile-form','Guardando…',async()=>{
    if(!authUser)return;
    const values=new FormData($('profile-form'));
    const patch={full_name:String(values.get('full_name')||'').trim().slice(0,90),phone:String(values.get('phone')||'').trim().slice(0,30)};
    const {data,error}=await sb.from('profiles').update(patch).eq('id',authUser.id).select('id,full_name,phone,role').single();
    if(error){txt('profile-state','No fue posible guardar los datos. Intenta de nuevo.','error');return;}
    profile=data;txt('profile-state','Perfil actualizado correctamente.');
  });});
  $('logout-button')?.addEventListener('click',async()=>{
    const btn=$('logout-button');btn.disabled=true;
    try{const {error}=await sb.auth.signOut();if(error)throw error; profile=null;authUser=null;accountGuest();navigate('/acceso');}
    catch{txt('account-state','No fue posible cerrar sesión. Intenta nuevamente.','error');}
    finally{btn.disabled=false;}
  });
}
const addressFields=['full_name','phone','street','number','colony','city','postal_code','between_streets','customer_references'];
let addressCache=[];
function addressView(address) {
  const card=el('article','address-card');
  const title=el('h2','',address.full_name || 'Dirección');
  const addressLine=el('p','',`${address.street||''} ${address.number||''}, ${address.colony||''}, ${address.city||''}, C.P. ${address.postal_code||''}`);
  const contact=el('p','',address.phone||'');
  const edit=el('button','button button--outline','Editar');edit.type='button';
  edit.addEventListener('click',()=>{const form=$('address-form');addressFields.forEach(f=>form.elements.namedItem(f).value=address[f]||'');form.elements.namedItem('id').value=address.id;form.scrollIntoView({block:'start',behavior:'smooth'});$('address-cancel').hidden=false;});
  const del=el('button','button button--outline','Eliminar');del.type='button';
  del.addEventListener('click',async()=>{
    if(!confirm('¿Eliminar esta dirección?'))return;del.disabled=true;
    const {error}=await sb.from('addresses').delete().eq('id',address.id).eq('user_id',authUser.id);
    if(error)txt('addresses-state','No se pudo eliminar la dirección.','error');
    else await loadAddresses(routeToken);
    del.disabled=false;
  });
  card.append(title,addressLine,contact,edit,del);return card;
}
async function loadAddresses(token) {
  if(!authUser||!activeRoute(token))return;
  txt('addresses-state','Cargando tus direcciones…');
  const {data,error}=await sb.from('addresses').select('id,user_id,full_name,phone,street,number,colony,city,postal_code,between_streets,customer_references,is_default').eq('user_id',authUser.id).order('created_at',{ascending:false});
  if(!activeRoute(token)||!authUser)return;
  if(error){txt('addresses-state','No fue posible consultar tus direcciones.','error');return;}
  addressCache=data||[];
  $('addresses-list').replaceChildren(...addressCache.map(addressView));
  txt('addresses-state',addressCache.length?'':'Todavía no tienes direcciones guardadas.');
}
function addressForm() {
  $('address-form')?.addEventListener('submit',(event)=>{event.preventDefault();transient('address-form','Guardando…',async()=>{
    if(!authUser)return;
    const input=new FormData($('address-form'));const record={};
    addressFields.forEach(f=>record[f]=String(input.get(f)||'').trim().slice(0,180));
    record.user_id=authUser.id;
    const id=String(input.get('id')||'');
    const operation=id?sb.from('addresses').update(record).eq('id',id).eq('user_id',authUser.id):sb.from('addresses').insert(record);
    const {error}=await operation;
    if(error){txt('address-form-state','No pudimos guardar la dirección. Revisa los datos.','error');return;}
    $('address-form').reset();$('address-cancel').hidden=true;txt('address-form-state','Dirección guardada.');await loadAddresses(routeToken);
  });});
  $('address-cancel')?.addEventListener('click',()=>{$('address-form').reset();$('address-cancel').hidden=true;txt('address-form-state','');});
}
async function loadOrders(token, id) {
  if(!authUser||!activeRoute(token))return;
  const detail=Boolean(id);const state=detail?'order-detail-state':'orders-state';
  txt(state,'Consultando tus pedidos…');
  let query=sb.from('orders').select('id,order_number,user_id,total,currency,payment_status,order_status,delivery_method,created_at').eq('user_id',authUser.id).order('created_at',{ascending:false}).limit(50);
  if(detail)query=sb.from('orders').select('id,order_number,user_id,subtotal,shipping_cost,total,currency,payment_status,order_status,delivery_method,created_at').eq('user_id',authUser.id).eq('id',id).maybeSingle();
  const {data,error}=await query;
  if(!activeRoute(token)||!authUser)return;
  if(error){txt(state,'No fue posible consultar los pedidos.','error');return;}
  const box=$(detail?'order-detail':'orders-list');box.replaceChildren();
  if(detail){
    if(!data){txt(state,'No encontramos ese pedido en tu cuenta.','error');return;}
    const item=el('article','order-card');item.append(el('h2','',`Pedido ${data.order_number}`),el('p','',`Fecha: ${stamp(data.created_at)}`),el('p','',`Pago: ${data.payment_status}`),el('p','',`Estado: ${data.order_status}`),el('p','',`Total: ${money(data.total)}`));box.append(item);
    const {data:lines,error:lineError}=await sb.from('order_items').select('product_name,quantity,unit_price').eq('order_id',data.id);
    if(!activeRoute(token))return;
    if(!lineError&&Array.isArray(lines))for(const line of lines){const p=el('p','',`${line.quantity} × ${line.product_name} — ${money(Number(line.unit_price)*Number(line.quantity))}`);item.append(p);}
    txt(state,'');
  } else {
    if(!data?.length){txt(state,'Todavía no tienes pedidos registrados.');return;}
    for(const order of data){const card=el('article','order-card');card.append(el('h2','',`Pedido ${order.order_number}`),el('p','',`${stamp(order.created_at)} · ${money(order.total)}`),el('p','',`${order.order_status} · Pago ${order.payment_status}`),link(`/pedido/${order.id}`,'Ver detalle ↗'));box.append(card);}
    txt(state,'');
  }
}
async function showRoute(screen,id) {
  route={screen,id};
  const token=++routeToken;
  if(!authRouteNames.has(screen))return;
  if(!sb){
    const idState=({cuenta:'account-state',pedidos:'orders-state',direcciones:'addresses-state',admin:'admin-state'})[screen]||'login-state';
    if(screen!=='admin')txt(idState,'Conectando con Supabase…');
    return;
  }
  if(['acceso','registro','recuperar'].includes(screen))return;
  if(screen==='restablecer'){
    txt('reset-state',recoveryActive&&authUser?'Enlace válido. Escribe tu nueva contraseña.':'Necesitas abrir un enlace de recuperación válido.');
    return;
  }
  if(!authUser){
    if(screen==='cuenta')accountGuest();
    else if(screen==='direcciones')txt('addresses-state','Inicia sesión para consultar tus direcciones.');
    else if(screen==='pedidos'||screen==='pedido')txt('orders-state','Inicia sesión para consultar tus pedidos.');
    // Administración: el módulo admin.js comprueba el usuario y su rol en servidor.
    return;
  }
  if(screen==='cuenta')await loadProfile(token);
  else if(screen==='direcciones')await loadAddresses(token);
  else if(screen==='pedidos'||screen==='pedido')await loadOrders(token,screen==='pedido'?id:null);
  // No escribir admin-state aquí: el estado del panel pertenece a admin.js.
}
export function initAccount() {
  loginForm();profileForm();addressForm();
  window.addEventListener('mikosmetics:route',(event)=>{const {screen,id}=event.detail;showRoute(screen,id);});
  window.addEventListener('mikosmetics:account-refresh',()=>{const info=window.MIKOSMETICS_UI?.route;if(info)showRoute(info.screen,info.id);});
  accountGuest('Conectando con el servicio de cuenta…');
  starting=getClient().then((client)=>{
    sb=client;
    const {data:{subscription}}=sb.auth.onAuthStateChange((event,session)=>{
      authUser=session?.user||null;
      if(event==='PASSWORD_RECOVERY' || (passwordRecoveryInUrl && session?.user)) recoveryActive=true;
      if(event==='SIGNED_OUT'){profile=null;profileLoadedFor='';document.querySelectorAll('[data-admin-link]').forEach(a=>a.hidden=true);}
      if(event==='SIGNED_IN'&&authCodeInUrl)navigate(passwordRecoveryInUrl?'/restablecer':'/cuenta');
      if(event==='PASSWORD_RECOVERY')navigate('/restablecer');
      // No await de servicios Supabase dentro del callback de Auth.
      queueMicrotask(()=>window.dispatchEvent(new Event('mikosmetics:account-refresh')));
    });
    return sb.auth.getSession().then(({data,error})=>{
      if(error)throw error;authUser=data.session?.user||null;
      // Recuperar también el caso en que el SDK haya procesado la URL durante INITIAL_SESSION.
      if(authUser && authCodeInUrl) {
        if(passwordRecoveryInUrl) recoveryActive=true;
        navigate(passwordRecoveryInUrl?'/restablecer':'/cuenta');
      }
      window.dispatchEvent(new Event('mikosmetics:account-refresh'));
    });
  }).catch((error)=>{
    const message=describe(error,'No se pudo iniciar Supabase Auth. Comprueba tu conexión e intenta recargar.');
    for(const id of ['account-state','login-state','register-state','recover-state','reset-state'])txt(id,message,'error');
    console.warn('MIKOSMETICS: módulo de cuenta no disponible');
  });
}
