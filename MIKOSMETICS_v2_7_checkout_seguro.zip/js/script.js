/** MIKOSMETICS v2.6 — inicio resistente a fallos.
 * La navegación arranca incluso si catálogo, sesión o administración no cargan.
 * Nunca habilita pagos ni confía en un rol del navegador como autorización.
 */
import { initShell } from './ui-shell.js?v=27';
const states = ['featured-state','catalog-state','promos-state'];
const failState = (message) => {
  states.forEach(id => { const el=document.getElementById(id); if(el && /preparando|cargando|consultando/i.test(el.textContent||'')) { el.textContent=message; el.dataset.state='error'; } });
};
try {
  initShell();
  window.MIKO_BOOT_OK?.();
} catch (error) {
  console.error('MIKOSMETICS: no pudo iniciarse la navegación', error);
  window.MIKO_BOOT_FAIL?.();
}
const startFeature = async (name, path, fn) => {
  try {
    const mod = await import(path);
    if(typeof mod[fn] !== 'function') throw new Error('El módulo no expone su inicializador');
    mod[fn]();
    document.documentElement.dataset['loaded'+name]= 'true';
  } catch (error) {
    console.error(`MIKOSMETICS: error en ${name}`,error);
    if(name==='Catalogo') failState('No se pudo cargar el catálogo. Revisa tu conexión y recarga la página.');
    else if(name==='Cuenta') ['account-state','login-state','register-state','recover-state','reset-state'].forEach(id=>{const el=document.getElementById(id);if(el)el.textContent='No se pudo iniciar Mi cuenta. Recarga para intentar de nuevo.';});
    else if(name==='Admin') {const el=document.getElementById('admin-state');if(el)el.textContent='No se pudo iniciar Administración. Recarga la página.';}
    window.MIKOSMETICS_UI?.toast?.(`No se pudo cargar ${name}. Puedes seguir navegando.`, 'error');
  }
};
// Imports independientes: si uno falla, los demás siguen operativos.
if (document.documentElement.dataset.boot==='ready') {
  await startFeature('Catalogo','./storefront.js?v=27','initStorefront');
  await startFeature('Cuenta','./account.js?v=27','initAccount');
  await startFeature('Checkout','./checkout.js?v=27','initCheckout');
  await startFeature('Admin','./admin.js?v=27','initAdmin');
}
