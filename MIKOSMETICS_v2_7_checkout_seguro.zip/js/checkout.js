/** MIKOSMETICS 2.7 · revisión de compra (sin transacciones monetarias).
 * Leemos productos actuales directamente de Supabase; NO creamos pedidos ni cobramos.
 * El contrato servidor continúa bloqueado hasta que inventario + webhook sean idempotentes.
 */
import { getClient, PUBLIC_CONFIG } from './supabase-client.js?v=27';
import { cleanCart, analyzeInventory } from './checkout-contract.js?v=27';

const CART_KEY = 'mikosmetics:cart:v1';
const LOGIN_RETURN_KEY = 'mikosmetics:return:v27';
const money = new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' });
const $ = (id) => document.getElementById(id);
let routeController = null;
let busy = false;
let active = false;

function create(tag, className='', text='') {
  const node=document.createElement(tag);
  if(className)node.className=className;
  if(text)node.textContent=String(text);
  return node;
}
function state(message='', type='') {
  const node=$('checkout-state');if(!node)return;
  node.textContent=message;
  type?node.dataset.state=type:node.removeAttribute('data-state');
}
function formState(message='', type='') {
  const node=$('checkout-form-state');if(!node)return;
  node.textContent=message;
  type?node.dataset.state=type:node.removeAttribute('data-state');
}
function readCart() {
  try{return cleanCart(JSON.parse(localStorage.getItem(CART_KEY)||'[]'));}
  catch{return [];}
}
function showSimpleMessage(holder, message) {
  holder.replaceChildren(create('p','checkout-notice',message));
}
function showAuthCTA(user, notice='') {
  const holder=$('checkout-auth'); if(!holder)return;
  holder.replaceChildren();
  if(user) {
    holder.append(create('p','checkout-auth__success',`Sesión: ${user.email||'cliente identificado'}`));
    return;
  }
  holder.append(create('p','',notice || 'Inicia sesión para asociar el pedido a tu cuenta. El carrito se conservará.'));
  const a=create('a','button button--outline','Iniciar sesión ↗');
  a.href='#/acceso';a.dataset.link='';
  a.addEventListener('click',()=>{
    try{sessionStorage.setItem(LOGIN_RETURN_KEY,'/checkout');}catch{}
  });
  holder.append(a);
  const b=create('a','checkout-register','Crear cuenta ↗'); b.href='#/registro'; b.dataset.link='';
  b.addEventListener('click',()=>{
    try{sessionStorage.setItem(LOGIN_RETURN_KEY,'/checkout');}catch{}
  });
  holder.append(b);
}
function showAmounts(report) {
  const holder=$('checkout-summary');if(!holder)return;
  holder.replaceChildren();
  holder.append(create('h2','','Resumen de revisión'));
  for(const entry of report.lines) {
    const row=create('div','checkout-review-line');
    const title=create('span','',`${entry.quantity} × ${entry.name}`);
    const val=create('strong','',entry.valid?money.format(entry.total):'No disponible');
    row.append(title,val);holder.append(row);
    if(entry.reason)holder.append(create('p','checkout-line-warning',entry.reason));
  }
  const row=create('div','summary__row');row.append(create('span','','Subtotal estimado'),create('strong','',report.ok?money.format(report.subtotal):'—'));
  holder.append(row);
  holder.append(create('p','checkout-small','Importe sujeto a verificación del servidor. El carrito no aparta unidades. El envío no tiene tarifa configurada.'));
}
function deliveryUI() {
  const selected=document.querySelector('input[name="delivery_method"]:checked')?.value||'personal';
  const addr=$('checkout-address-field');if(addr)addr.hidden=selected!=='shipping';
  const help=$('shipping-state');if(help){
    help.textContent=selected==='shipping'
      ?'El envío nacional todavía no tiene tarifa aprobada. No se pueden solicitar cobros ni interpretarlo como envío gratuito.'
      :'Referencia de entrega personal: 20 de Noviembre. Ubicación y horario exactos pendientes de confirmar.';
  }
  const delivery=$('checkout-delivery-status');if(delivery)delivery.textContent=selected==='shipping'
    ?'Envío: tarifa pendiente de configurar en servidor.'
    :'Entrega personal: ubicación y horario pendientes de confirmar.';
}
async function fetchProducts(ids, signal) {
  const qs=new URLSearchParams();
  qs.set('select','id,name,price,stock,available,published,promotion_enabled,promotion_price,promotion_starts_at,promotion_ends_at');
  qs.set('id',`in.(${ids.join(',')})`);
  qs.set('published','eq.true');
  const url=`${PUBLIC_CONFIG.url}/rest/v1/products?${qs}`;
  const timeout=new AbortController();
  const stop=()=>timeout.abort();signal.addEventListener('abort',stop,{once:true});
  const timer=setTimeout(()=>timeout.abort(),10000);
  try {
    const res=await fetch(url, {headers:{apikey:PUBLIC_CONFIG.publishableKey,Accept:'application/json'},signal:timeout.signal,cache:'no-store'});
    if(!res.ok)throw new Error('catalog_http_'+res.status);
    const rows=await res.json();if(!Array.isArray(rows))throw new Error('catalog_shape');
    return rows;
  } finally {clearTimeout(timer);signal.removeEventListener('abort',stop);}
}
async function fetchAddresses(client,user,signal) {
  const select=$('checkout-address');if(!select)return;
  select.replaceChildren(new Option('Seleccionar dirección',''));
  if(!user)return;
  const {data,error}=await client.from('addresses').select('id,full_name,street,number,city,postal_code').eq('user_id',user.id).order('created_at',{ascending:false}).limit(25);
  if(signal.aborted)return;
  if(error){formState('No se pudieron consultar tus direcciones.','error');return;}
  for(const a of data||[])select.add(new Option(`${a.full_name||'Dirección'} · ${a.street||''} ${a.number||''}, ${a.city||''} · ${a.postal_code||''}`,a.id));
  if(!data?.length){
    const box=$('checkout-address-help');if(box){box.textContent='No tienes direcciones registradas. Puedes añadir una desde Mi cuenta → Direcciones.';}
  }
}
async function openReview(signal){
  if(busy)return;
  busy=true;active=true;
  const btn=$('create-order');if(btn)btn.disabled=true;
  state('Verificando productos y cantidades…');formState('');
  const cart=readCart();
  if(!cart.length){state('Tu carrito está vacío.');showSimpleMessage($('checkout-summary'),'Agrega productos para revisar la compra.');showAuthCTA(null);busy=false;if(btn)btn.disabled=false;return;}
  let report;
  try{
    const products=await fetchProducts(cart.map(v=>v.id),signal);
    if(signal.aborted)return;
    report=analyzeInventory(cart,products,Date.now());
    showAmounts(report);
    state(report.ok?'Precios y existencias consultados.':'Hay artículos agotados, retirados o con cantidades superiores al stock.',report.ok?'':'error');
    if(!report.ok){formState('Corrige el carrito antes de continuar.','error');}
  }catch(error){
    if(signal.aborted)return;
    state('No fue posible comprobar la disponibilidad. Revisa la conexión y pulsa Reintentar.','error');
    showSimpleMessage($('checkout-summary'),'El resumen no está disponible hasta obtener los datos actuales del servidor.');
    formState('La consulta no se completó. No se ha creado ningún pedido.','error');
  }
  if(signal.aborted)return;
  try{
    const client=await getClient();
    if(signal.aborted)return;
    const {data:{session},error}=await client.auth.getSession();
    if(error)throw error;
    const user=session?.user||null;
    showAuthCTA(user);
    if(user)await fetchAddresses(client,user,signal);
  }catch(error){
    if(signal.aborted)return;
    showAuthCTA(null,'No pudimos comprobar tu sesión. Puedes volver a intentarlo o abrir Mi cuenta.');
  }finally{
    if(!signal.aborted){busy=false;if(btn)btn.disabled=false;}
  }
}
function routeChanged(event){
  if(event.detail.screen!=='checkout'){
    active=false;
    if(routeController)routeController.abort();
    routeController=null;return;
  }
  if(routeController)routeController.abort();
  routeController=new AbortController();
  busy=false;
  deliveryUI();
  openReview(routeController.signal);
}
export function initCheckout(){
  const form=$('checkout-form');
  if(!form || !$('checkout-summary'))throw new Error('El HTML de checkout no coincide con la versión instalada.');
  form.addEventListener('change',e=>{if(e.target.name==='delivery_method')deliveryUI();});
  form.addEventListener('submit',e=>{
    e.preventDefault();
    // Revisión actualiza precios/stock; no emite órdenes ni envía pagos.
    if(routeController && !busy)openReview(routeController.signal);
  });
  window.addEventListener('mikosmetics:route',routeChanged);
  window.addEventListener('mikosmetics:cart-changed',()=>{
    if(active && routeController && !busy)openReview(routeController.signal);
  });
  window.addEventListener('mikosmetics:account-refresh',()=>{
    if(active && routeController && !busy)openReview(routeController.signal);
  });
  const route=window.MIKOSMETICS_UI?.route;
  if(route?.screen==='checkout')routeChanged({detail:route});
}
